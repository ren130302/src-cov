/*    */ package com.ruby.meshi.crafting;
/*    */ 
/*    */ import it.unimi.dsi.fastutil.ints.IntList;
/*    */ import java.lang.reflect.Field;
/*    */ import net.minecraft.item.crafting.IRecipe;
/*    */ import net.minecraft.item.crafting.RecipeItemHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GrindRecipeItemHelper
/*    */   extends RecipeItemHelper
/*    */ {
/*    */   public boolean func_194116_a(IRecipe<?> recipe, IntList packedItemList) {
/* 14 */     if (recipe instanceof GrindRecipe) {
/* 15 */       return func_194118_a(recipe, packedItemList, ((GrindRecipe)recipe).getRequestCount());
/*    */     }
/* 17 */     return super.func_194116_a(recipe, packedItemList);
/*    */   }
/*    */ 
/*    */ 
/*    */   public static void hookHelper(Class<?> target, Object instance) {
/* 22 */     for (Field field : target.getDeclaredFields()) {
/* 23 */       if (field.getType() == RecipeItemHelper.class) {
/* 24 */         field.setAccessible(true);
/*    */         try {
/* 26 */           field.set(instance, new GrindRecipeItemHelper());
/* 27 */         } catch (Exception e) {
/* 28 */           e.printStackTrace();
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 5 ms
	
*/