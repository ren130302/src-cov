package com.ruby.meshi.block;

import net.minecraft.item.DyeColor;

public interface SimpleColorMultiply<T> {
   int getColorCode();

   T setColorCode(DyeColor var1);
}