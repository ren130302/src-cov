/*    */ package com.ruby.meshi.util.packet;
/*    */ 
/*    */ import com.ruby.meshi.util.CapabilityExtendInventory;
/*    */ import java.util.function.Supplier;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.nbt.CompoundNBT;
/*    */ import net.minecraft.nbt.INBT;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ import net.minecraftforge.fml.network.NetworkEvent;
/*    */ 
/*    */ 
/*    */ public class NBTSyncHandler
/*    */ {
/*    */   public final CompoundNBT nbt;
/*    */   
/*    */   public NBTSyncHandler(INBT nbt) {
/* 17 */     this; this.nbt = compNBT(nbt);
/*    */   }
/*    */ 
/*    */   public static CompoundNBT compNBT(INBT nbt) {
/* 21 */     CompoundNBT tmp = new CompoundNBT();
/* 22 */     tmp.func_218657_a("sync", nbt);
/* 23 */     return tmp;
/*    */   }
/*    */ 
/*    */   public static INBT decompNBT(CompoundNBT nbt) {
/* 27 */     return nbt.func_74781_a("sync");
/*    */   }
/*    */ 
/*    */   public NBTSyncHandler(CompoundNBT nbt) {
/* 31 */     this.nbt = nbt;
/*    */   }
/*    */ 
/*    */   public static void encode(NBTSyncHandler msg, PacketBuffer buf) {
/* 35 */     buf.func_150786_a(msg.nbt);
/*    */   }
/*    */ 
/*    */   public static NBTSyncHandler decode(PacketBuffer buf) {
/* 39 */     return new NBTSyncHandler(buf.func_150793_b());
/*    */   }
/*    */ 
/*    */   public CompoundNBT getNBT() {
/* 43 */     return this.nbt;
/*    */   }
/*    */ 
/*    */   public static void handle(NBTSyncHandler message, Supplier<NetworkEvent.Context> ctx) {
/* 47 */     ((NetworkEvent.Context)ctx.get()).enqueueWork(() -> CapabilityExtendInventory.EXTEND_INVENTORY.readNBT((Minecraft.func_71410_x()).field_71439_g.getCapability(CapabilityExtendInventory.EXTEND_INVENTORY).orElse(CapabilityExtendInventory.EXTEND_INVENTORY.getDefaultInstance()), null, decompNBT(message.nbt)));
/*    */ 
/*    */     
/* 50 */     ((NetworkEvent.Context)ctx.get()).setPacketHandled(true);
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 7 ms
	
*/