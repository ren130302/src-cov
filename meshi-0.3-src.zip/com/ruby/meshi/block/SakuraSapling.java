/*    */ package com.ruby.meshi.block;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.SaplingBlock;
/*    */ import net.minecraft.block.trees.Tree;
/*    */ 
/*    */ public class SakuraSapling
/*    */   extends SaplingBlock {
/*    */   public SakuraSapling(Tree p_i48337_1_, Block.Properties properties) {
/* 10 */     super(p_i48337_1_, properties);
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 1 ms
	
*/