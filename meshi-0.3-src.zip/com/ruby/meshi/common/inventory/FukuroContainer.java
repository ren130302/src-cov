/*     */ package com.ruby.meshi.common.inventory;
/*     */ 
/*     */ import com.ruby.meshi.init.HiganContainerType;
/*     */ import com.ruby.meshi.item.Fukuro;
/*     */ import net.minecraft.entity.player.PlayerEntity;
/*     */ import net.minecraft.entity.player.PlayerInventory;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.Inventory;
/*     */ import net.minecraft.inventory.container.Container;
/*     */ import net.minecraft.inventory.container.ContainerType;
/*     */ import net.minecraft.inventory.container.Slot;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ public class FukuroContainer
/*     */   extends Container
/*     */ {
/*     */   private IInventory inventory;
/*     */   private World world;
/*     */   
/*     */   public FukuroContainer(int windowId, PlayerInventory playerInventory) {
/*  23 */     this(HiganContainerType.FUKURO, windowId, playerInventory, (IInventory)new Inventory(1));
/*     */   }
/*     */ 
/*     */   public FukuroContainer(int windowId, PlayerInventory playerInventory, Fukuro.FukuroInventory inventory) {
/*  27 */     this(HiganContainerType.FUKURO, windowId, playerInventory, inventory);
/*     */   }
/*     */ 
/*     */   public FukuroContainer(ContainerType<?> type, int id, PlayerInventory playerInventory, IInventory inventory) {
/*  31 */     super(type, id);
/*  32 */     this.inventory = inventory;
/*  33 */     inventory.func_174889_b(playerInventory.field_70458_d);
/*  34 */     this.world = playerInventory.field_70458_d.field_70170_p;
/*     */     
/*  36 */     func_75146_a(new FukuroSlot(this.inventory, 0, 80, 33));
/*     */     
/*  38 */     for (int k = 0; k < 3; k++) {
/*  39 */       for (int i1 = 0; i1 < 9; i1++) {
/*  40 */         func_75146_a(new Slot((IInventory)playerInventory, i1 + k * 9 + 9, 8 + i1 * 18, 84 + k * 18));
/*     */       }
/*     */     } 
/*     */     
/*  44 */     for (int l = 0; l < 9; l++) {
/*  45 */       func_75146_a(new Slot((IInventory)playerInventory, l, 8 + l * 18, 142));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_75145_c(PlayerEntity playerIn) {
/*  51 */     return this.inventory.func_70300_a(playerIn);
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_75134_a(PlayerEntity playerIn) {
/*  56 */     super.func_75134_a(playerIn);
/*  57 */     playerIn.func_184602_cy();
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_94530_a(ItemStack stack, Slot slotIn) {
/*  62 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   public ItemStack func_82846_b(PlayerEntity playerIn, int index) {
/*  67 */     ItemStack itemstack = ItemStack.field_190927_a;
/*  68 */     Slot slot = this.field_75151_b.get(index);
/*  69 */     if (slot != null && slot.func_75216_d()) {
/*  70 */       ItemStack itemstack1 = slot.func_75211_c();
/*  71 */       itemstack = itemstack1.func_77946_l();
/*  72 */       if (index != 0)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  78 */         if (index >= 1 && index < 27) {
/*  79 */           if (!func_75135_a(itemstack1, 27, 36, false)) {
/*  80 */             return ItemStack.field_190927_a;
/*     */           }
/*  82 */         } else if (index >= 27 && index < 36) {
/*  83 */           if (!func_75135_a(itemstack1, 1, 27, false)) {
/*  84 */             return ItemStack.field_190927_a;
/*     */           }
/*  86 */         } else if (!func_75135_a(itemstack1, 1, 36, false)) {
/*  87 */           return ItemStack.field_190927_a;
/*     */         } 
/*     */       }
/*  90 */       if (itemstack1.func_190926_b()) {
/*  91 */         slot.func_75215_d(ItemStack.field_190927_a);
/*     */       } else {
/*  93 */         slot.func_75218_e();
/*     */       } 
/*     */       
/*  96 */       if (itemstack1.func_190916_E() == itemstack.func_190916_E()) {
/*  97 */         return ItemStack.field_190927_a;
/*     */       }
/*     */       
/* 100 */       ItemStack itemstack2 = slot.func_190901_a(playerIn, itemstack1);
/* 101 */       if (index == 0) {
/* 102 */         playerIn.func_71019_a(itemstack2, false);
/*     */       }
/*     */     } 
/*     */     
/* 106 */     return itemstack;
/*     */   }
/*     */ 
/*     */   static class FukuroSlot
/*     */     extends Slot {
/*     */     public FukuroSlot(IInventory inventoryIn, int index, int xPosition, int yPosition) {
/* 112 */       super(inventoryIn, index, xPosition, yPosition);
/*     */     }
/*     */ 
/*     */ 
/*     */     public boolean func_75214_a(ItemStack stack) {
/* 117 */       return Fukuro.isItemValid(stack);
/*     */     }
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 7 ms
	
*/