/*     */ package com.ruby.meshi.block.tileentity;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.ruby.meshi.block.Cardboard;
/*     */ import com.ruby.meshi.client.renderer.animation.AnimationSet;
/*     */ import com.ruby.meshi.client.renderer.animation.AnimationTile;
/*     */ import com.ruby.meshi.client.renderer.animation.EntityModelAnimation;
/*     */ import com.ruby.meshi.init.HiganTileEntityType;
/*     */ import java.util.List;
/*     */ import java.util.function.Predicate;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityType;
/*     */ import net.minecraft.entity.passive.CatEntity;
/*     */ import net.minecraft.nbt.CompoundNBT;
/*     */ import net.minecraft.nbt.INBT;
/*     */ import net.minecraft.network.NetworkManager;
/*     */ import net.minecraft.network.play.server.SUpdateTileEntityPacket;
/*     */ import net.minecraft.state.IProperty;
/*     */ import net.minecraft.tileentity.ITickableTileEntity;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.Direction;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraftforge.api.distmarker.Dist;
/*     */ import net.minecraftforge.api.distmarker.OnlyIn;
/*     */ 
/*     */ @OnlyIn(value = Dist.CLIENT, _interface = AnimationTile.class)
/*     */ public class CardboardTileEntity
/*     */   extends TileEntity
/*     */   implements ITickableTileEntity, AnimationTile {
/*     */   private CompoundNBT nbt;
/*     */   private static final String CAT = "cat";
/*     */   private static final String CAT_DATA = "cat_data";
/*     */   @OnlyIn(Dist.CLIENT)
/*     */   private List<EntityModelAnimation> animation;
/*     */   public boolean isOccupied = false;
/*     */   
/*     */   public CardboardTileEntity() {
/*  39 */     super(HiganTileEntityType.CARDBOARD);
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_73660_a() {
/*  44 */     if ((func_145831_w()).field_72995_K) {
/*  45 */       animateTick();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   public void animateTick() {
/*  51 */     if (getAnimations().isEmpty()) {
/*  52 */       int animeNo = this.field_145850_b.func_201674_k().nextInt(3);
/*  53 */       if (animeNo == 0) {
/*  54 */         getAnimations().addAll(AnimationSet.createSwingHead(getDirection(), true));
/*  55 */       } else if (animeNo == 1) {
/*  56 */         getAnimations().addAll(AnimationSet.createWatchHead(getDirection(), func_174877_v(), searchEntity(e -> e instanceof net.minecraft.entity.LivingEntity), true));
/*     */       } else {
/*  58 */         getAnimations().addAll(AnimationSet.createTail(getDirection()));
/*     */       }
/*     */     
/*  61 */     } else if (!hasCatNBT()) {
/*  62 */       getAnimations().clear();
/*     */     } 
/*     */ 
/*     */     
/*  66 */     getAnimations().forEach(EntityModelAnimation::animationTick);
/*     */   }
/*     */ 
/*     */   public Entity searchEntity(Predicate<Entity> tester) {
/*  70 */     return this.field_145850_b.func_175674_a(null, (new AxisAlignedBB(this.field_174879_c)).func_186662_g(10.0D), tester).stream().findAny().orElse(null);
/*     */   }
/*     */ 
/*     */   private Direction getDirection() {
/*  74 */     return (Direction)func_195044_w().func_177229_b((IProperty)Cardboard.field_185512_D);
/*     */   }
/*     */ 
/*     */   public void compoundCat(CatEntity cat) {
/*  78 */     getNBT().func_218657_a("cat_data", (INBT)cat.func_189511_e(new CompoundNBT()));
/*  79 */     cat.func_70106_y();
/*     */   }
/*     */ 
/*     */   public void createCatFromNBT() {
/*  83 */     if (hasCatNBT()) {
/*  84 */       CatEntity cat = (CatEntity)EntityType.field_220360_g.func_200721_a(func_145831_w());
/*  85 */       cat.func_70020_e(getCatNBT());
/*  86 */       func_145831_w().func_217376_c((Entity)cat);
/*  87 */       this.nbt = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   public boolean hasCatNBT() {
/*  92 */     return (this.nbt != null && !this.nbt.isEmpty());
/*     */   }
/*     */ 
/*     */   public int getCatType() {
/*  96 */     if (this.nbt == null || this.nbt.isEmpty()) {
/*  97 */       return 0;
/*     */     }
/*  99 */     return getCatNBT().func_74762_e("CatType");
/*     */   }
/*     */ 
/*     */   @Nullable
/*     */   public CompoundNBT getCatNBT() {
/* 104 */     if (this.nbt != null && !this.nbt.isEmpty()) {
/* 105 */       return this.nbt.func_74775_l("cat_data");
/*     */     }
/* 107 */     return null;
/*     */   }
/*     */ 
/*     */   private CompoundNBT getNBT() {
/* 111 */     if (this.nbt == null) {
/* 112 */       this.nbt = new CompoundNBT();
/*     */     }
/* 114 */     return this.nbt;
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_145839_a(CompoundNBT compound) {
/* 119 */     super.func_145839_a(compound);
/* 120 */     readData(compound);
/* 121 */     this.isOccupied = hasCatNBT();
/*     */   }
/*     */ 
/*     */ 
/*     */   public CompoundNBT func_189515_b(CompoundNBT compound) {
/* 126 */     super.func_189515_b(compound);
/* 127 */     return writeData(compound);
/*     */   }
/*     */ 
/*     */   public void readData(CompoundNBT compound) {
/* 131 */     this.nbt = compound.func_74775_l("cat");
/*     */   }
/*     */ 
/*     */   public CompoundNBT writeData(CompoundNBT compound) {
/* 135 */     if (this.nbt != null && !this.nbt.isEmpty()) {
/* 136 */       compound.func_218657_a("cat", (INBT)this.nbt);
/*     */     }
/* 138 */     return compound;
/*     */   }
/*     */ 
/*     */ 
/*     */   public void handleUpdateTag(CompoundNBT tag) {
/* 143 */     super.handleUpdateTag(tag);
/* 144 */     readData(tag);
/*     */   }
/*     */ 
/*     */ 
/*     */   public CompoundNBT func_189517_E_() {
/* 149 */     CompoundNBT tag = super.func_189517_E_();
/* 150 */     writeData(tag);
/* 151 */     return tag;
/*     */   }
/*     */ 
/*     */ 
/*     */   public void onDataPacket(NetworkManager net, SUpdateTileEntityPacket pkt) {
/* 156 */     readData(pkt.func_148857_g());
/*     */   }
/*     */ 
/*     */ 
/*     */   public SUpdateTileEntityPacket func_189518_D_() {
/* 161 */     CompoundNBT var1 = new CompoundNBT();
/* 162 */     writeData(var1);
/* 163 */     return new SUpdateTileEntityPacket(func_174877_v(), 5, var1);
/*     */   }
/*     */ 
/*     */ 
/*     */   public List<EntityModelAnimation> getAnimations() {
/* 168 */     if (this.animation == null) {
/* 169 */       this.animation = Lists.newArrayList();
/*     */     }
/* 171 */     return this.animation;
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 13 ms
	
*/