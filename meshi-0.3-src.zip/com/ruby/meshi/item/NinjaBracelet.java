/*     */ package com.ruby.meshi.item;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.GlStateManager;
/*     */ import com.ruby.meshi.enchant.HiganEnchant;
/*     */ import com.ruby.meshi.enchant.HiganEnchantType;
/*     */ import com.ruby.meshi.entity.ShurikenEntity;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ThreadLocalRandom;
/*     */ import java.util.stream.Stream;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.player.AbstractClientPlayerEntity;
/*     */ import net.minecraft.client.entity.player.ClientPlayerEntity;
/*     */ import net.minecraft.client.renderer.entity.PlayerRenderer;
/*     */ import net.minecraft.client.util.ITooltipFlag;
/*     */ import net.minecraft.enchantment.Enchantment;
/*     */ import net.minecraft.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.LivingEntity;
/*     */ import net.minecraft.entity.ai.attributes.AttributeModifier;
/*     */ import net.minecraft.entity.player.PlayerEntity;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.potion.Effect;
/*     */ import net.minecraft.potion.EffectInstance;
/*     */ import net.minecraft.potion.Effects;
/*     */ import net.minecraft.stats.Stats;
/*     */ import net.minecraft.util.ActionResult;
/*     */ import net.minecraft.util.ActionResultType;
/*     */ import net.minecraft.util.Hand;
/*     */ import net.minecraft.util.HandSide;
/*     */ import net.minecraft.util.SoundCategory;
/*     */ import net.minecraft.util.SoundEvents;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TextFormatting;
/*     */ import net.minecraft.util.text.TranslationTextComponent;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.api.distmarker.Dist;
/*     */ import net.minecraftforge.api.distmarker.OnlyIn;
/*     */ import net.minecraftforge.client.event.RenderSpecificHandEvent;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.event.ForgeEventFactory;
/*     */ import net.minecraftforge.fml.DistExecutor;
/*     */ 
/*     */ public class NinjaBracelet
/*     */   extends Item
/*     */   implements KatanaDrop.KatanaDropListener {
/*  50 */   public static final ThreadLocalRandom random = ThreadLocalRandom.current();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NinjaBracelet(Item.Properties properties) {
/*  56 */     this(properties, 1.25F, 1.75F);
/*     */   }
/*     */ 
/*     */   public NinjaBracelet(Item.Properties properties, float velocityBase, float inaccuracyBase) {
/*  60 */     super(properties);
/*  61 */     DistExecutor.runWhenOn(Dist.CLIENT, () -> ());
/*  62 */     this.velocityBase = velocityBase;
/*  63 */     this.inaccuracyBase = inaccuracyBase;
/*     */   }
/*     */ 
/*     */ 
/*     */   public ActionResult<ItemStack> func_77659_a(World worldIn, PlayerEntity playerIn, Hand handIn) {
/*  68 */     ItemStack bracelet = playerIn.func_184586_b(handIn);
/*  69 */     ItemStack itemstack = playerIn.field_71071_by.field_70462_a.stream().filter(s -> s.func_77973_b() instanceof Shuriken).findFirst().orElse(ItemStack.field_190927_a);
/*  70 */     if (itemstack.func_190926_b()) {
/*  71 */       return new ActionResult(ActionResultType.FAIL, bracelet);
/*     */     }
/*     */     
/*  74 */     playerIn.func_184609_a(handIn);
/*  75 */     worldIn.func_184148_a((PlayerEntity)null, playerIn.field_70165_t, playerIn.field_70163_u, playerIn.field_70161_v, SoundEvents.field_187797_fA, SoundCategory.PLAYERS, 0.5F, 0.4F / (random.nextFloat() * 0.4F + 0.8F));
/*  76 */     if (!worldIn.field_72995_K) {
/*  77 */       ShurikenEntity entity = new ShurikenEntity((LivingEntity)playerIn, worldIn);
/*     */       
/*  79 */       checkAddMultiThrow(entity, bracelet);
/*     */       
/*  81 */       checkAddCritical(entity, bracelet);
/*     */       
/*  83 */       entity.func_70239_b(getThrowingDamage(bracelet));
/*     */       
/*  85 */       checkAddReturn(entity, bracelet);
/*     */       
/*  87 */       checkAddFlame(entity, bracelet);
/*     */       
/*  89 */       checkAddInfinity(entity, bracelet, itemstack);
/*     */       
/*  91 */       checkAddEconomy(entity, bracelet);
/*     */       
/*  93 */       checkAddPoison(entity, bracelet);
/*     */       
/*  95 */       entity.setItemStack(itemstack);
/*  96 */       float velocity = this.velocityBase;
/*  97 */       float inaccuracy = this.inaccuracyBase;
/*     */       
/*  99 */       if (hasEnchant(bracelet, new Enchantment[] { HiganEnchant.SNIPE_THROW })) {
/* 100 */         velocity *= 1.1F;
/* 101 */         inaccuracy *= 0.5F;
/*     */       } 
/* 103 */       entity.func_184547_a((Entity)playerIn, playerIn.field_70125_A, playerIn.field_70177_z, 0.0F, velocity, inaccuracy);
/* 104 */       worldIn.func_217376_c((Entity)entity);
/*     */       
/* 106 */       playerIn.func_184811_cZ().func_185145_a(this, getThrowingDelay(bracelet));
/*     */       
/* 108 */       if (!playerIn.field_71075_bZ.field_75098_d) {
/* 109 */         if (!entity.isNoPickup()) {
/* 110 */           itemstack.func_190918_g(1);
/*     */         }
/* 112 */         if (!isUnbreaking(bracelet)) {
/* 113 */           bracelet.func_222118_a(1, (LivingEntity)playerIn, p -> {
/*     */                 p.func_213334_d(playerIn.func_184600_cs());
/*     */                 
/*     */                 ForgeEventFactory.onPlayerDestroyItem(playerIn, playerIn.func_184607_cu(), playerIn.func_184600_cs());
/*     */               });
/*     */         }
/*     */       } 
/*     */     } 
/* 121 */     playerIn.func_71029_a(Stats.field_75929_E.func_199076_b(this));
/* 122 */     return new ActionResult(ActionResultType.SUCCESS, bracelet);
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean onLeftClickEntity(ItemStack stack, PlayerEntity player, Entity entity) {
/* 127 */     if (entity instanceof LivingEntity) {
/* 128 */       ((LivingEntity)entity).func_70653_a((Entity)player, 1.0F, MathHelper.func_76126_a(player.field_70177_z * 0.017453292F), -MathHelper.func_76134_b(player.field_70177_z * 0.017453292F));
/*     */     }
/* 130 */     return true;
/*     */   }
/*     */ 
/*     */   void checkAddPoison(ShurikenEntity entity, ItemStack stack) {
/* 134 */     int lvl = getEnchantLv(stack, new Enchantment[] { HiganEnchant.POISON_THROW, HiganEnchant.ROGUE_THROW, HiganEnchant.ASSASSIN_THROW });
/* 135 */     if (lvl > 0) {
/* 136 */       boolean isVenom = (lvl > 5);
/* 137 */       int amp = isVenom ? 2 : 0;
/* 138 */       int duration = isVenom ? 15 : 10;
/* 139 */       Effect[] effect = { isVenom ? Effects.field_82731_v : Effects.field_76436_u, Effects.field_76437_t, Effects.field_76421_d, Effects.field_188423_x };
/* 140 */       entity.addEffect(new EffectInstance(effect[(isVenom && random.nextBoolean()) ? 0 : random.nextInt(effect.length)], duration * lvl, amp));
/*     */     } 
/*     */   }
/*     */ 
/*     */   void checkAddEconomy(ShurikenEntity entity, ItemStack stack) {
/* 145 */     if (random.nextFloat() < getEconomyRate(stack)) {
/* 146 */       entity.setNonPickup();
/*     */     }
/*     */   }
/*     */ 
/*     */   void checkAddInfinity(ShurikenEntity entity, ItemStack stack, ItemStack star) {
/* 151 */     if (hasEnchant(stack, new Enchantment[] { HiganEnchant.INFINITY_THROW })) {
/* 152 */       Item item = star.func_77973_b();
/* 153 */       if (item instanceof Shuriken) {
/* 154 */         entity.setInfinity(((Shuriken)item).getTier());
/* 155 */         entity.setNonPickup();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   boolean isUnbreaking(ItemStack stack) {
/* 161 */     int lvl = getEnchantLv(stack, new Enchantment[] { HiganEnchant.UNBREAKING_BRACELET });
/* 162 */     return (random.nextFloat() < lvl * 0.25F);
/*     */   }
/*     */ 
/*     */   void checkAddReturn(ShurikenEntity entity, ItemStack stack) {
/* 166 */     if (hasEnchant(stack, new Enchantment[] { HiganEnchant.RETURN_THROW })) {
/* 167 */       entity.setIsReturn(true);
/*     */     }
/*     */   }
/*     */ 
/*     */   void checkAddFlame(ShurikenEntity entity, ItemStack stack) {
/* 172 */     if (hasEnchant(stack, new Enchantment[] { HiganEnchant.FLAME_THROW })) {
/* 173 */       entity.func_70015_d(5);
/*     */     }
/*     */   }
/*     */ 
/*     */   public float getEconomyRate(ItemStack stack) {
/* 178 */     int lvl = getEnchantLv(stack, new Enchantment[] { HiganEnchant.ECONOMY_BRACELET });
/*     */     
/* 180 */     return (lvl * lvl + 1) * 0.08F;
/*     */   }
/*     */ 
/*     */   public float getThrowingDamage(ItemStack stack) {
/* 184 */     return calcThrowingDamage(getEnchantLv(stack, new Enchantment[] { HiganEnchant.POWER_THROW, HiganEnchant.HUNTER_THROW, HiganEnchant.ASSASSIN_THROW }));
/*     */   }
/*     */ 
/*     */   public float calcThrowingDamage(int enchantLv) {
/* 188 */     float damage = 0.0F;
/* 189 */     if (enchantLv > 0) {
/* 190 */       damage = Math.min(enchantLv, 5);
/* 191 */       if (enchantLv > 5) {
/* 192 */         enchantLv -= 5;
/* 193 */         damage += (enchantLv * 2);
/*     */       } 
/*     */     } 
/* 196 */     return damage;
/*     */   }
/*     */ 
/*     */   public int getThrowingDelay(ItemStack stack) {
/* 200 */     return calcThrowingDelay(getEnchantLv(stack, new Enchantment[] { HiganEnchant.QUICK_THROW, HiganEnchant.HUNTER_THROW, HiganEnchant.ASSASSIN_THROW }));
/*     */   }
/*     */ 
/*     */   public int calcThrowingDelay(int enchantLv) {
/* 204 */     int coolTime = 20;
/* 205 */     if (enchantLv > 0) {
/* 206 */       coolTime -= Math.min(enchantLv * 2, 10);
/*     */       
/* 208 */       if (enchantLv > 5) {
/* 209 */         enchantLv -= 5;
/* 210 */         coolTime -= enchantLv * 5;
/*     */       } 
/*     */     } 
/* 213 */     return Math.max(coolTime, 0);
/*     */   }
/*     */ 
/*     */   void checkAddCritical(ShurikenEntity entity, ItemStack stack) {
/* 217 */     int lvl = getEnchantLv(stack, new Enchantment[] { HiganEnchant.CRITICAL_THROW, HiganEnchant.ROGUE_THROW, HiganEnchant.ASSASSIN_THROW });
/* 218 */     if (lvl > 0) {
/* 219 */       float crit = Math.min(lvl * 0.1F, 0.5F);
/* 220 */       if (lvl > 5) {
/* 221 */         lvl -= 5;
/* 222 */         crit += lvl * 0.25F;
/*     */       } 
/* 224 */       entity.func_70243_d((random.nextFloat() < crit));
/*     */     } 
/*     */   }
/*     */ 
/*     */   void checkAddMultiThrow(ShurikenEntity entity, ItemStack stack) {
/* 229 */     int lvl = getEnchantLv(stack, new Enchantment[] { HiganEnchant.MULTI_THROW });
/* 230 */     if (lvl > 0) {
/* 231 */       if (lvl == 1 && random.nextBoolean()) {
/* 232 */         entity.setMultiThrow(1);
/*     */       } else {
/* 234 */         entity.setMultiThrow(lvl - 1);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getEnchantLv(ItemStack stack, Enchantment... enc) {
/* 247 */     return ((Integer)Stream.<Enchantment>of(enc).map(e -> Integer.valueOf(EnchantmentHelper.func_77506_a(e, stack)))
/* 248 */       .max(Comparator.naturalOrder()).orElse(Integer.valueOf(0))).intValue();
/*     */   }
/*     */ 
/*     */   public boolean hasEnchant(ItemStack stack, Enchantment... enc) {
/* 252 */     return (getEnchantLv(stack, enc) > 0);
/*     */   }
/*     */ 
/*     */   @OnlyIn(Dist.CLIENT)
/*     */   public void renderItem(RenderSpecificHandEvent event) {
/* 257 */     if (event.getItemStack().func_77973_b() == this) {
/* 258 */       event.setCanceled(true);
/* 259 */       renderArmFirstPerson(event.getEquipProgress(), event.getSwingProgress(), event.getHand());
/*     */     } 
/*     */   }
/*     */ 
/*     */   @OnlyIn(Dist.CLIENT)
/*     */   void renderArmFirstPerson(float equippedProgress, float swingProgress, Hand hand) {
/* 265 */     Minecraft mc = Minecraft.func_71410_x();
/* 266 */     ClientPlayerEntity clientPlayerEntity = mc.field_71439_g;
/* 267 */     HandSide side = (hand == Hand.MAIN_HAND) ? clientPlayerEntity.func_184591_cq() : clientPlayerEntity.func_184591_cq().func_188468_a();
/* 268 */     boolean flag = (side != HandSide.LEFT);
/* 269 */     float f = flag ? 1.0F : -1.0F;
/* 270 */     float f1 = MathHelper.func_76129_c(swingProgress);
/* 271 */     float f2 = -0.3F * MathHelper.func_76126_a(f1 * 3.1415927F);
/* 272 */     float f3 = 0.4F * MathHelper.func_76126_a(f1 * 6.2831855F);
/* 273 */     float f4 = -0.4F * MathHelper.func_76126_a(swingProgress * 3.1415927F);
/* 274 */     GlStateManager.translatef(f * (f2 + 0.64000005F), f3 + -0.6F + equippedProgress * -0.6F, f4 + -0.71999997F);
/* 275 */     GlStateManager.rotatef(f * 45.0F, 0.0F, 1.0F, 0.0F);
/* 276 */     float f5 = MathHelper.func_76126_a(swingProgress * swingProgress * 3.1415927F);
/* 277 */     float f6 = MathHelper.func_76126_a(f1 * 3.1415927F);
/* 278 */     GlStateManager.rotatef(f * f6 * 70.0F, 0.0F, 1.0F, 0.0F);
/* 279 */     GlStateManager.rotatef(f * f5 * -20.0F, 0.0F, 0.0F, 1.0F);
/* 280 */     mc.func_110434_K().func_110577_a(clientPlayerEntity.func_110306_p());
/* 281 */     GlStateManager.translatef(f * -1.0F, 3.6F, 3.5F);
/* 282 */     GlStateManager.rotatef(f * 120.0F, 0.0F, 0.0F, 1.0F);
/* 283 */     GlStateManager.rotatef(200.0F, 1.0F, 0.0F, 0.0F);
/* 284 */     GlStateManager.rotatef(f * -135.0F, 0.0F, 1.0F, 0.0F);
/* 285 */     GlStateManager.translatef(f * 5.6F, 0.0F, 0.0F);
/* 286 */     PlayerRenderer playerrenderer = (PlayerRenderer)mc.func_175598_ae().func_78713_a((Entity)clientPlayerEntity);
/* 287 */     GlStateManager.disableCull();
/* 288 */     if (flag) {
/* 289 */       playerrenderer.func_177138_b((AbstractClientPlayerEntity)clientPlayerEntity);
/*     */     } else {
/* 291 */       playerrenderer.func_177139_c((AbstractClientPlayerEntity)clientPlayerEntity);
/*     */     } 
/* 293 */     GlStateManager.enableCull();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean canApplyAtEnchantingTable(ItemStack stack, Enchantment enchantment) {
/* 299 */     return (HiganEnchantType.BRACELET == enchantment.field_77351_y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int func_77619_b() {
/* 306 */     return 120;
/*     */   }
/*     */ 
/*     */ 
/*     */   @OnlyIn(Dist.CLIENT)
/*     */   public void func_77624_a(ItemStack stack, @Nullable World worldIn, List<ITextComponent> tooltip, ITooltipFlag flagIn) {
/* 312 */     float dmg = getThrowingDamage(stack);
/* 313 */     int speed = getThrowingDelay(stack);
/* 314 */     int eco = (int)(getEconomyRate(stack) * 100.0F);
/* 315 */     if (dmg > 0.0F) {
/* 316 */       tooltip.add((new TranslationTextComponent("attribute.modifier.equals." + AttributeModifier.Operation.ADDITION.func_220371_a(), new Object[] { ItemStack.field_111284_a.format(dmg), new TranslationTextComponent("tooltip.meshi.throwing_damage", new Object[0]) })).func_211708_a(TextFormatting.DARK_GREEN));
/*     */     }
/* 318 */     tooltip.add((new TranslationTextComponent("attribute.modifier.equals." + AttributeModifier.Operation.ADDITION.func_220371_a(), new Object[] { ItemStack.field_111284_a.format(speed), new TranslationTextComponent("tooltip.meshi.throwing_delay", new Object[0]) })).func_211708_a(TextFormatting.DARK_GREEN));
/* 319 */     tooltip.add((new TranslationTextComponent("attribute.modifier.equals." + AttributeModifier.Operation.ADDITION.func_220371_a(), new Object[] { ItemStack.field_111284_a.format(eco), new TranslationTextComponent("tooltip.meshi.throwing_save", new Object[0]) })).func_211708_a(TextFormatting.DARK_GREEN));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean canKatanaDrop(LivingEntity source, LivingEntity target, ItemStack stack, Hand hand) {
/* 325 */     return hasEnchant(stack, new Enchantment[] { HiganEnchant.PICKPOCKET });
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 26 ms
	
*/