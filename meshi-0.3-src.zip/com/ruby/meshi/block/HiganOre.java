/*    */ package com.ruby.meshi.block;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.BlockState;
/*    */ import net.minecraft.block.OreBlock;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.math.MathHelper;
/*    */ import net.minecraft.world.storage.loot.LootContext;
/*    */ import net.minecraftforge.common.ToolType;
/*    */ 
/*    */ public class HiganOre
/*    */   extends OreBlock {
/*    */   public HiganOre(Block.Properties properties) {
/* 16 */     super(properties);
/*    */   }
/*    */ 
/*    */ 
/*    */   public ToolType getHarvestTool(BlockState state) {
/* 21 */     return ToolType.PICKAXE;
/*    */   }
/*    */ 
/*    */ 
/*    */   public int getHarvestLevel(BlockState state) {
/* 26 */     if (this == SakuraBlocks.SAKURA_ORE) {
/* 27 */       return 3;
/*    */     }
/* 29 */     if (this == SakuraBlocks.GINKGO_ORE) {
/* 30 */       return 2;
/*    */     }
/* 32 */     return 1;
/*    */   }
/*    */ 
/*    */ 
/*    */   protected int func_220281_a(Random rand) {
/* 37 */     if (this == SakuraBlocks.SAKURA_ORE) {
/* 38 */       return MathHelper.func_76136_a(rand, 6, 10);
/*    */     }
/* 40 */     if (this == SakuraBlocks.GINKGO_ORE) {
/* 41 */       return MathHelper.func_76136_a(rand, 3, 7);
/*    */     }
/* 43 */     return 0;
/*    */   }
/*    */ 
/*    */ 
/*    */   public List<ItemStack> func_220076_a(BlockState state, LootContext.Builder builder) {
/* 48 */     List<ItemStack> list = super.func_220076_a(state, builder);
/* 49 */     list.forEach(stack -> stack.func_190920_e(Math.max(1, stack.func_190916_E() / 2)));
/* 50 */     return list;
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 3 ms
	
*/