/*     */ package com.ruby.meshi.block;
/*     */ 
/*     */ import com.ruby.meshi.block.tileentity.CollectorPressurePlateTileEntity;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.BiPredicate;
/*     */ import java.util.function.IntPredicate;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.IntStream;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockState;
/*     */ import net.minecraft.block.ChestBlock;
/*     */ import net.minecraft.block.PressurePlateBlock;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.PlayerEntity;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.container.INamedContainerProvider;
/*     */ import net.minecraft.item.BlockItemUseContext;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.state.BooleanProperty;
/*     */ import net.minecraft.state.IProperty;
/*     */ import net.minecraft.state.StateContainer;
/*     */ import net.minecraft.state.properties.BlockStateProperties;
/*     */ import net.minecraft.stats.Stats;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.Hand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.BlockRayTraceResult;
/*     */ import net.minecraft.world.IBlockReader;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public abstract class CollectionAndDeliveryBase
/*     */   extends PressurePlateBlock
/*     */ {
/*  37 */   public static final BooleanProperty FORCE = BlockStateProperties.field_208180_g;
/*     */ 
/*     */ 
/*     */ 
/*     */   public CollectionAndDeliveryBase(Block.Properties properties, int horizon, int vertical) {
/*  42 */     super(PressurePlateBlock.Sensitivity.EVERYTHING, properties);
/*  43 */     this.horizonSize = horizon;
/*  44 */     this.verticalSize = vertical;
/*  45 */     func_180632_j((BlockState)func_176223_P().func_206870_a((IProperty)FORCE, Boolean.valueOf(false)));
/*     */   }
/*     */ 
/*     */ 
/*     */   public BlockState func_196258_a(BlockItemUseContext context) {
/*  50 */     return (BlockState)super.func_196258_a(context).func_206870_a((IProperty)FORCE, Boolean.valueOf(context.func_195998_g()));
/*     */   }
/*     */ 
/*     */ 
/*     */   protected void func_206840_a(StateContainer.Builder<Block, BlockState> builder) {
/*  55 */     super.func_206840_a(builder);
/*  56 */     builder.func_206894_a(new IProperty[] { (IProperty)FORCE });
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_220051_a(BlockState state, World worldIn, BlockPos pos, PlayerEntity player, Hand handIn, BlockRayTraceResult hit) {
/*  61 */     if (worldIn.field_72995_K) {
/*  62 */       return true;
/*     */     }
/*  64 */     INamedContainerProvider inamedcontainerprovider = func_220052_b(state, worldIn, pos);
/*  65 */     if (inamedcontainerprovider != null) {
/*  66 */       player.func_213829_a(inamedcontainerprovider);
/*  67 */       player.func_71029_a(Stats.field_199092_j.func_199076_b(Stats.field_188063_ac));
/*     */     } 
/*     */     
/*  70 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   public INamedContainerProvider func_220052_b(BlockState state, World world, BlockPos pos) {
/*  76 */     TileEntity tileentity = world.func_175625_s(pos);
/*  77 */     return (tileentity instanceof INamedContainerProvider) ? (INamedContainerProvider)tileentity : null;
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_189539_a(BlockState state, World worldIn, BlockPos pos, int id, int param) {
/*  82 */     super.func_189539_a(state, worldIn, pos, id, param);
/*  83 */     TileEntity tileentity = worldIn.func_175625_s(pos);
/*  84 */     return (tileentity == null) ? false : tileentity.func_145842_c(id, param);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<IInventory> getSurroundingIInventory(World world, BlockPos pos, int horizonSize, int verticalSize) {
/*  99 */     return (Set<IInventory>)BlockPos.func_218281_b(pos.func_177982_a(-horizonSize, 0, -horizonSize), pos.func_177982_a(horizonSize, verticalSize, horizonSize))
/* 100 */       .map(p -> (world.func_180495_p(p).func_177230_c() instanceof ChestBlock) ? ChestBlock.func_220105_a(world.func_180495_p(p), world, p, false) : world.func_175625_s(p))
/* 101 */       .filter(e -> (e instanceof IInventory && !(e instanceof CollectorPressurePlateTileEntity)))
/* 102 */       .map(IInventory.class::cast)
/* 103 */       .collect(Collectors.toSet());
/*     */   }
/*     */ 
/*     */   public List<ItemStack> getSlotList(IInventory inv) {
/* 107 */     return (List<ItemStack>)IntStream.range(0, inv.func_70302_i_())
/* 108 */       .mapToObj(inv::func_70301_a)
/* 109 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_196262_a(BlockState state, World worldIn, BlockPos pos, Entity entityIn) {
/* 114 */     if (!worldIn.field_72995_K && entityIn instanceof PlayerEntity) {
/* 115 */       int i = func_176576_e(state);
/* 116 */       if (i == 0) {
/* 117 */         onPressedSwitch(state, worldIn, pos, (PlayerEntity)entityIn);
/*     */       }
/*     */     } 
/* 120 */     super.func_196262_a(state, worldIn, pos, entityIn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<InventoryEntry> createInventoryEntrys(IInventory targetInventory, List<ItemStack> targetList, Predicate<ItemStack> stackTester, BiPredicate<Integer, ItemStack> slotTester) {
/* 136 */     InventoryEntry.Builder entryBuilder = InventoryEntry.build(targetInventory);
/* 137 */     return (List<InventoryEntry>)IntStream.range(0, targetList.size())
/* 138 */       .mapToObj(slotId -> {
/*     */           ItemStack stack = targetList.get(slotId);
/* 140 */           return (stackTester.test(stack) && slotTester.test(Integer.valueOf(slotId), stack)) ? entryBuilder.create(slotId) : null;
/*     */         
/* 142 */         }).filter(e -> (e != null))
/* 143 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */   public void searchAndInsert(InventoryEntry fromEntry, InventoryEntry toEntry, boolean isEmptyInsert) {
/* 148 */     ItemStack fromStack = fromEntry.getStack();
/* 149 */     int slot = toEntry.getSlot();
/*     */     
/* 151 */     for (int i = 0; i < toEntry.getInventory().func_70302_i_(); i++) {
/* 152 */       if (toEntry.insertStack(fromStack, slot)) {
/*     */         
/* 154 */         fromEntry.getInventory().func_70296_d();
/* 155 */         toEntry.getInventory().func_70296_d();
/*     */       } 
/* 157 */       if (fromStack.func_190926_b()) {
/* 158 */         fromEntry.setStack(ItemStack.field_190927_a);
/*     */         break;
/*     */       } 
/* 161 */       int nextSlot = toEntry.getNextStackableSlot(fromStack, slot);
/* 162 */       if (nextSlot >= 0) {
/* 163 */         slot = nextSlot;
/*     */       }
/* 165 */       else if (isEmptyInsert) {
/*     */         
/* 167 */         nextSlot = toEntry.getNextEmptySlot(slot);
/* 168 */         if (nextSlot >= 0) {
/* 169 */           slot = nextSlot;
/*     */         } else {
/*     */           break;
/*     */         } 
/*     */       } else {
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   public static class InventoryEntry
/*     */     implements Comparable<InventoryEntry>
/*     */   {
/*     */     private final IInventory inventory;
/*     */     
/*     */     private final int slot;
/*     */ 
/*     */     
/*     */     private InventoryEntry(IInventory inventory, int slot) {
/* 189 */       this.inventory = inventory;
/* 190 */       this.slot = slot;
/*     */     }
/*     */ 
/*     */     public IInventory getInventory() {
/* 194 */       return this.inventory;
/*     */     }
/*     */ 
/*     */     public int getSlot() {
/* 198 */       return this.slot;
/*     */     }
/*     */ 
/*     */     public ItemStack getStack() {
/* 202 */       return getInventory().func_70301_a(this.slot);
/*     */     }
/*     */ 
/*     */     public void setStack(ItemStack stack) {
/* 206 */       getInventory().func_70299_a(this.slot, stack);
/*     */     }
/*     */ 
/*     */     public Item getItem() {
/* 210 */       return getStack().func_77973_b();
/*     */     }
/*     */ 
/*     */     public boolean isItemEqual(InventoryEntry entry) {
/* 214 */       return getStack().func_77969_a(entry.getStack());
/*     */     }
/*     */ 
/*     */     public boolean insertStack(ItemStack stack, int slot) {
/* 218 */       if (stack.func_190926_b()) {
/* 219 */         return false;
/*     */       }
/* 221 */       ItemStack inventoryStack = getInventory().func_70301_a(slot);
/*     */       
/* 223 */       if (inventoryStack.func_190926_b()) {
/* 224 */         getInventory().func_70299_a(slot, stack.func_77979_a(getInventory().func_70297_j_()));
/* 225 */         return true;
/*     */       } 
/*     */       
/* 228 */       if (stack.func_77969_a(inventoryStack) && stack.func_77985_e()) {
/*     */         
/* 230 */         int insertCount = getInventory().func_70297_j_() - inventoryStack.func_190916_E();
/* 231 */         if (insertCount > 0) {
/*     */           
/* 233 */           inventoryStack.func_190920_e(inventoryStack.func_190916_E() + stack.func_77979_a(insertCount).func_190916_E());
/* 234 */           return true;
/*     */         } 
/*     */       } 
/*     */       
/* 238 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getNextStackableSlot(ItemStack stack, int baseSlot) {
/* 248 */       return getNextSlot(baseSlot, slot -> {
/*     */             ItemStack inventoryStack = getInventory().func_70301_a(slot);
/* 250 */             return (stack.func_77969_a(inventoryStack) && getInventory().func_70297_j_() - inventoryStack.func_190916_E() > 0);
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getNextEmptySlot(int baseSlot) {
/* 261 */       return getNextSlot(baseSlot, slot -> getInventory().func_70301_a(slot).func_190926_b());
/*     */     }
/*     */ 
/*     */ 
/*     */     private int getNextSlot(int slot, IntPredicate tester) {
/* 266 */       return IntStream.iterate(slot, e -> (e < getInventory().func_70302_i_() - 1) ? (e + 1) : 0)
/* 267 */         .limit(getInventory().func_70302_i_())
/* 268 */         .filter(tester)
/* 269 */         .findFirst()
/* 270 */         .orElse(-1);
/*     */     }
/*     */ 
/*     */ 
/*     */     public int hashCode() {
/* 275 */       int prime = 31;
/* 276 */       int result = 1;
/* 277 */       result = 31 * result + ((this.inventory == null) ? 0 : this.inventory.hashCode());
/* 278 */       result = 31 * result + ((getItem() == null) ? 0 : getItem().hashCode());
/* 279 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */     public boolean equals(Object obj) {
/* 284 */       if (this == obj)
/* 285 */         return true; 
/* 286 */       if (obj == null)
/* 287 */         return false; 
/* 288 */       if (getClass() != obj.getClass())
/* 289 */         return false; 
/* 290 */       InventoryEntry other = (InventoryEntry)obj;
/* 291 */       if (this.inventory == null) {
/* 292 */         if (other.inventory != null)
/* 293 */           return false; 
/* 294 */       } else if (!this.inventory.equals(other.inventory)) {
/* 295 */         return false;
/* 296 */       }  if (getItem() == null) {
/* 297 */         if (other.getItem() != null)
/* 298 */           return false; 
/* 299 */       } else if (!getItem().equals(other.getItem())) {
/* 300 */         return false;
/* 301 */       }  return true;
/*     */     }
/*     */ 
/*     */ 
/*     */     public String toString() {
/* 306 */       return String.format("inv %s:%s , stack : %s", new Object[] { this.inventory.getClass().getSimpleName(), Integer.valueOf(getSlot()), getStack() });
/*     */     }
/*     */ 
/*     */ 
/*     */     public int compareTo(InventoryEntry o) {
/* 311 */       return this.slot - o.slot;
/*     */     }
/*     */ 
/*     */     public static Builder build(IInventory factory) {
/* 315 */       return new Builder(factory);
/*     */     }
/*     */ 
/*     */     public static class Builder
/*     */     {
/*     */       private IInventory inventory;
/*     */       
/*     */       private Builder(IInventory inventory) {
/* 323 */         this.inventory = inventory;
/*     */       }
/*     */ 
/*     */       public CollectionAndDeliveryBase.InventoryEntry create(int slot) {
/* 327 */         return new CollectionAndDeliveryBase.InventoryEntry(this.inventory, slot); } } } public static class Builder { public CollectionAndDeliveryBase.InventoryEntry create(int slot) { return new CollectionAndDeliveryBase.InventoryEntry(this.inventory, slot); }        return new CollectionAndDeliveryBase.InventoryEntry(this.inventory, slot); } } } public static class Builder { public CollectionAndDeliveryBase.InventoryEntry create(int slot) { return new CollectionAndDeliveryBase.InventoryEntry(this.inventory, slot); }
/*     */     
/*     */     private IInventory inventory;
/*     */     private Builder(IInventory inventory) {
/*     */       this.inventory = inventory;
/*     */     } }
/*     */   public boolean hasTileEntity(BlockState state) {
/* 334 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   public TileEntity createTileEntity(BlockState state, IBlockReader world) {
/* 339 */     return (TileEntity)new CollectorPressurePlateTileEntity();
/*     */   }
/*     */   
/*     */   public abstract void onPressedSwitch(BlockState paramBlockState, World paramWorld, BlockPos paramBlockPos, PlayerEntity paramPlayerEntity);
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 23 ms
	
*/