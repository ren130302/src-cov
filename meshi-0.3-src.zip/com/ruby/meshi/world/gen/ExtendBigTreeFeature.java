/*     */ package com.ruby.meshi.world.gen;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.mojang.datafixers.Dynamic;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Random;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import net.minecraft.block.BlockState;
/*     */ import net.minecraft.block.RotatedPillarBlock;
/*     */ import net.minecraft.state.IProperty;
/*     */ import net.minecraft.util.Direction;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.MutableBoundingBox;
/*     */ import net.minecraft.world.IWorldWriter;
/*     */ import net.minecraft.world.gen.IWorldGenerationBaseReader;
/*     */ import net.minecraft.world.gen.IWorldGenerationReader;
/*     */ import net.minecraft.world.gen.feature.AbstractTreeFeature;
/*     */ import net.minecraft.world.gen.feature.NoFeatureConfig;
/*     */ 
/*     */ public class ExtendBigTreeFeature extends AbstractTreeFeature<NoFeatureConfig> {
/*     */   private BlockState log_block;
/*     */   private BlockState leave_block;
/*     */   
/*     */   public ExtendBigTreeFeature setBlocks(BlockState log, BlockState leave) {
/*  28 */     this.log_block = log;
/*  29 */     this.leave_block = leave;
/*  30 */     return this;
/*     */   }
/*     */ 
/*     */   public ExtendBigTreeFeature(Function<Dynamic<?>, ? extends NoFeatureConfig> p_i49918_1_, boolean p_i49918_2_) {
/*  34 */     super(p_i49918_1_, p_i49918_2_);
/*     */   }
/*     */ 
/*     */   private void crossSection(IWorldGenerationReader p_208529_1_, BlockPos p_208529_2_, float p_208529_3_, MutableBoundingBox p_208529_4_, Set<BlockPos> p_208529_5_) {
/*  38 */     int i = (int)(p_208529_3_ + 0.618D);
/*     */     
/*  40 */     for (int j = -i; j <= i; j++) {
/*  41 */       for (int k = -i; k <= i; k++) {
/*  42 */         if (Math.pow(Math.abs(j) + 0.5D, 2.0D) + Math.pow(Math.abs(k) + 0.5D, 2.0D) <= (p_208529_3_ * p_208529_3_)) {
/*  43 */           BlockPos blockpos = p_208529_2_.func_177982_a(j, 0, k);
/*  44 */           if (func_214572_g((IWorldGenerationBaseReader)p_208529_1_, blockpos)) {
/*  45 */             func_208520_a(p_208529_5_, (IWorldWriter)p_208529_1_, blockpos, this.leave_block, p_208529_4_);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   private float treeShape(int p_208527_1_, int p_208527_2_) {
/*  54 */     if (p_208527_2_ < p_208527_1_ * 0.3F) {
/*  55 */       return -1.0F;
/*     */     }
/*  57 */     float f = p_208527_1_ / 2.0F;
/*  58 */     float f1 = f - p_208527_2_;
/*  59 */     float f2 = MathHelper.func_76129_c(f * f - f1 * f1);
/*  60 */     if (f1 == 0.0F) {
/*  61 */       f2 = f;
/*  62 */     } else if (Math.abs(f1) >= f) {
/*  63 */       return 0.0F;
/*     */     } 
/*     */     
/*  66 */     return f2 * 0.5F;
/*     */   }
/*     */ 
/*     */ 
/*     */   private float foliageShape(int y) {
/*  71 */     if (y >= 0 && y < 5) {
/*  72 */       return (y != 0 && y != 4) ? 3.0F : 2.0F;
/*     */     }
/*  74 */     return -1.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */   private void foliageCluster(IWorldGenerationReader p_202393_1_, BlockPos p_202393_2_, MutableBoundingBox p_202393_3_, Set<BlockPos> p_202393_4_) {
/*  79 */     for (int i = 0; i < 5; i++) {
/*  80 */       crossSection(p_202393_1_, p_202393_2_.func_177981_b(i), foliageShape(i), p_202393_3_, p_202393_4_);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   private int makeLimb(Set<BlockPos> p_208523_1_, IWorldGenerationReader p_208523_2_, BlockPos p_208523_3_, BlockPos p_208523_4_, boolean p_208523_5_, MutableBoundingBox p_208523_6_) {
/*  86 */     if (!p_208523_5_ && Objects.equals(p_208523_3_, p_208523_4_)) {
/*  87 */       return -1;
/*     */     }
/*  89 */     BlockPos blockpos = p_208523_4_.func_177982_a(-p_208523_3_.func_177958_n(), -p_208523_3_.func_177956_o(), -p_208523_3_.func_177952_p());
/*  90 */     int i = getGreatestDistance(blockpos);
/*  91 */     float f = blockpos.func_177958_n() / i;
/*  92 */     float f1 = blockpos.func_177956_o() / i;
/*  93 */     float f2 = blockpos.func_177952_p() / i;
/*     */     
/*  95 */     for (int j = 0; j <= i; j++) {
/*  96 */       BlockPos blockpos1 = p_208523_3_.func_177963_a((0.5F + j * f), (0.5F + j * f1), (0.5F + j * f2));
/*  97 */       if (p_208523_5_) {
/*  98 */         func_208520_a(p_208523_1_, (IWorldWriter)p_208523_2_, blockpos1, (BlockState)this.log_block.func_206870_a((IProperty)RotatedPillarBlock.field_176298_M, (Comparable)getLoxAxis(p_208523_3_, blockpos1)), p_208523_6_);
/*     */       }
/* 100 */       else if (!func_214587_a((IWorldGenerationBaseReader)p_208523_2_, blockpos1)) {
/* 101 */         return j;
/*     */       } 
/*     */     } 
/*     */     
/* 105 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int getGreatestDistance(BlockPos posIn) {
/* 113 */     int i = MathHelper.func_76130_a(posIn.func_177958_n());
/* 114 */     int j = MathHelper.func_76130_a(posIn.func_177956_o());
/* 115 */     int k = MathHelper.func_76130_a(posIn.func_177952_p());
/* 116 */     if (k > i && k > j) {
/* 117 */       return k;
/*     */     }
/* 119 */     return (j > i) ? j : i;
/*     */   }
/*     */ 
/*     */ 
/*     */   private Direction.Axis getLoxAxis(BlockPos p_197170_1_, BlockPos p_197170_2_) {
/* 124 */     Direction.Axis direction$axis = Direction.Axis.Y;
/* 125 */     int i = Math.abs(p_197170_2_.func_177958_n() - p_197170_1_.func_177958_n());
/* 126 */     int j = Math.abs(p_197170_2_.func_177952_p() - p_197170_1_.func_177952_p());
/* 127 */     int k = Math.max(i, j);
/* 128 */     if (k > 0) {
/* 129 */       if (i == k) {
/* 130 */         direction$axis = Direction.Axis.X;
/* 131 */       } else if (j == k) {
/* 132 */         direction$axis = Direction.Axis.Z;
/*     */       } 
/*     */     }
/*     */     
/* 136 */     return direction$axis;
/*     */   }
/*     */ 
/*     */   private void makeFoliage(IWorldGenerationReader p_208525_1_, int p_208525_2_, BlockPos p_208525_3_, List<FoliageCoordinates> p_208525_4_, MutableBoundingBox p_208525_5_, Set<BlockPos> p_208525_6_) {
/* 140 */     for (FoliageCoordinates BigTreeBase$foliagecoordinates : p_208525_4_) {
/* 141 */       if (trimBranches(p_208525_2_, BigTreeBase$foliagecoordinates.getBranchBase() - p_208525_3_.func_177956_o())) {
/* 142 */         foliageCluster(p_208525_1_, BigTreeBase$foliagecoordinates, p_208525_5_, p_208525_6_);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   private boolean trimBranches(int p_208522_1_, int p_208522_2_) {
/* 149 */     return (p_208522_2_ >= p_208522_1_ * 0.2D);
/*     */   }
/*     */ 
/*     */   private void makeTrunk(Set<BlockPos> p_208526_1_, IWorldGenerationReader p_208526_2_, BlockPos p_208526_3_, int p_208526_4_, MutableBoundingBox p_208526_5_) {
/* 153 */     makeLimb(p_208526_1_, p_208526_2_, p_208526_3_, p_208526_3_.func_177981_b(p_208526_4_), true, p_208526_5_);
/*     */   }
/*     */ 
/*     */   private void makeBranches(Set<BlockPos> p_208524_1_, IWorldGenerationReader p_208524_2_, int p_208524_3_, BlockPos p_208524_4_, List<FoliageCoordinates> p_208524_5_, MutableBoundingBox p_208524_6_) {
/* 157 */     for (FoliageCoordinates BigTreeBase$foliagecoordinates : p_208524_5_) {
/* 158 */       int i = BigTreeBase$foliagecoordinates.getBranchBase();
/* 159 */       BlockPos blockpos = new BlockPos(p_208524_4_.func_177958_n(), i, p_208524_4_.func_177952_p());
/* 160 */       if (!blockpos.equals(BigTreeBase$foliagecoordinates) && trimBranches(p_208524_3_, i - p_208524_4_.func_177956_o())) {
/* 161 */         makeLimb(p_208524_1_, p_208524_2_, blockpos, BigTreeBase$foliagecoordinates, true, p_208524_6_);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean func_208519_a(Set<BlockPos> changedBlocks, IWorldGenerationReader worldIn, Random rand, BlockPos position, MutableBoundingBox p_208519_5_) {
/* 169 */     Random random = new Random(rand.nextLong());
/* 170 */     int i = checkLocation(changedBlocks, worldIn, position, 5 + random.nextInt(12), p_208519_5_);
/* 171 */     if (i == -1) {
/* 172 */       return false;
/*     */     }
/* 174 */     setDirtAt(worldIn, position.func_177977_b(), position);
/* 175 */     int j = (int)(i * 0.618D);
/* 176 */     if (j >= i) {
/* 177 */       j = i - 1;
/*     */     }
/*     */     
/* 180 */     double d0 = 1.0D;
/* 181 */     int k = (int)(1.382D + Math.pow(1.0D * i / 13.0D, 2.0D));
/* 182 */     if (k < 1) {
/* 183 */       k = 1;
/*     */     }
/*     */     
/* 186 */     int l = position.func_177956_o() + j;
/* 187 */     int i1 = i - 5;
/* 188 */     List<FoliageCoordinates> list = Lists.newArrayList();
/* 189 */     list.add(new FoliageCoordinates(position.func_177981_b(i1), l));
/*     */     
/* 191 */     for (; i1 >= 0; i1--) {
/* 192 */       float f = treeShape(i, i1);
/* 193 */       if (f >= 0.0F) {
/* 194 */         for (int j1 = 0; j1 < k; j1++) {
/* 195 */           double d1 = 1.0D;
/* 196 */           double d2 = 1.0D * f * (random.nextFloat() + 0.328D);
/* 197 */           double d3 = (random.nextFloat() * 2.0F) * Math.PI;
/* 198 */           double d4 = d2 * Math.sin(d3) + 0.5D;
/* 199 */           double d5 = d2 * Math.cos(d3) + 0.5D;
/* 200 */           BlockPos blockpos = position.func_177963_a(d4, (i1 - 1), d5);
/* 201 */           BlockPos blockpos1 = blockpos.func_177981_b(5);
/* 202 */           if (makeLimb(changedBlocks, worldIn, blockpos, blockpos1, false, p_208519_5_) == -1) {
/* 203 */             int k1 = position.func_177958_n() - blockpos.func_177958_n();
/* 204 */             int l1 = position.func_177952_p() - blockpos.func_177952_p();
/* 205 */             double d6 = blockpos.func_177956_o() - Math.sqrt((k1 * k1 + l1 * l1)) * 0.381D;
/* 206 */             int i2 = (d6 > l) ? l : (int)d6;
/* 207 */             BlockPos blockpos2 = new BlockPos(position.func_177958_n(), i2, position.func_177952_p());
/* 208 */             if (makeLimb(changedBlocks, worldIn, blockpos2, blockpos, false, p_208519_5_) == -1) {
/* 209 */               list.add(new FoliageCoordinates(blockpos, blockpos2.func_177956_o()));
/*     */             }
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 216 */     makeFoliage(worldIn, i, position, list, p_208519_5_, changedBlocks);
/* 217 */     makeTrunk(changedBlocks, worldIn, position, j, p_208519_5_);
/* 218 */     makeBranches(changedBlocks, worldIn, i, position, list, p_208519_5_);
/* 219 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   private int checkLocation(Set<BlockPos> p_208528_1_, IWorldGenerationReader p_208528_2_, BlockPos p_208528_3_, int p_208528_4_, MutableBoundingBox p_208528_5_) {
/* 224 */     if (!isSoilOrFarm((IWorldGenerationBaseReader)p_208528_2_, p_208528_3_.func_177977_b(), getSapling())) {
/* 225 */       return -1;
/*     */     }
/* 227 */     int i = makeLimb(p_208528_1_, p_208528_2_, p_208528_3_, p_208528_3_.func_177981_b(p_208528_4_ - 1), false, p_208528_5_);
/* 228 */     if (i == -1) {
/* 229 */       return p_208528_4_;
/*     */     }
/* 231 */     return (i < 6) ? -1 : i;
/*     */   }
/*     */ 
/*     */   static class FoliageCoordinates
/*     */     extends BlockPos
/*     */   {
/*     */     private final int branchBase;
/*     */     
/*     */     public FoliageCoordinates(BlockPos pos, int p_i45635_2_) {
/* 240 */       super(pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p());
/* 241 */       this.branchBase = p_i45635_2_;
/*     */     }
/*     */ 
/*     */     public int getBranchBase() {
/* 245 */       return this.branchBase;
/*     */     }
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 16 ms
	
*/