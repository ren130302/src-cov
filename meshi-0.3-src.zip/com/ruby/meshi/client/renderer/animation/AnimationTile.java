// Warning: No line numbers available in class file
/*  */ package com.ruby.meshi.client.renderer.animation;
/*  */ 
/*  */ import java.util.List;
/*  */ import net.minecraftforge.api.distmarker.Dist;
/*  */ import net.minecraftforge.api.distmarker.OnlyIn;
/*  */ 
/*  */ @OnlyIn(Dist.CLIENT)
/*  */ public interface AnimationTile {
/*  */   @OnlyIn(Dist.CLIENT)
/*  */   List<EntityModelAnimation> getAnimations();
/*  */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 0 ms
	
*/