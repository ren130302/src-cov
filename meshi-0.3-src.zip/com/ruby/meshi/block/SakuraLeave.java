/*    */ package com.ruby.meshi.block;
/*    */ 
/*    */ import com.ruby.meshi.client.paticle.PetalParticle;
/*    */ import com.ruby.meshi.client.paticle.SakuraParticleManager;
/*    */ import com.ruby.meshi.client.paticle.WindManager;
/*    */ import com.ruby.meshi.init.SakuraConfig;
/*    */ import java.util.Arrays;
/*    */ import java.util.Random;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.BlockState;
/*    */ import net.minecraft.block.LeavesBlock;
/*    */ import net.minecraft.item.DyeColor;
/*    */ import net.minecraft.util.BlockRenderLayer;
/*    */ import net.minecraft.util.Direction;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.api.distmarker.Dist;
/*    */ import net.minecraftforge.api.distmarker.OnlyIn;
/*    */ 
/*    */ public class SakuraLeave
/*    */   extends LeavesBlock
/*    */   implements ExtraParticle {
/*    */   private SakuraType type;
/*    */   
/*    */   public SakuraLeave(Block.Properties properties) {
/* 26 */     super(properties);
/* 27 */     this.type = SakuraType.GREEN;
/*    */   }
/*    */ 
/*    */   public SakuraLeave setPetalType(SakuraType type) {
/* 31 */     this.type = type;
/* 32 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */   public void func_196265_a(BlockState state, World worldIn, BlockPos pos, Random random) {
/* 37 */     super.func_196265_a(state, worldIn, pos, random);
/*    */   }
/*    */ 
/*    */ 
/*    */   @OnlyIn(Dist.CLIENT)
/*    */   public void func_180655_c(BlockState stateIn, World worldIn, BlockPos pos, Random rand) {
/* 43 */     super.func_180655_c(stateIn, worldIn, pos, rand);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   @OnlyIn(Dist.CLIENT)
/*    */   public void paticleTick(BlockState stateIn, World worldIn, BlockPos pos, Random rand) {
/* 50 */     if (rand.nextFloat() < (WindManager.isStrongWind() ? 0.1D : 0.05D)) {
/* 51 */       if (worldIn.func_175623_d(pos.func_177977_b())) {
/* 52 */         SakuraParticleManager.addEffect((new PetalParticle(worldIn, (pos.func_177958_n() + getPetalRandomRange(rand)), (pos.func_177956_o() - 0.1F), (pos.func_177952_p() + getPetalRandomRange(rand)))).setPetal(this.type));
/*    */       }
/* 54 */       if (WindManager.isStrongWind()) {
/* 55 */         Direction dir = WindManager.getWindDir();
/* 56 */         if (worldIn.func_175623_d(pos.func_177972_a(dir))) {
/* 57 */           SakuraParticleManager.addEffect((new PetalParticle(worldIn, (pos.func_177958_n() + getPetalRandomRange(rand) + dir.func_82601_c()), (pos.func_177956_o() + getPetalRandomRange(rand)), (pos.func_177952_p() + getPetalRandomRange(rand) + dir.func_82599_e()))).setPetal(this.type));
/*    */         }
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */   float getPetalRandomRange(Random rand) {
/* 64 */     return Math.min(rand.nextFloat() + 0.1F, 0.9F);
/*    */   }
/*    */ 
/*    */ 
/*    */   public BlockRenderLayer func_180664_k() {
/* 69 */     return ((Boolean)SakuraConfig.CLIENT.sakuraFancyRender.get()).booleanValue() ? BlockRenderLayer.CUTOUT_MIPPED : super.func_180664_k();
/*    */   }
/*    */ 
/*    */   public enum SakuraType {
/* 73 */     GREEN(0, 1.0F, DyeColor.GREEN),
/* 74 */     PINK(1, 0.7F, DyeColor.PINK),
/* 75 */     RED(2, 1.2F, DyeColor.RED),
/* 76 */     YELLOW(3, 1.2F, DyeColor.YELLOW);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     SakuraType(int id, float mass, DyeColor color) {
/* 83 */       this.ID = id;
/* 84 */       this.MASS = mass;
/* 85 */       this.COLOR = color;
/*    */     }
/*    */ 
/*    */     public static SakuraType getPetal(DyeColor color) {
/* 89 */       return Arrays.<SakuraType>stream(values()).filter(t -> (t.COLOR == color)).findFirst().orElse(PINK);
/*    */     }
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 8 ms
	
*/