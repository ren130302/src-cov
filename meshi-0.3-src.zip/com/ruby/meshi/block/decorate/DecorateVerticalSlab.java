/*     */ package com.ruby.meshi.block.decorate;
/*     */ 
/*     */ import com.ruby.meshi.block.CustomItemBlock;
/*     */ import com.ruby.meshi.client.CreativeTab;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockState;
/*     */ import net.minecraft.block.IWaterLoggable;
/*     */ import net.minecraft.entity.EntityType;
/*     */ import net.minecraft.fluid.Fluid;
/*     */ import net.minecraft.fluid.Fluids;
/*     */ import net.minecraft.fluid.IFluidState;
/*     */ import net.minecraft.item.BlockItemUseContext;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.pathfinding.PathType;
/*     */ import net.minecraft.state.BooleanProperty;
/*     */ import net.minecraft.state.DirectionProperty;
/*     */ import net.minecraft.state.IProperty;
/*     */ import net.minecraft.state.StateContainer;
/*     */ import net.minecraft.state.properties.BlockStateProperties;
/*     */ import net.minecraft.tags.FluidTags;
/*     */ import net.minecraft.util.Direction;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.shapes.ISelectionContext;
/*     */ import net.minecraft.util.math.shapes.VoxelShape;
/*     */ import net.minecraft.util.math.shapes.VoxelShapes;
/*     */ import net.minecraft.world.IBlockReader;
/*     */ import net.minecraft.world.IWorld;
/*     */ import net.minecraft.world.IWorldReader;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class DecorateVerticalSlab extends Block implements CustomItemBlock, IWaterLoggable {
/*  33 */   public static final BooleanProperty WATERLOGGED = BlockStateProperties.field_208198_y;
/*  34 */   public static final DirectionProperty FACING = BlockStateProperties.field_208155_H;
/*  35 */   public static final BooleanProperty DOUBLE = BooleanProperty.func_177716_a("double");
/*     */ 
/*  37 */   public static final VoxelShape UP_AABB = Block.func_208617_a(0.0D, 8.0D, 0.0D, 16.0D, 16.0D, 16.0D);
/*  38 */   public static final VoxelShape DOWN_AABB = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 8.0D, 16.0D);
/*  39 */   public static final VoxelShape EAST_AABB = Block.func_208617_a(8.0D, 0.0D, 0.0D, 16.0D, 16.0D, 16.0D);
/*  40 */   public static final VoxelShape NORTH_AABB = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 16.0D, 8.0D);
/*  41 */   public static final VoxelShape SOUTH_AABB = Block.func_208617_a(0.0D, 0.0D, 8.0D, 16.0D, 16.0D, 16.0D);
/*  42 */   public static final VoxelShape WEST_AABB = Block.func_208617_a(0.0D, 0.0D, 0.0D, 8.0D, 16.0D, 16.0D);
/*     */ 
/*     */   public DecorateVerticalSlab(Block.Properties properties) {
/*  45 */     super(properties);
/*  46 */     func_180632_j((BlockState)((BlockState)((BlockState)func_176223_P().func_206870_a((IProperty)FACING, (Comparable)Direction.NORTH)).func_206870_a((IProperty)DOUBLE, Boolean.valueOf(false))).func_206870_a((IProperty)WATERLOGGED, Boolean.valueOf(false)));
/*     */   }
/*     */ 
/*     */ 
/*     */   public BlockState func_196258_a(BlockItemUseContext context) {
/*  51 */     BlockPos blockpos = context.func_195995_a();
/*  52 */     BlockState blockstate = super.func_196258_a(context);
/*     */     
/*  54 */     World world = context.func_195991_k();
/*  55 */     Direction direction = context.func_196000_l().func_176734_d();
/*     */     
/*  57 */     BlockState contextState = context.func_195991_k().func_180495_p(blockpos);
/*     */     
/*  59 */     if (contextState.func_177230_c() == this) {
/*  60 */       return (BlockState)((BlockState)contextState.func_206870_a((IProperty)DOUBLE, Boolean.valueOf(true))).func_206870_a((IProperty)WATERLOGGED, Boolean.valueOf(false));
/*     */     }
/*     */     
/*  63 */     IFluidState ifluidstate = context.func_195991_k().func_204610_c(blockpos);
/*  64 */     blockstate = (BlockState)((BlockState)((BlockState)blockstate.func_206870_a((IProperty)FACING, (Comparable)direction)).func_206870_a((IProperty)DOUBLE, Boolean.valueOf(false))).func_206870_a((IProperty)WATERLOGGED, Boolean.valueOf((ifluidstate.func_206886_c() == Fluids.field_204546_a)));
/*  65 */     if (blockstate.func_196955_c((IWorldReader)world, blockpos)) {
/*  66 */       return blockstate;
/*     */     }
/*     */     
/*  69 */     return blockstate;
/*     */   }
/*     */ 
/*     */   public boolean func_196253_a(BlockState state, BlockItemUseContext useContext) {
/*  73 */     ItemStack itemstack = useContext.func_195996_i();
/*  74 */     if (!((Boolean)state.func_177229_b((IProperty)DOUBLE)).booleanValue() && itemstack.func_77973_b() == func_199767_j()) {
/*  75 */       if (useContext.func_196012_c()) {
/*  76 */         boolean flag = ((useContext.func_221532_j()).field_72448_b - useContext.func_195995_a().func_177956_o() > 0.5D);
/*  77 */         Direction direction = useContext.func_196000_l().func_176734_d();
/*  78 */         return (!((Boolean)state.func_177229_b((IProperty)DOUBLE)).booleanValue() && direction == state.func_177229_b((IProperty)FACING));
/*     */       } 
/*  80 */       return true;
/*     */     } 
/*     */     
/*  83 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public VoxelShape func_220053_a(BlockState state, IBlockReader worldIn, BlockPos pos, ISelectionContext context) {
/*  90 */     if (((Boolean)state.func_177229_b((IProperty)DOUBLE)).booleanValue()) {
/*  91 */       return VoxelShapes.func_197868_b();
/*     */     }
/*  93 */     switch ((Direction)state.func_177229_b((IProperty)FACING)) {
/*     */       case LAND:
/*  95 */         return UP_AABB;
/*     */       case WATER:
/*  97 */         return DOWN_AABB;
/*     */       case AIR:
/*  99 */         return EAST_AABB;
/*     */       case null:
/* 101 */         return NORTH_AABB;
/*     */       case null:
/* 103 */         return SOUTH_AABB;
/*     */       case null:
/* 105 */         return WEST_AABB;
/*     */     } 
/* 107 */     return VoxelShapes.func_197868_b();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean func_220067_a(BlockState state, IBlockReader worldIn, BlockPos pos, EntityType<?> type) {
/* 113 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   protected void func_206840_a(StateContainer.Builder<Block, BlockState> builder) {
/* 118 */     super.func_206840_a(builder);
/* 119 */     builder.func_206894_a(new IProperty[] { (IProperty)FACING, (IProperty)DOUBLE, (IProperty)WATERLOGGED });
/*     */   }
/*     */ 
/*     */ 
/*     */   public Item.Properties getProperty(Item.Properties prop) {
/* 124 */     return prop.func_200916_a(CreativeTab.DECO_GROUP);
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_220074_n(BlockState state) {
/* 129 */     return !((Boolean)state.func_177229_b((IProperty)DOUBLE)).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   public IFluidState func_204507_t(BlockState state) {
/* 134 */     return ((Boolean)state.func_177229_b((IProperty)WATERLOGGED)).booleanValue() ? Fluids.field_204546_a.func_207204_a(false) : super.func_204507_t(state);
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_204509_a(IWorld worldIn, BlockPos pos, BlockState state, IFluidState fluidStateIn) {
/* 139 */     return !((Boolean)state.func_177229_b((IProperty)DOUBLE)).booleanValue() ? super.func_204509_a(worldIn, pos, state, fluidStateIn) : false;
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_204510_a(IBlockReader worldIn, BlockPos pos, BlockState state, Fluid fluidIn) {
/* 144 */     return !((Boolean)state.func_177229_b((IProperty)DOUBLE)).booleanValue() ? super.func_204510_a(worldIn, pos, state, fluidIn) : false;
/*     */   }
/*     */ 
/*     */ 
/*     */   public BlockState func_196271_a(BlockState stateIn, Direction facing, BlockState facingState, IWorld worldIn, BlockPos currentPos, BlockPos facingPos) {
/* 149 */     if (((Boolean)stateIn.func_177229_b((IProperty)WATERLOGGED)).booleanValue()) {
/* 150 */       worldIn.func_205219_F_().func_205360_a(currentPos, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a((IWorldReader)worldIn));
/*     */     }
/*     */     
/* 153 */     return super.func_196271_a(stateIn, facing, facingState, worldIn, currentPos, facingPos);
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_196266_a(BlockState state, IBlockReader worldIn, BlockPos pos, PathType type) {
/* 158 */     switch (type) {
/*     */       case LAND:
/* 160 */         return false;
/*     */       case WATER:
/* 162 */         return worldIn.func_204610_c(pos).func_206884_a(FluidTags.field_206959_a);
/*     */       case AIR:
/* 164 */         return false;
/*     */     } 
/* 166 */     return false;
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 13 ms
	
*/