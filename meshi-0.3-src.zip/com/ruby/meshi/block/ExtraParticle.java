package com.ruby.meshi.block;

import java.util.Random;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public interface ExtraParticle {
   @OnlyIn(Dist.CLIENT)
   void paticleTick(BlockState var1, World var2, BlockPos var3, Random var4);
}