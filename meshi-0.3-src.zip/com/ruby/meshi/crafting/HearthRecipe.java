/*     */ package com.ruby.meshi.crafting;
/*     */ 
/*     */ import com.google.common.annotations.VisibleForTesting;
/*     */ import com.google.common.collect.Maps;
/*     */ import com.google.common.collect.Sets;
/*     */ import com.google.gson.JsonArray;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonParseException;
/*     */ import com.google.gson.JsonSyntaxException;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.crafting.IRecipe;
/*     */ import net.minecraft.item.crafting.IRecipeSerializer;
/*     */ import net.minecraft.item.crafting.IRecipeType;
/*     */ import net.minecraft.item.crafting.Ingredient;
/*     */ import net.minecraft.nbt.CompoundNBT;
/*     */ import net.minecraft.network.PacketBuffer;
/*     */ import net.minecraft.util.JSONUtils;
/*     */ import net.minecraft.util.NonNullList;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.registry.Registry;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.crafting.CraftingHelper;
/*     */ import net.minecraftforge.common.crafting.IShapedRecipe;
/*     */ import net.minecraftforge.registries.ForgeRegistryEntry;
/*     */ 
/*     */ public class HearthRecipe implements IShapedRecipe<IInventory>, NonLockRecipe, CookingTimerRecipe {
/*     */   public static final IRecipeType<HearthRecipe> TYPE;
/*     */   
/*     */   static {
/*  35 */     final ResourceLocation key = HiganRecipeSerializer.HEARTH.getRegistryName();
/*  36 */     TYPE = (IRecipeType<HearthRecipe>)Registry.func_218322_a(Registry.field_218367_H, key, new IRecipeType<HearthRecipe>()
/*     */         {
/*     */           public String toString() {
/*  39 */             return key.toString();
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HearthRecipe(ResourceLocation idIn, String groupIn, int recipeWidthIn, int recipeHeightIn, NonNullList<Ingredient> recipeItemsIn, ItemStack recipeOutputIn, int time) {
/*  57 */     this.id = idIn;
/*  58 */     this.group = groupIn;
/*  59 */     this.recipeWidth = recipeWidthIn;
/*  60 */     this.recipeHeight = recipeHeightIn;
/*  61 */     this.recipeItems = recipeItemsIn;
/*  62 */     this.recipeOutput = recipeOutputIn;
/*  63 */     this.cookingTime = time;
/*     */   }
/*     */ 
/*     */ 
/*     */   public ResourceLocation func_199560_c() {
/*  68 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */   public String func_193358_e() {
/*  73 */     return this.group;
/*     */   }
/*     */ 
/*     */ 
/*     */   public ItemStack func_77571_b() {
/*  78 */     return this.recipeOutput;
/*     */   }
/*     */ 
/*     */ 
/*     */   public NonNullList<Ingredient> func_192400_c() {
/*  83 */     return this.recipeItems;
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_194133_a(int width, int height) {
/*  88 */     return (width >= this.recipeWidth && height >= this.recipeHeight);
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_77569_a(IInventory inv, World worldIn) {
/*  93 */     for (int i = 0; i <= 3 - this.recipeWidth; i++) {
/*  94 */       for (int j = 0; j <= 3 - this.recipeHeight; j++) {
/*  95 */         if (checkMatch(inv, i, j, true)) {
/*  96 */           return true;
/*     */         }
/*     */         
/*  99 */         if (checkMatch(inv, i, j, false)) {
/* 100 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 105 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean checkMatch(IInventory craftingInventory, int p_77573_2_, int p_77573_3_, boolean p_77573_4_) {
/* 109 */     for (int i = 0; i < 3; i++) {
/* 110 */       for (int j = 0; j < 3; j++) {
/* 111 */         int k = i - p_77573_2_;
/* 112 */         int l = j - p_77573_3_;
/* 113 */         Ingredient ingredient = Ingredient.field_193370_a;
/* 114 */         if (k >= 0 && l >= 0 && k < this.recipeWidth && l < this.recipeHeight) {
/* 115 */           if (p_77573_4_) {
/* 116 */             ingredient = (Ingredient)this.recipeItems.get(this.recipeWidth - k - 1 + l * this.recipeWidth);
/*     */           } else {
/* 118 */             ingredient = (Ingredient)this.recipeItems.get(k + l * this.recipeWidth);
/*     */           } 
/*     */         }
/*     */         
/* 122 */         if (!ingredient.test(craftingInventory.func_70301_a(i + j * 3 + 1))) {
/* 123 */           return false;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 128 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   public ItemStack func_77572_b(IInventory inv) {
/* 133 */     return func_77571_b().func_77946_l();
/*     */   }
/*     */ 
/*     */   public int getWidth() {
/* 137 */     return this.recipeWidth;
/*     */   }
/*     */ 
/*     */   public int getHeight() {
/* 141 */     return this.recipeHeight;
/*     */   }
/*     */ 
/*     */ 
/*     */   public int getRecipeWidth() {
/* 146 */     return this.recipeWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */   public int getRecipeHeight() {
/* 151 */     return this.recipeHeight;
/*     */   }
/*     */ 
/*     */   private static NonNullList<Ingredient> deserializeIngredients(String[] pattern, Map<String, Ingredient> keys, int patternWidth, int patternHeight) {
/* 155 */     NonNullList<Ingredient> nonnulllist = NonNullList.func_191197_a(patternWidth * patternHeight, Ingredient.field_193370_a);
/* 156 */     Set<String> set = Sets.newHashSet(keys.keySet());
/* 157 */     set.remove(" ");
/*     */     
/* 159 */     for (int i = 0; i < pattern.length; i++) {
/* 160 */       for (int j = 0; j < pattern[i].length(); j++) {
/* 161 */         String s = pattern[i].substring(j, j + 1);
/* 162 */         Ingredient ingredient = keys.get(s);
/* 163 */         if (ingredient == null) {
/* 164 */           throw new JsonSyntaxException("Pattern references symbol '" + s + "' but it's not defined in the key");
/*     */         }
/*     */         
/* 167 */         set.remove(s);
/* 168 */         nonnulllist.set(j + patternWidth * i, ingredient);
/*     */       } 
/*     */     } 
/*     */     
/* 172 */     if (!set.isEmpty()) {
/* 173 */       throw new JsonSyntaxException("Key defines symbols that aren't used in pattern: " + set);
/*     */     }
/* 175 */     return nonnulllist;
/*     */   }
/*     */ 
/*     */ 
/*     */   @VisibleForTesting
/*     */   static String[] shrink(String... toShrink) {
/* 181 */     int i = Integer.MAX_VALUE;
/* 182 */     int j = 0;
/* 183 */     int k = 0;
/* 184 */     int l = 0;
/*     */     
/* 186 */     for (int i1 = 0; i1 < toShrink.length; i1++) {
/* 187 */       String s = toShrink[i1];
/* 188 */       i = Math.min(i, firstNonSpace(s));
/* 189 */       int j1 = lastNonSpace(s);
/* 190 */       j = Math.max(j, j1);
/* 191 */       if (j1 < 0) {
/* 192 */         if (k == i1) {
/* 193 */           k++;
/*     */         }
/*     */         
/* 196 */         l++;
/*     */       } else {
/* 198 */         l = 0;
/*     */       } 
/*     */     } 
/*     */     
/* 202 */     if (toShrink.length == l) {
/* 203 */       return new String[0];
/*     */     }
/* 205 */     String[] astring = new String[toShrink.length - l - k];
/*     */     
/* 207 */     for (int k1 = 0; k1 < astring.length; k1++) {
/* 208 */       astring[k1] = toShrink[k1 + k].substring(i, j + 1);
/*     */     }
/*     */     
/* 211 */     return astring;
/*     */   }
/*     */ 
/*     */ 
/*     */   private static int firstNonSpace(String str) {
/*     */     int i;
/* 217 */     for (i = 0; i < str.length() && str.charAt(i) == ' '; i++);
/*     */ 
/*     */ 
/*     */     
/* 221 */     return i;
/*     */   }
/*     */ 
/*     */   private static int lastNonSpace(String str) {
/*     */     int i;
/* 226 */     for (i = str.length() - 1; i >= 0 && str.charAt(i) == ' '; i--);
/*     */ 
/*     */ 
/*     */     
/* 230 */     return i;
/*     */   }
/*     */ 
/*     */   private static String[] patternFromJson(JsonArray jsonArr) {
/* 234 */     String[] astring = new String[jsonArr.size()];
/* 235 */     if (astring.length > 3)
/* 236 */       throw new JsonSyntaxException("Invalid pattern: too many rows, 3 is maximum"); 
/* 237 */     if (astring.length == 0) {
/* 238 */       throw new JsonSyntaxException("Invalid pattern: empty pattern not allowed");
/*     */     }
/* 240 */     for (int i = 0; i < astring.length; i++) {
/* 241 */       String s = JSONUtils.func_151206_a(jsonArr.get(i), "pattern[" + i + "]");
/* 242 */       if (s.length() > 3) {
/* 243 */         throw new JsonSyntaxException("Invalid pattern: too many columns, 3 is maximum");
/*     */       }
/*     */       
/* 246 */       if (i > 0 && astring[0].length() != s.length()) {
/* 247 */         throw new JsonSyntaxException("Invalid pattern: each row must be the same width");
/*     */       }
/*     */       
/* 250 */       astring[i] = s;
/*     */     } 
/*     */     
/* 253 */     return astring;
/*     */   }
/*     */ 
/*     */ 
/*     */   private static Map<String, Ingredient> deserializeKey(JsonObject json) {
/* 258 */     Map<String, Ingredient> map = Maps.newHashMap();
/*     */     
/* 260 */     for (Map.Entry<String, JsonElement> entry : (Iterable<Map.Entry<String, JsonElement>>)json.entrySet()) {
/* 261 */       if (((String)entry.getKey()).length() != 1) {
/* 262 */         throw new JsonSyntaxException("Invalid key entry: '" + (String)entry.getKey() + "' is an invalid symbol (must be 1 character only).");
/*     */       }
/*     */       
/* 265 */       if (" ".equals(entry.getKey())) {
/* 266 */         throw new JsonSyntaxException("Invalid key entry: ' ' is a reserved symbol.");
/*     */       }
/*     */       
/* 269 */       map.put(entry.getKey(), Ingredient.func_199802_a(entry.getValue()));
/*     */     } 
/*     */     
/* 272 */     map.put(" ", Ingredient.field_193370_a);
/* 273 */     return map;
/*     */   }
/*     */ 
/*     */   public static ItemStack deserializeItem(JsonObject p_199798_0_) {
/* 277 */     String s = JSONUtils.func_151200_h(p_199798_0_, "item");
/* 278 */     Item item = (Item)Registry.field_212630_s.func_218349_b(new ResourceLocation(s)).orElseThrow(() -> new JsonSyntaxException("Unknown item '" + s + "'"));
/*     */ 
/*     */     
/* 281 */     if (p_199798_0_.has("data")) {
/* 282 */       throw new JsonParseException("Disallowed data tag found");
/*     */     }
/* 284 */     int i = JSONUtils.func_151208_a(p_199798_0_, "count", 1);
/* 285 */     return CraftingHelper.getItemStack(p_199798_0_, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   public IRecipeSerializer<?> func_199559_b() {
/* 291 */     return HiganRecipeSerializer.HEARTH;
/*     */   }
/*     */ 
/*     */ 
/*     */   public IRecipeType<?> func_222127_g() {
/* 296 */     return TYPE;
/*     */   }
/*     */ 
/*     */ 
/*     */   public int getCookTime() {
/* 301 */     return this.cookingTime;
/*     */   }
/*     */ 
/*     */   private static CompoundNBT patternNBTFromJson(JsonArray jsonArr, CompoundNBT nbt) {
/* 305 */     if (jsonArr.size() == 0) {
/* 306 */       throw new JsonSyntaxException("Invalid pattern: empty pattern not allowed");
/*     */     }
/* 308 */     for (int i = 0; i < jsonArr.size(); i++) {
/* 309 */       String s = JSONUtils.func_151206_a(jsonArr.get(i), "nbt[" + i + "]");
/* 310 */       String[] tmp = s.split(":");
/* 311 */       if (tmp.length == 2) {
/* 312 */         if (tmp[1].matches("\\d+")) {
/* 313 */           nbt.func_74768_a(tmp[0], Integer.parseInt(tmp[1]));
/* 314 */         } else if (tmp[1].equalsIgnoreCase("true") || tmp[1].equalsIgnoreCase("false")) {
/* 315 */           nbt.func_74757_a(tmp[0], Boolean.parseBoolean(tmp[1]));
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 320 */     return nbt;
/*     */   }
/*     */ 
/*     */   public static class Serializer
/*     */     extends ForgeRegistryEntry<IRecipeSerializer<?>>
/*     */     implements IRecipeSerializer<HearthRecipe>
/*     */   {
/*     */     public HearthRecipe read(ResourceLocation recipeId, JsonObject json) {
/* 328 */       String s = JSONUtils.func_151219_a(json, "group", "");
/* 329 */       Map<String, Ingredient> map = HearthRecipe.deserializeKey(JSONUtils.func_152754_s(json, "key"));
/* 330 */       String[] astring = HearthRecipe.shrink(HearthRecipe.patternFromJson(JSONUtils.func_151214_t(json, "pattern")));
/* 331 */       int i = astring[0].length();
/* 332 */       int j = astring.length;
/* 333 */       NonNullList<Ingredient> nonnulllist = HearthRecipe.deserializeIngredients(astring, map, i, j);
/* 334 */       ItemStack itemstack = HearthRecipe.deserializeItem(JSONUtils.func_152754_s(json, "result"));
/* 335 */       int time = JSONUtils.func_151208_a(json, "cookingtime", 200);
/* 336 */       if (JSONUtils.func_151202_d(json, "nbt")) {
/* 337 */         HearthRecipe.patternNBTFromJson(JSONUtils.func_151214_t(json, "nbt"), itemstack.func_190925_c("BlockEntityTag"));
/*     */       }
/*     */       
/* 340 */       return new HearthRecipe(recipeId, s, i, j, nonnulllist, itemstack, time);
/*     */     }
/*     */ 
/*     */ 
/*     */     public HearthRecipe read(ResourceLocation recipeId, PacketBuffer buffer) {
/* 345 */       int i = buffer.func_150792_a();
/* 346 */       int j = buffer.func_150792_a();
/* 347 */       String s = buffer.func_150789_c(32767);
/* 348 */       NonNullList<Ingredient> nonnulllist = NonNullList.func_191197_a(i * j, Ingredient.field_193370_a);
/*     */       
/* 350 */       for (int k = 0; k < nonnulllist.size(); k++) {
/* 351 */         nonnulllist.set(k, Ingredient.func_199566_b(buffer));
/*     */       }
/*     */       
/* 354 */       ItemStack itemstack = buffer.func_150791_c();
/* 355 */       int time = buffer.func_150792_a();
/* 356 */       return new HearthRecipe(recipeId, s, i, j, nonnulllist, itemstack, time);
/*     */     }
/*     */ 
/*     */ 
/*     */     public void write(PacketBuffer buffer, HearthRecipe recipe) {
/* 361 */       buffer.func_150787_b(recipe.recipeWidth);
/* 362 */       buffer.func_150787_b(recipe.recipeHeight);
/* 363 */       buffer.func_180714_a(recipe.group);
/*     */       
/* 365 */       for (Ingredient ingredient : recipe.recipeItems) {
/* 366 */         ingredient.func_199564_a(buffer);
/*     */       }
/*     */       
/* 369 */       buffer.func_150788_a(recipe.recipeOutput);
/* 370 */       buffer.func_150787_b(recipe.cookingTime);
/*     */     }
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 18 ms
	
*/