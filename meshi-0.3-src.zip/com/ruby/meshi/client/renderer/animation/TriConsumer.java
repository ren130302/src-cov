/*    */ package com.ruby.meshi.client.renderer.animation;
/*    */ 
/*    */ import java.util.Objects;
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface TriConsumer<T, U, V> {
/*    */   void accept(T paramT, U paramU, V paramV);
/*    */   
/*    */   default TriConsumer<T, U, V> andThen(TriConsumer<? super T, ? super U, ? super V> after) {
/* 10 */     Objects.requireNonNull(after);
/*    */     
/* 12 */     return (l, r, v) -> {
/*    */         accept((T)l, (U)r, (V)v);
/*    */         after.accept(l, r, v);
/*    */       };
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 1 ms
	
*/