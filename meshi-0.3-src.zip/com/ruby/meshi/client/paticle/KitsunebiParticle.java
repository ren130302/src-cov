/*    */ package com.ruby.meshi.client.paticle;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.particle.IParticleRenderType;
/*    */ import net.minecraft.client.particle.SpriteTexturedParticle;
/*    */ import net.minecraft.client.renderer.ActiveRenderInfo;
/*    */ import net.minecraft.client.renderer.BufferBuilder;
/*    */ import net.minecraft.util.IItemProvider;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.util.math.MathHelper;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class KitsunebiParticle extends SpriteTexturedParticle {
/* 14 */   private float yRotate = 0.0F;
/*    */ 
/*    */   public KitsunebiParticle(World world, double xCoordIn, double yCoordIn, double zCoordIn, IItemProvider renderItem) {
/* 17 */     super(world, xCoordIn, yCoordIn, zCoordIn);
/* 18 */     func_217567_a(Minecraft.func_71410_x().func_175599_af().func_175037_a().func_199934_a(renderItem));
/* 19 */     this.field_70545_g = 0.0F;
/* 20 */     this.field_70547_e = 60;
/* 21 */     this.field_190017_n = false;
/*    */   }
/*    */ 
/*    */   public KitsunebiParticle setHorizontal() {
/* 25 */     this.yRotate = 90.0F;
/* 26 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */   public void func_189213_a() {
/* 31 */     if (this.field_187122_b != null && this.field_187122_b.func_175623_d(new BlockPos(this.field_187126_f, this.field_187127_g, this.field_187128_h))) {
/* 32 */       func_187112_i();
/*    */     }
/* 34 */     super.func_189213_a();
/*    */   }
/*    */ 
/*    */ 
/*    */   public void func_180434_a(BufferBuilder buffer, ActiveRenderInfo entityIn, float partialTicks, float rotationX, float rotationZ, float rotationYZ, float rotationXY, float rotationXZ) {
/* 39 */     rotationZ = (this.yRotate != 0.0F) ? MathHelper.func_76134_b(this.yRotate * 0.017453292F) : rotationZ;
/* 40 */     super.func_180434_a(buffer, entityIn, partialTicks, rotationX, rotationZ, rotationYZ, rotationXY, rotationXZ);
/*    */   }
/*    */ 
/*    */ 
/*    */   public IParticleRenderType func_217558_b() {
/* 45 */     return IParticleRenderType.field_217601_a;
/*    */   }
/*    */ 
/*    */ 
/*    */   public float func_217561_b(float p_217561_1_) {
/* 50 */     return 0.5F;
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 4 ms
	
*/