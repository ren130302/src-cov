/*     */ package com.ruby.meshi.block;
/*     */ 
/*     */ import com.ruby.meshi.block.tileentity.MiniatureTileEntity;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockRenderType;
/*     */ import net.minecraft.block.BlockState;
/*     */ import net.minecraft.block.CropsBlock;
/*     */ import net.minecraft.block.DirectionalBlock;
/*     */ import net.minecraft.block.IWaterLoggable;
/*     */ import net.minecraft.block.RedstoneTorchBlock;
/*     */ import net.minecraft.block.material.PushReaction;
/*     */ import net.minecraft.entity.player.PlayerEntity;
/*     */ import net.minecraft.fluid.Fluid;
/*     */ import net.minecraft.fluid.Fluids;
/*     */ import net.minecraft.item.BlockItem;
/*     */ import net.minecraft.item.BlockItemUseContext;
/*     */ import net.minecraft.item.BucketItem;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.ItemUseContext;
/*     */ import net.minecraft.item.Items;
/*     */ import net.minecraft.pathfinding.PathType;
/*     */ import net.minecraft.state.BooleanProperty;
/*     */ import net.minecraft.state.IProperty;
/*     */ import net.minecraft.state.StateContainer;
/*     */ import net.minecraft.state.properties.BlockStateProperties;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.ActionResultType;
/*     */ import net.minecraft.util.BlockRenderLayer;
/*     */ import net.minecraft.util.Direction;
/*     */ import net.minecraft.util.Hand;
/*     */ import net.minecraft.util.IItemProvider;
/*     */ import net.minecraft.util.Rotation;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.BlockRayTraceResult;
/*     */ import net.minecraft.util.math.RayTraceResult;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.shapes.ISelectionContext;
/*     */ import net.minecraft.util.math.shapes.VoxelShape;
/*     */ import net.minecraft.util.math.shapes.VoxelShapes;
/*     */ import net.minecraft.world.IBlockReader;
/*     */ import net.minecraft.world.IWorld;
/*     */ import net.minecraft.world.IWorldReader;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.storage.loot.LootContext;
/*     */ import net.minecraft.world.storage.loot.LootParameters;
/*     */ 
/*     */ 
/*     */ public class Miniature
/*     */   extends DirectionalBlock
/*     */ {
/*  54 */   public static final VoxelShape UP_AABB = Block.func_208617_a(0.0D, 15.9D, 0.0D, 16.0D, 16.0D, 16.0D);
/*  55 */   public static final VoxelShape DOWN_AABB = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 0.1D, 16.0D);
/*  56 */   public static final VoxelShape EAST_AABB = Block.func_208617_a(15.9D, 0.0D, 0.0D, 16.0D, 16.0D, 16.0D);
/*  57 */   public static final VoxelShape NORTH_AABB = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 16.0D, 0.1D);
/*  58 */   public static final VoxelShape SOUTH_AABB = Block.func_208617_a(0.0D, 0.0D, 15.9D, 16.0D, 16.0D, 16.0D);
/*  59 */   public static final VoxelShape WEST_AABB = Block.func_208617_a(0.0D, 0.0D, 0.0D, 0.1D, 16.0D, 16.0D);
/*  60 */   public VoxelShape[][][] shapes = makeShapes(getSize());
/*     */ 
/*  62 */   public static final BooleanProperty ENABLED = BlockStateProperties.field_208180_g;
/*     */ 
/*     */ 
/*     */   public Miniature(Block.Properties properties) {
/*  66 */     super(properties);
/*  67 */     func_180632_j((BlockState)((BlockState)func_176223_P().func_206870_a((IProperty)field_176387_N, (Comparable)Direction.NORTH)).func_206870_a((IProperty)ENABLED, Boolean.valueOf(false)));
/*     */   }
/*     */ 
/*     */   int getSize() {
/*  71 */     return 8;
/*     */   }
/*     */ 
/*     */   private VoxelShape[][][] makeShapes(int size) {
/*  75 */     VoxelShape[][][] shapes = new VoxelShape[size][size][size];
/*     */     
/*  77 */     float shapeOffset = 16.0F * 1.0F / size;
/*  78 */     for (int i = 0; i < size; i++) {
/*  79 */       double minX = (i * shapeOffset);
/*  80 */       for (int j = 0; j < size; j++) {
/*  81 */         double minY = (j * shapeOffset);
/*  82 */         for (int k = 0; k < size; k++) {
/*  83 */           double minZ = (k * shapeOffset);
/*  84 */           shapes[i][j][k] = Block.func_208617_a(minX, minY, minZ, minX + shapeOffset, minY + shapeOffset, minZ + shapeOffset);
/*     */         } 
/*     */       } 
/*     */     } 
/*  88 */     return shapes;
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_220051_a(BlockState state, World worldIn, BlockPos pos, PlayerEntity player, Hand handIn, BlockRayTraceResult hit) {
/*  93 */     if (!worldIn.field_72995_K) {
/*  94 */       TileEntity te = worldIn.func_175625_s(pos);
/*  95 */       boolean isUpdated = false;
/*  96 */       if (te != null && te instanceof MiniatureTileEntity) {
/*  97 */         MiniatureTileEntity mini = (MiniatureTileEntity)te;
/*  98 */         ItemStack stack = player.func_184586_b(handIn);
/*  99 */         int size = (getSize() == mini.getSize()) ? getSize() : mini.getSize();
/*     */         
/* 101 */         BlockPos innerTargetPos = calcHitPos(pos, hit.func_216347_e(), hit.func_216354_b().func_176734_d(), size);
/* 102 */         BlockPos innerHitPos = calcHitPos(pos, hit.func_216347_e(), hit.func_216354_b(), size);
/*     */ 
/*     */         
/* 105 */         if (!stack.func_190926_b()) {
/*     */           
/* 107 */           ItemStack copyStack = stack.func_77946_l();
/* 108 */           BlockState innerTargeState = mini.getInnerState(innerTargetPos.func_177958_n(), innerTargetPos.func_177956_o(), innerTargetPos.func_177952_p());
/*     */           
/* 110 */           if (!onItemUse(worldIn, pos, mini, mini.getInnerWorld(), innerTargetPos, innerTargeState, stack, player, handIn, hit)) {
/*     */             
/* 112 */             if (stack.func_77973_b() instanceof BlockItem) {
/* 113 */               DummyItemUseContext context = new DummyItemUseContext(mini.getInnerWorld(), player, handIn, copyStack, hit);
/* 114 */               if (innerTargeState.func_204520_s().func_206888_e()) {
/* 115 */                 context.innerPos = innerHitPos;
/*     */               } else {
/* 117 */                 context.innerPos = innerTargetPos;
/*     */               } 
/* 119 */               if (((BlockItem)copyStack.func_77973_b()).func_195942_a(context) == ActionResultType.SUCCESS) {
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 124 */                 if (!((Boolean)state.func_177229_b((IProperty)ENABLED)).booleanValue()) {
/* 125 */                   worldIn.func_175656_a(pos, (BlockState)state.func_206870_a((IProperty)ENABLED, Boolean.valueOf(true)));
/*     */                 }
/* 127 */                 isUpdated = true;
/*     */               } 
/* 129 */             } else if (stack.func_77973_b() instanceof BucketItem) {
/* 130 */               Fluid fluid = ((BucketItem)stack.func_77973_b()).getFluid();
/* 131 */               if (innerTargeState.func_177230_c() instanceof IWaterLoggable) {
/* 132 */                 IWaterLoggable container = (IWaterLoggable)innerTargeState.func_177230_c();
/* 133 */                 if (!fluid.func_207188_f().func_206888_e()) {
/* 134 */                   if (container.func_204510_a((IBlockReader)mini.getInnerWorld(), innerTargetPos, innerTargeState, fluid)) {
/* 135 */                     isUpdated = container.func_204509_a((IWorld)mini.getInnerWorld(), innerTargetPos, innerTargeState, fluid.func_207188_f());
/*     */                   } else {
/* 137 */                     BlockState fluidState = ((BucketItem)stack.func_77973_b()).getFluid().func_207188_f().func_206883_i();
/* 138 */                     if (!fluidState.hasTileEntity()) {
/* 139 */                       isUpdated = mini.setInnerState(innerHitPos, fluidState);
/*     */                     }
/*     */                   } 
/*     */                 } else {
/* 143 */                   isUpdated = (container.func_204508_a((IWorld)mini.getInnerWorld(), innerTargetPos, innerTargeState) != Fluids.field_204541_a);
/*     */                 }
/*     */               
/* 146 */               } else if (!fluid.func_207188_f().func_206888_e()) {
/* 147 */                 BlockState fluidState = ((BucketItem)stack.func_77973_b()).getFluid().func_207188_f().func_206883_i();
/* 148 */                 if (!fluidState.hasTileEntity()) {
/* 149 */                   isUpdated = mini.setInnerState(innerHitPos, fluidState);
/*     */                 }
/*     */               } else {
/* 152 */                 isUpdated = mini.setInnerState(innerTargetPos, MiniatureTileEntity.EMPTY);
/*     */               } 
/*     */             } 
/*     */           } else {
/*     */             
/* 157 */             isUpdated = true;
/*     */           } 
/*     */         } else {
/*     */           
/* 161 */           BlockState innerState = mini.getInnerState(innerTargetPos.func_177958_n(), innerTargetPos.func_177956_o(), innerTargetPos.func_177952_p());
/* 162 */           if (innerState != MiniatureTileEntity.EMPTY) {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 167 */             innerState.func_177230_c().func_176208_a(mini.getInnerWorld(), innerTargetPos, innerState, player);
/* 168 */             isUpdated = mini.setInnerState(innerTargetPos, MiniatureTileEntity.EMPTY);
/*     */             
/* 170 */             validCheck(mini, innerTargetPos, player);
/* 171 */             worldIn.func_175656_a(pos, (BlockState)state.func_206870_a((IProperty)ENABLED, Boolean.valueOf(!mini.isInnerEmpty())));
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 176 */         if (!isUpdated && 
/* 177 */           isOuterPos(mini, innerHitPos)) {
/* 178 */           BlockPos outerPos = pos.func_177972_a(hit.func_216354_b());
/* 179 */           BlockState outerState = worldIn.func_180495_p(outerPos);
/* 180 */           boolean isSuccess = false;
/*     */           
/* 182 */           if (outerState.isAir((IBlockReader)worldIn, outerPos)) {
/* 183 */             Optional<ItemStack> searchItem = player.field_71071_by.field_70462_a.stream().filter(s -> s.func_77969_a(new ItemStack((IItemProvider)this))).findFirst();
/* 184 */             if (searchItem.isPresent() || player.func_184812_l_()) {
/* 185 */               outerState = (BlockState)((BlockState)func_176223_P().func_206870_a((IProperty)field_176387_N, (Comparable)hit.func_216354_b().func_176734_d())).func_206870_a((IProperty)ENABLED, Boolean.valueOf(true));
/* 186 */               isSuccess = worldIn.func_175656_a(outerPos, outerState);
/* 187 */               if (isSuccess) {
/* 188 */                 if (!player.func_184812_l_()) {
/* 189 */                   ((ItemStack)searchItem.get()).func_190918_g(1);
/*     */                 }
/* 191 */                 ((MiniatureTileEntity)worldIn.func_175625_s(outerPos)).setSize(mini.getSize());
/* 192 */                 ((MiniatureTileEntity)worldIn.func_175625_s(outerPos)).setNoTexResize(mini.isNoTexResize());
/*     */               } 
/*     */             } 
/*     */           } 
/*     */           
/* 197 */           if (isSuccess && outerState.func_177230_c() instanceof Miniature) {
/* 198 */             return outerState.func_215687_a(worldIn, player, handIn, new BlockRayTraceResult(hit.func_216347_e(), hit.func_216354_b(), outerPos, hit.func_216353_d()));
/*     */           }
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 204 */         if (isUpdated) {
/* 205 */           BlockState updateState = worldIn.func_180495_p(pos);
/* 206 */           worldIn.func_184138_a(pos, updateState, updateState, 2);
/* 207 */           worldIn.func_195592_c(pos, (Block)this);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 213 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isOuterPos(MiniatureTileEntity mini, BlockPos innerHitPos) {
/* 221 */     return !mini.isInInnerRange(innerHitPos.func_177958_n(), innerHitPos.func_177956_o(), innerHitPos.func_177952_p());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   ItemStack getReturnItem(World outerWorld, BlockPos outerPos, BlockState innerState) {
/*     */     ItemStack drop;
/* 230 */     if (innerState.func_177230_c() instanceof CropsBlock) {
/* 231 */       drop = ((CropsBlock)innerState.func_177230_c()).func_185473_a((IBlockReader)outerWorld, outerPos, innerState);
/*     */     } else {
/* 233 */       drop = new ItemStack((IItemProvider)innerState.func_177230_c());
/*     */     } 
/* 235 */     return drop;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean onItemUse(World outerWorld, BlockPos outerPos, MiniatureTileEntity mini, World innerWorld, BlockPos innerPos, BlockState innerState, ItemStack stack, PlayerEntity player, Hand handIn, BlockRayTraceResult hit) {
/* 246 */     if (Items.field_151137_ax == stack.func_77973_b())
/* 247 */     { if (innerState.func_196959_b((IProperty)RedstoneTorchBlock.field_196528_a)) {
/* 248 */         boolean isPower = ((Boolean)innerState.func_177229_b((IProperty)RedstoneTorchBlock.field_196528_a)).booleanValue();
/* 249 */         BlockState powerState = (BlockState)innerState.func_206870_a((IProperty)RedstoneTorchBlock.field_196528_a, Boolean.valueOf(!isPower));
/* 250 */         if (!powerState.hasTileEntity()) {
/* 251 */           mini.setInnerState(innerPos, powerState);
/* 252 */           return true;
/*     */         } 
/*     */       } 
/* 255 */       if (innerState.func_196959_b((IProperty)BlockStateProperties.field_208193_t)) {
/* 256 */         boolean isPower = ((Boolean)innerState.func_177229_b((IProperty)BlockStateProperties.field_208193_t)).booleanValue();
/* 257 */         BlockState powerState = (BlockState)innerState.func_206870_a((IProperty)BlockStateProperties.field_208193_t, Boolean.valueOf(!isPower));
/* 258 */         if (!powerState.hasTileEntity()) {
/* 259 */           mini.setInnerState(innerPos, powerState);
/* 260 */           return true;
/*     */         } 
/*     */       }  }
/* 263 */     else { if (stack.func_77973_b() == Item.func_150898_a((Block)this)) {
/* 264 */         if (!mini.isInnerEmpty()) {
/* 265 */           ItemStack copy = player.func_184812_l_() ? new ItemStack((IItemProvider)this) : stack.func_77979_a(1);
/* 266 */           mini.writeData(copy.func_190925_c("BlockEntityTag"));
/* 267 */           Block.func_180635_a(outerWorld, outerPos, copy);
/*     */         } 
/* 269 */         return true;
/* 270 */       }  if (Items.field_151055_y == stack.func_77973_b()) {
/* 271 */         mini.func_189667_a(getRotation(player.func_174811_aO(), hit));
/* 272 */         return true;
/* 273 */       }  if ((stack.func_77973_b() instanceof net.minecraft.item.HoeItem || stack.func_77973_b() instanceof net.minecraft.item.ShovelItem || stack.func_77973_b() instanceof net.minecraft.item.BoneMealItem || stack.func_77973_b() instanceof net.minecraft.item.FlintAndSteelItem) && 
/* 274 */         !outerWorld.field_72995_K && 
/* 275 */         stack.func_196084_a((ItemUseContext)(new DummyItemUseContext(innerWorld, player, handIn, stack.func_77946_l(), hit)).setPos(innerPos)) == ActionResultType.SUCCESS) {
/* 276 */         return true;
/*     */       } }
/*     */ 
/*     */     
/* 280 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Rotation getRotation(Direction direction, BlockRayTraceResult hit) {
/* 291 */     return Rotation.CLOCKWISE_90;
/*     */   }
/*     */ 
/*     */   void validCheck(MiniatureTileEntity mini, BlockPos pos, PlayerEntity player) {
/* 295 */     for (Direction dir : Direction.values()) {
/* 296 */       BlockPos offsetPos = pos.func_177971_a(dir.func_176730_m());
/* 297 */       BlockState s = mini.getInnerState(offsetPos.func_177958_n(), offsetPos.func_177956_o(), offsetPos.func_177952_p());
/* 298 */       if (s != MiniatureTileEntity.EMPTY && !s.func_196955_c((IWorldReader)mini.getInnerWorld(), offsetPos)) {
/* 299 */         s.func_177230_c().func_176208_a(mini.getInnerWorld(), offsetPos, s, player);
/* 300 */         mini.setInnerState(offsetPos, MiniatureTileEntity.EMPTY);
/* 301 */         validCheck(mini, offsetPos, player);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public List<ItemStack> func_220076_a(BlockState state, LootContext.Builder builder) {
/* 309 */     List<ItemStack> list = super.func_220076_a(state, builder);
/* 310 */     ItemStack stack = list.stream().findFirst().orElse(ItemStack.field_190927_a);
/* 311 */     if (stack != ItemStack.field_190927_a) {
/* 312 */       TileEntity te = (TileEntity)builder.func_216019_b(LootParameters.field_216288_h);
/* 313 */       if (te != null && te instanceof MiniatureTileEntity && 
/* 314 */         !((MiniatureTileEntity)te).isInnerEmpty()) {
/* 315 */         ((MiniatureTileEntity)te).writeData(stack.func_190925_c("BlockEntityTag"));
/*     */       }
/*     */     } 
/*     */     
/* 319 */     return list;
/*     */   }
/*     */ 
/*     */   BlockPos calcHitPos(BlockPos pos, Vec3d hitVec, Direction face, int size) {
/* 323 */     Vec3d offsetVec = getOffsetVec3d(hitVec.func_178786_a(pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p()), face, size);
/* 324 */     return new BlockPos(offsetVec.func_82615_a() / (1.0F / size), offsetVec.func_82617_b() / (1.0F / size), offsetVec.func_82616_c() / (1.0F / size));
/*     */   }
/*     */ 
/*     */   Vec3d getOffsetVec3d(Vec3d vec, Direction face, int size) {
/* 328 */     return vec.func_72441_c((face.func_82601_c() * 1.0F / size * 0.5F), (face.func_96559_d() * 1.0F / size * 0.5F), (face.func_82599_e() * 1.0F / size * 0.5F));
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_220069_a(BlockState state, World worldIn, BlockPos pos, Block blockIn, BlockPos fromPos, boolean isMoving) {
/* 333 */     super.func_220069_a(state, worldIn, pos, blockIn, fromPos, isMoving);
/* 334 */     TileEntity te = worldIn.func_175625_s(pos);
/* 335 */     if (te != null && te instanceof MiniatureTileEntity) {
/* 336 */       worldIn.func_184138_a(pos, state, state, 2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   public BlockState func_196271_a(BlockState stateIn, Direction facing, BlockState facingState, IWorld worldIn, BlockPos currentPos, BlockPos facingPos) {
/* 342 */     BlockState updateState = super.func_196271_a(stateIn, facing, facingState, worldIn, currentPos, facingPos);
/* 343 */     TileEntity te = worldIn.func_175625_s(currentPos);
/* 344 */     if (te != null && te instanceof MiniatureTileEntity && 
/* 345 */       worldIn.func_201670_d()) {
/* 346 */       ((MiniatureTileEntity)te).removeCache();
/*     */     }
/*     */     
/* 349 */     return updateState;
/*     */   }
/*     */ 
/*     */ 
/*     */   public VoxelShape func_220053_a(BlockState state, IBlockReader worldIn, BlockPos pos, ISelectionContext context) {
/* 354 */     VoxelShape shape = VoxelShapes.func_197880_a();
/* 355 */     if (!((Boolean)state.func_177229_b((IProperty)ENABLED)).booleanValue()) {
/* 356 */       shape = getFaceShape((Direction)state.func_177229_b((IProperty)field_176387_N));
/*     */     } else {
/* 358 */       for (Direction dir : Direction.values()) {
/* 359 */         BlockState offsetState = worldIn.func_180495_p(pos.func_177972_a(dir));
/* 360 */         if (offsetState.func_177230_c() != this && 
/* 361 */           offsetState.func_196954_c(worldIn, pos.func_177972_a(dir)) == VoxelShapes.func_197868_b()) {
/* 362 */           shape = VoxelShapes.func_197872_a(shape, getFaceShape(dir));
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 367 */       TileEntity te = worldIn.func_175625_s(pos);
/* 368 */       if (te != null && te instanceof MiniatureTileEntity) {
/* 369 */         MiniatureTileEntity mini = (MiniatureTileEntity)te;
/* 370 */         if (mini.shapeCache != null) {
/* 371 */           return mini.shapeCache;
/*     */         }
/* 373 */         int size = (getSize() == mini.getSize()) ? getSize() : mini.getSize();
/* 374 */         VoxelShape[][][] s = (getSize() == size) ? this.shapes : makeShapes(size);
/* 375 */         for (int i = 0; i < size; i++) {
/* 376 */           for (int j = 0; j < size; j++) {
/* 377 */             for (int k = 0; k < size; k++) {
/* 378 */               BlockState innerState = mini.getInnerState(i, j, k);
/* 379 */               if (innerState != MiniatureTileEntity.EMPTY) {
/* 380 */                 shape = VoxelShapes.func_197872_a(shape, s[i][j][k]);
/*     */               }
/*     */             } 
/*     */           } 
/*     */         } 
/* 385 */         mini.shapeCache = shape;
/*     */       } 
/*     */     } 
/* 388 */     return shape;
/*     */   }
/*     */ 
/*     */ 
/*     */   VoxelShape getFaceShape(Direction dir) {
/* 393 */     switch (dir) {
/*     */       case DOWN:
/* 395 */         return DOWN_AABB;
/*     */       case EAST:
/* 397 */         return EAST_AABB;
/*     */       case NORTH:
/* 399 */         return NORTH_AABB;
/*     */       case SOUTH:
/* 401 */         return SOUTH_AABB;
/*     */       case UP:
/* 403 */         return UP_AABB;
/*     */       case WEST:
/* 405 */         return WEST_AABB;
/*     */     } 
/* 407 */     return VoxelShapes.func_197880_a();
/*     */   }
/*     */ 
/*     */ 
/*     */   public BlockState func_196258_a(BlockItemUseContext context) {
/* 412 */     BlockState blockstate = func_176223_P();
/* 413 */     boolean flg = (context.func_195996_i().func_179543_a("BlockEntityTag") != null && context.func_195996_i().func_179543_a("BlockEntityTag").func_74764_b("state"));
/* 414 */     return (BlockState)((BlockState)blockstate.func_206870_a((IProperty)field_176387_N, (Comparable)context.func_196000_l().func_176734_d())).func_206870_a((IProperty)ENABLED, Boolean.valueOf(flg));
/*     */   }
/*     */ 
/*     */ 
/*     */   public BlockRenderLayer func_180664_k() {
/* 419 */     return BlockRenderLayer.CUTOUT;
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean hasTileEntity(BlockState state) {
/* 424 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   public TileEntity createTileEntity(BlockState state, IBlockReader world) {
/* 429 */     return new MiniatureTileEntity();
/*     */   }
/*     */ 
/*     */ 
/*     */   public BlockRenderType func_149645_b(BlockState state) {
/* 434 */     return ((Boolean)state.func_177229_b((IProperty)ENABLED)).booleanValue() ? BlockRenderType.INVISIBLE : super.func_149645_b(state);
/*     */   }
/*     */ 
/*     */ 
/*     */   protected void func_206840_a(StateContainer.Builder<Block, BlockState> builder) {
/* 439 */     super.func_206840_a(builder);
/* 440 */     builder.func_206894_a(new IProperty[] { (IProperty)ENABLED, (IProperty)field_176387_N });
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_196266_a(BlockState state, IBlockReader worldIn, BlockPos pos, PathType type) {
/* 445 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   public PushReaction func_149656_h(BlockState state) {
/* 450 */     return PushReaction.BLOCK;
/*     */   }
/*     */ 
/*     */ 
/*     */   public ItemStack getPickBlock(BlockState state, RayTraceResult target, IBlockReader worldIn, BlockPos pos, PlayerEntity player) {
/* 455 */     TileEntity te = worldIn.func_175625_s(pos);
/* 456 */     if (te != null && te instanceof MiniatureTileEntity && 
/* 457 */       target instanceof BlockRayTraceResult) {
/* 458 */       BlockRayTraceResult hit = (BlockRayTraceResult)target;
/* 459 */       int size = (getSize() == ((MiniatureTileEntity)te).getSize()) ? getSize() : ((MiniatureTileEntity)te).getSize();
/* 460 */       BlockPos innerTargetPos = calcHitPos(pos, hit.func_216347_e(), hit.func_216354_b().func_176734_d(), size);
/* 461 */       return new ItemStack((IItemProvider)((MiniatureTileEntity)te).getInnerState(innerTargetPos).func_177230_c());
/*     */     } 
/*     */     
/* 464 */     return getBlock().func_185473_a(worldIn, pos, state);
/*     */   }
/*     */ 
/*     */   class DummyItemUseContext
/*     */     extends BlockItemUseContext {
/*     */     BlockPos innerPos;
/*     */     
/*     */     public DummyItemUseContext(World world, PlayerEntity player, Hand handIn, ItemStack stack, BlockRayTraceResult rayTraceResultIn) {
/* 472 */       super(world, player, handIn, stack, rayTraceResultIn);
/*     */     }
/*     */ 
/*     */     public DummyItemUseContext setPos(BlockPos pos) {
/* 476 */       this.innerPos = pos;
/* 477 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */     public BlockPos func_195995_a() {
/* 482 */       return this.innerPos;
/*     */     }
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 33 ms
	
*/