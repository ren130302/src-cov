/*     */ package com.ruby.meshi.crafting;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.google.gson.JsonArray;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonParseException;
/*     */ import it.unimi.dsi.fastutil.ints.IntList;
/*     */ import java.util.List;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.crafting.IRecipe;
/*     */ import net.minecraft.item.crafting.IRecipeSerializer;
/*     */ import net.minecraft.item.crafting.IRecipeType;
/*     */ import net.minecraft.item.crafting.Ingredient;
/*     */ import net.minecraft.item.crafting.RecipeItemHelper;
/*     */ import net.minecraft.item.crafting.ShapedRecipe;
/*     */ import net.minecraft.network.PacketBuffer;
/*     */ import net.minecraft.util.JSONUtils;
/*     */ import net.minecraft.util.NonNullList;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.registry.Registry;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.util.RecipeMatcher;
/*     */ import net.minecraftforge.registries.ForgeRegistryEntry;
/*     */ 
/*     */ public class HearthShapelessRecipe
/*     */   implements IRecipe<IInventory>, NonLockRecipe, CookingTimerRecipe {
/*     */   public static final IRecipeType<HearthShapelessRecipe> TYPE;
/*     */   
/*     */   static {
/*  31 */     final ResourceLocation key = HiganRecipeSerializer.HEARTH_SHAPELESS.getRegistryName();
/*  32 */     TYPE = (IRecipeType<HearthShapelessRecipe>)Registry.func_218322_a(Registry.field_218367_H, key, new IRecipeType<HearthShapelessRecipe>()
/*     */         {
/*     */           public String toString() {
/*  35 */             return key.toString();
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HearthShapelessRecipe(ResourceLocation idIn, String groupIn, ItemStack recipeOutputIn, NonNullList<Ingredient> recipeItemsIn, int time) {
/*  48 */     this.id = idIn;
/*  49 */     this.group = groupIn;
/*  50 */     this.recipeOutput = recipeOutputIn;
/*  51 */     this.recipeItems = recipeItemsIn;
/*  52 */     this.isSimple = recipeItemsIn.stream().allMatch(Ingredient::isSimple);
/*  53 */     this.cookingTime = time;
/*     */   }
/*     */ 
/*     */ 
/*     */   public ResourceLocation func_199560_c() {
/*  58 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */   public IRecipeSerializer<?> func_199559_b() {
/*  63 */     return HiganRecipeSerializer.HEARTH_SHAPELESS;
/*     */   }
/*     */ 
/*     */ 
/*     */   public String func_193358_e() {
/*  68 */     return this.group;
/*     */   }
/*     */ 
/*     */ 
/*     */   public ItemStack func_77571_b() {
/*  73 */     return this.recipeOutput;
/*     */   }
/*     */ 
/*     */ 
/*     */   public NonNullList<Ingredient> func_192400_c() {
/*  78 */     return this.recipeItems;
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_77569_a(IInventory inv, World worldIn) {
/*  83 */     RecipeItemHelper recipeitemhelper = new RecipeItemHelper();
/*  84 */     List<ItemStack> inputs = Lists.newArrayList();
/*  85 */     int i = 0;
/*     */     
/*  87 */     for (int j = 0; j < inv.func_70302_i_(); j++) {
/*  88 */       ItemStack itemstack = inv.func_70301_a(j);
/*  89 */       if (!itemstack.func_190926_b()) {
/*  90 */         i++;
/*  91 */         if (this.isSimple) {
/*  92 */           recipeitemhelper.func_221264_a(itemstack, 1);
/*     */         } else {
/*  94 */           inputs.add(itemstack);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  99 */     return (i == this.recipeItems.size() && (this.isSimple ? recipeitemhelper.func_194116_a(this, (IntList)null) : (RecipeMatcher.findMatches(inputs, (List)this.recipeItems) != null)));
/*     */   }
/*     */ 
/*     */ 
/*     */   public ItemStack func_77572_b(IInventory inv) {
/* 104 */     return this.recipeOutput.func_77946_l();
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_194133_a(int width, int height) {
/* 109 */     return (width * height >= this.recipeItems.size());
/*     */   }
/*     */ 
/*     */ 
/*     */   public int getCookTime() {
/* 114 */     return this.cookingTime;
/*     */   }
/*     */ 
/*     */ 
/*     */   public IRecipeType<?> func_222127_g() {
/* 119 */     return TYPE;
/*     */   }
/*     */ 
/*     */   public static class Serializer
/*     */     extends ForgeRegistryEntry<IRecipeSerializer<?>> implements IRecipeSerializer<HearthShapelessRecipe> {
/*     */     public HearthShapelessRecipe read(ResourceLocation recipeId, JsonObject json) {
/* 125 */       String s = JSONUtils.func_151219_a(json, "group", "");
/* 126 */       int cookingTime = JSONUtils.func_151208_a(json, "cookingtime", 200);
/* 127 */       NonNullList<Ingredient> nonnulllist = readIngredients(JSONUtils.func_151214_t(json, "ingredients"));
/* 128 */       if (nonnulllist.isEmpty())
/* 129 */         throw new JsonParseException("No ingredients for shapeless recipe"); 
/* 130 */       if (nonnulllist.size() > 9) {
/* 131 */         throw new JsonParseException("Too many ingredients for shapeless recipe the max is 9");
/*     */       }
/* 133 */       ItemStack itemstack = ShapedRecipe.func_199798_a(JSONUtils.func_152754_s(json, "result"));
/* 134 */       return new HearthShapelessRecipe(recipeId, s, itemstack, nonnulllist, cookingTime);
/*     */     }
/*     */ 
/*     */ 
/*     */     private static NonNullList<Ingredient> readIngredients(JsonArray p_199568_0_) {
/* 139 */       NonNullList<Ingredient> nonnulllist = NonNullList.func_191196_a();
/*     */       
/* 141 */       for (int i = 0; i < p_199568_0_.size(); i++) {
/* 142 */         Ingredient ingredient = Ingredient.func_199802_a(p_199568_0_.get(i));
/* 143 */         if (!ingredient.func_203189_d()) {
/* 144 */           nonnulllist.add(ingredient);
/*     */         }
/*     */       } 
/*     */       
/* 148 */       return nonnulllist;
/*     */     }
/*     */ 
/*     */ 
/*     */     public HearthShapelessRecipe read(ResourceLocation recipeId, PacketBuffer buffer) {
/* 153 */       String s = buffer.func_150789_c(32767);
/* 154 */       int i = buffer.func_150792_a();
/* 155 */       NonNullList<Ingredient> nonnulllist = NonNullList.func_191197_a(i, Ingredient.field_193370_a);
/*     */       
/* 157 */       for (int j = 0; j < nonnulllist.size(); j++) {
/* 158 */         nonnulllist.set(j, Ingredient.func_199566_b(buffer));
/*     */       }
/*     */       
/* 161 */       ItemStack itemstack = buffer.func_150791_c();
/* 162 */       int cookingTime = buffer.readInt();
/* 163 */       return new HearthShapelessRecipe(recipeId, s, itemstack, nonnulllist, cookingTime);
/*     */     }
/*     */ 
/*     */ 
/*     */     public void write(PacketBuffer buffer, HearthShapelessRecipe recipe) {
/* 168 */       buffer.func_180714_a(recipe.func_193358_e());
/* 169 */       buffer.func_150787_b(recipe.func_192400_c().size());
/*     */       
/* 171 */       for (Ingredient ingredient : recipe.func_192400_c()) {
/* 172 */         ingredient.func_199564_a(buffer);
/*     */       }
/*     */       
/* 175 */       buffer.func_150788_a(recipe.func_77571_b());
/* 176 */       buffer.writeInt(recipe.getCookTime());
/*     */     }
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 10 ms
	
*/