/*    */ package com.ruby.meshi.util;
/*    */ 
/*    */ import com.ruby.meshi.util.packet.ContainerHandler;
/*    */ import com.ruby.meshi.util.packet.NBTSyncHandler;
/*    */ import net.minecraft.entity.player.ServerPlayerEntity;
/*    */ import net.minecraft.inventory.container.ContainerType;
/*    */ import net.minecraft.nbt.INBT;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraftforge.fml.network.NetworkRegistry;
/*    */ import net.minecraftforge.fml.network.PacketDistributor;
/*    */ import net.minecraftforge.fml.network.simple.SimpleChannel;
/*    */ 
/*    */ 
/*    */ public class NetworkHandler
/*    */ {
/* 16 */   private static final String PROTOCOL_VERSION = Integer.toString(1);
/* 17 */   private static final SimpleChannel HANDLER = NetworkRegistry.ChannelBuilder.named(new ResourceLocation("meshi", "main_channel"))
/* 18 */     .clientAcceptedVersions(PROTOCOL_VERSION::equals)
/* 19 */     .serverAcceptedVersions(PROTOCOL_VERSION::equals)
/* 20 */     .networkProtocolVersion(() -> PROTOCOL_VERSION)
/* 21 */     .simpleChannel();
/*    */ 
/*    */   public static void register() {
/* 24 */     int disc = 0;
/* 25 */     HANDLER.registerMessage(disc++, ContainerHandler.class, ContainerHandler::encode, ContainerHandler::decode, ContainerHandler::handle);
/* 26 */     HANDLER.registerMessage(disc++, NBTSyncHandler.class, NBTSyncHandler::encode, NBTSyncHandler::decode, NBTSyncHandler::handle);
/*    */   }
/*    */ 
/*    */   public static <MSG> void send(PacketDistributor.PacketTarget target, MSG message) {
/* 30 */     HANDLER.send(target, message);
/*    */   }
/*    */ 
/*    */   public static void openServerContainer(ContainerType<?> type) {
/* 34 */     HANDLER.sendToServer(new ContainerHandler(type.getRegistryName()));
/*    */   }
/*    */ 
/*    */   public static void sendExtendInvCap(ServerPlayerEntity player) {
/* 38 */     INBT nbt = CapabilityExtendInventory.EXTEND_INVENTORY.writeNBT(player.getCapability(CapabilityExtendInventory.EXTEND_INVENTORY).orElse(CapabilityExtendInventory.EXTEND_INVENTORY.getDefaultInstance()), null);
/* 39 */     HANDLER.send(PacketDistributor.PLAYER.with(() -> player), new NBTSyncHandler(nbt));
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 5 ms
	
*/