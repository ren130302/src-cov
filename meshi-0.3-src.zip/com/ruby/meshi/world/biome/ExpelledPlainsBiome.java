/*    */ package com.ruby.meshi.world.biome;
/*    */ 
/*    */ import net.minecraft.world.biome.Biome;
/*    */ import net.minecraft.world.biome.DefaultBiomeFeatures;
/*    */ import net.minecraft.world.gen.surfacebuilders.ISurfaceBuilderConfig;
/*    */ import net.minecraft.world.gen.surfacebuilders.SurfaceBuilder;
/*    */ 
/*    */ public class ExpelledPlainsBiome extends ExpelledBaseBiome {
/*    */   protected ExpelledPlainsBiome() {
/* 10 */     super((new Biome.Builder()).func_222351_a(SurfaceBuilder.field_215396_G, (ISurfaceBuilderConfig)SurfaceBuilder.field_215425_v).func_205415_a(Biome.RainType.RAIN).func_205419_a(Biome.Category.PLAINS).func_205421_a(0.25F).func_205420_b(0.0125F).func_205414_c(0.8F).func_205417_d(0.4F).func_205412_a(4159204).func_205413_b(329011).func_205418_a((String)null));
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 18 */     DefaultBiomeFeatures.func_222300_a(this);
/* 19 */     DefaultBiomeFeatures.func_222333_d(this);
/*    */ 
/*    */ 
/*    */     
/* 23 */     DefaultBiomeFeatures.func_222283_Y(this);
/* 24 */     DefaultBiomeFeatures.func_222282_l(this);
/*    */     
/* 26 */     DefaultBiomeFeatures.func_222299_R(this);
/* 27 */     DefaultBiomeFeatures.func_222315_Z(this);
/* 28 */     DefaultBiomeFeatures.func_222311_aa(this);
/* 29 */     DefaultBiomeFeatures.func_222337_am(this);
/* 30 */     DefaultBiomeFeatures.func_222297_ap(this);
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 3 ms
	
*/