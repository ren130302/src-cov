/*    */ package com.ruby.meshi.block.tileentity;
/*    */ 
/*    */ import com.ruby.meshi.init.HiganTileEntityType;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.tileentity.TileEntityType;
/*    */ 
/*    */ public class BambooPotTileEntity
/*    */   extends TileEntity
/*    */ {
/*    */   public BambooPotTileEntity(TileEntityType<?> tileEntityTypeIn) {
/* 11 */     super(tileEntityTypeIn);
/*    */   }
/*    */ 
/*    */   public BambooPotTileEntity() {
/* 15 */     this(HiganTileEntityType.BAMBOO_POT);
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 1 ms
	
*/