/*    */ package com.ruby.meshi.block;
/*    */ 
/*    */ import com.ruby.meshi.block.tileentity.ContainerTileEntity;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.BlockState;
/*    */ import net.minecraft.entity.player.PlayerEntity;
/*    */ import net.minecraft.entity.player.PlayerInventory;
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.inventory.InventoryHelper;
/*    */ import net.minecraft.inventory.container.ChestContainer;
/*    */ import net.minecraft.inventory.container.Container;
/*    */ import net.minecraft.inventory.container.INamedContainerProvider;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.Hand;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.util.math.BlockRayTraceResult;
/*    */ import net.minecraft.world.IBlockReader;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class JPChest
/*    */   extends PlayerFacingBlock
/*    */   implements ContainerTileEntity.MeshiContainer {
/*    */   public JPChest(Block.Properties properties) {
/* 24 */     super(properties);
/*    */   }
/*    */ 
/*    */ 
/*    */   public boolean func_220051_a(BlockState state, World worldIn, BlockPos pos, PlayerEntity player, Hand handIn, BlockRayTraceResult hit) {
/* 29 */     if (worldIn.field_72995_K) {
/* 30 */       return true;
/*    */     }
/* 32 */     INamedContainerProvider inamedcontainerprovider = func_220052_b(state, worldIn, pos);
/* 33 */     if (inamedcontainerprovider != null) {
/* 34 */       player.func_213829_a(inamedcontainerprovider);
/*    */     }
/* 36 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   public INamedContainerProvider func_220052_b(BlockState state, World worldIn, BlockPos pos) {
/* 42 */     return (INamedContainerProvider)worldIn.func_175625_s(pos);
/*    */   }
/*    */ 
/*    */ 
/*    */   public boolean hasTileEntity(BlockState state) {
/* 47 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   public TileEntity createTileEntity(BlockState state, IBlockReader world) {
/* 52 */     return (TileEntity)(new ContainerTileEntity()).setContainerBlock(this);
/*    */   }
/*    */ 
/*    */ 
/*    */   public int getSize() {
/* 57 */     return 54;
/*    */   }
/*    */ 
/*    */ 
/*    */   public Container createMenu(int id, PlayerInventory player, IInventory inv) {
/* 62 */     return (Container)ChestContainer.func_216984_b(id, player, inv);
/*    */   }
/*    */ 
/*    */ 
/*    */   public void func_196243_a(BlockState state, World worldIn, BlockPos pos, BlockState newState, boolean isMoving) {
/* 67 */     if (state.func_177230_c() != newState.func_177230_c()) {
/* 68 */       TileEntity tileentity = worldIn.func_175625_s(pos);
/* 69 */       if (tileentity instanceof IInventory) {
/* 70 */         InventoryHelper.func_180175_a(worldIn, pos, (IInventory)tileentity);
/* 71 */         worldIn.func_175666_e(pos, (Block)this);
/*    */       } 
/*    */       
/* 74 */       super.func_196243_a(state, worldIn, pos, newState, isMoving);
/*    */     } 
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 4 ms
	
*/