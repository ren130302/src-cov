/*    */ package com.ruby.meshi.block;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraft.world.biome.Biome;
/*    */ 
/*    */ public class FermentedCask
/*    */   extends Block {
/*    */   public FermentedCask(Block.Properties properties) {
/* 11 */     super(properties);
/*    */   }
/*    */ 
/*    */ 
/*    */   public void getType(World worldIn, BlockPos pos) {
/* 16 */     Biome.TempCategory temp = worldIn.func_180494_b(pos).func_150561_m();
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 1 ms
	
*/