/*    */ package com.ruby.meshi.client.renderer;
/*    */ 
/*    */ import com.ruby.meshi.block.tileentity.BambooPotTileEntity;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ 
/*    */ public class BambooPotRender
/*    */   extends SimpleItemRender<BambooPotTileEntity> {
/*    */   public void render(BambooPotTileEntity tileEntityIn, double x, double y, double z, float partialTicks, int destroyStage) {
/*  9 */     super.func_199341_a(tileEntityIn, x, y, z, partialTicks, destroyStage);
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 1 ms
	
*/