/*     */ package com.ruby.meshi.block;
/*     */ 
/*     */ import com.google.common.collect.Streams;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockState;
/*     */ import net.minecraft.block.FarmlandBlock;
/*     */ import net.minecraft.block.IWaterLoggable;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.fluid.Fluid;
/*     */ import net.minecraft.fluid.Fluids;
/*     */ import net.minecraft.fluid.IFluidState;
/*     */ import net.minecraft.item.BlockItemUseContext;
/*     */ import net.minecraft.state.BooleanProperty;
/*     */ import net.minecraft.state.IProperty;
/*     */ import net.minecraft.state.StateContainer;
/*     */ import net.minecraft.state.properties.BlockStateProperties;
/*     */ import net.minecraft.util.Direction;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.IBlockReader;
/*     */ import net.minecraft.world.IWorld;
/*     */ import net.minecraft.world.IWorldReader;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.IPlantable;
/*     */ import net.minecraftforge.common.PlantType;
/*     */ 
/*     */ public class PaddyField
/*     */   extends FarmlandBlock implements IWaterLoggable {
/*  29 */   public static final BooleanProperty WATERLOGGED = BlockStateProperties.field_208198_y;
/*     */ 
/*     */   protected PaddyField(Block.Properties builder) {
/*  32 */     super(builder);
/*  33 */     func_180632_j((BlockState)func_176223_P().func_206870_a((IProperty)WATERLOGGED, Boolean.valueOf(false)));
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_196267_b(BlockState state, World worldIn, BlockPos pos, Random random) {
/*  38 */     super.func_196267_b(state, worldIn, pos, random);
/*     */ 
/*     */     
/*  41 */     int moisture = ((Integer)state.func_177229_b((IProperty)field_176531_a)).intValue();
/*  42 */     boolean waterlogged = ((Boolean)state.func_177229_b((IProperty)WATERLOGGED)).booleanValue();
/*  43 */     BlockPos upperPos = pos.func_177984_a();
/*  44 */     BlockState upperState = worldIn.func_180495_p(upperPos);
/*  45 */     if (moisture == 7) {
/*  46 */       if (!waterlogged) {
/*  47 */         if (upperState.func_177230_c() instanceof IPlantable) {
/*  48 */           PlantType type = ((IPlantable)upperState.func_177230_c()).getPlantType((IBlockReader)worldIn, pos.func_177972_a(Direction.UP));
/*  49 */           if (type == PlantType.Crop && upperState.func_177230_c() != SakuraBlocks.RICE_PLANT && 
/*  50 */             random.nextFloat() < 0.75F) {
/*  51 */             upperState.func_196940_a(worldIn, upperPos, random);
/*     */           }
/*     */         }
/*     */       
/*     */       }
/*  56 */       else if (upperState.func_177230_c() == SakuraBlocks.RICE_PLANT && 
/*  57 */         random.nextFloat() < 0.75F) {
/*  58 */         upperState.func_196940_a(worldIn, upperPos, random);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void randomDestory(World worldIn, BlockPos pos, Random rand) {
/*  67 */     if (rand.nextFloat() < 0.01F) {
/*  68 */       worldIn.func_175655_b(pos, false);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   public IFluidState func_204507_t(BlockState state) {
/*  74 */     return ((Boolean)state.func_177229_b((IProperty)WATERLOGGED)).booleanValue() ? Fluids.field_204546_a.func_207204_a(false) : super.func_204507_t(state);
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_206840_a(StateContainer.Builder<Block, BlockState> builder) {
/*  79 */     super.func_206840_a(builder);
/*  80 */     builder.func_206894_a(new IProperty[] { (IProperty)WATERLOGGED });
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_220082_b(BlockState state, World worldIn, BlockPos pos, BlockState oldState, boolean isMoving) {
/*  85 */     super.func_220082_b(state, worldIn, pos, oldState, isMoving);
/*  86 */     if (oldState.func_177230_c() != this) {
/*  87 */       worldIn.func_175656_a(pos, setHorizontalWater(state, worldIn, pos));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   public BlockState func_196271_a(BlockState stateIn, Direction facing, BlockState facingState, IWorld worldIn, BlockPos currentPos, BlockPos facingPos) {
/*  93 */     if (((Boolean)stateIn.func_177229_b((IProperty)WATERLOGGED)).booleanValue()) {
/*  94 */       worldIn.func_205219_F_().func_205360_a(currentPos, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a((IWorldReader)worldIn));
/*     */     }
/*     */     
/*  97 */     return super.func_196271_a(stateIn, facing, facingState, worldIn, currentPos, facingPos);
/*     */   }
/*     */ 
/*     */ 
/*     */   public BlockState func_196258_a(BlockItemUseContext context) {
/* 102 */     return setHorizontalWater(super.func_196258_a(context), context.func_195991_k(), context.func_195995_a());
/*     */   }
/*     */ 
/*     */   public BlockState setHorizontalWater(BlockState state, World worldIn, BlockPos pos) {
/* 106 */     Fluid fluid = worldIn.func_204610_c(pos).func_206886_c();
/* 107 */     if (fluid == Fluids.field_204541_a || fluid == Fluids.field_207212_b)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 112 */       fluid = Streams.stream(Direction.Plane.HORIZONTAL.iterator()).filter(d -> (worldIn.func_180495_p(pos.func_177972_a(d)).func_177230_c() == this)).map(d -> worldIn.func_204610_c(pos.func_177972_a(d)).func_206886_c()).filter(Fluids.field_204546_a::equals).findAny().orElse(Fluids.field_204541_a);
/*     */     }
/* 114 */     return (BlockState)((BlockState)state.func_206870_a((IProperty)WATERLOGGED, Boolean.valueOf((fluid == Fluids.field_204546_a)))).func_206870_a((IProperty)field_176531_a, Integer.valueOf((fluid == Fluids.field_204546_a) ? 7 : 0));
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_180658_a(World worldIn, BlockPos pos, Entity entityIn, float fallDistance) {
/* 119 */     if (!((Boolean)worldIn.func_180495_p(pos).func_177229_b((IProperty)WATERLOGGED)).booleanValue()) {
/* 120 */       super.func_180658_a(worldIn, pos, entityIn, fallDistance);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_220069_a(BlockState state, World worldIn, BlockPos pos, Block blockIn, BlockPos fromPos, boolean isMoving) {
/* 126 */     super.func_220069_a(state, worldIn, pos, blockIn, fromPos, isMoving);
/* 127 */     if (!worldIn.field_72995_K) {
/* 128 */       BlockState fromState = worldIn.func_180495_p(fromPos);
/* 129 */       if (fromState.func_177230_c() == this && isHorizontalPos(pos, fromPos) && 
/* 130 */         state.func_177229_b((IProperty)WATERLOGGED) != fromState.func_177229_b((IProperty)WATERLOGGED)) {
/* 131 */         worldIn.func_175656_a(pos, (BlockState)state.func_206870_a((IProperty)WATERLOGGED, fromState.func_177229_b((IProperty)WATERLOGGED)));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   private boolean isHorizontalPos(BlockPos pos, BlockPos fromPos) {
/* 138 */     if (pos.func_177956_o() == fromPos.func_177956_o()) {
/* 139 */       return Streams.stream(Direction.Plane.HORIZONTAL.iterator())
/* 140 */         .anyMatch(d -> pos.func_177972_a(d).equals(fromPos));
/*     */     }
/* 142 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean canSustainPlant(BlockState state, IBlockReader world, BlockPos pos, Direction facing, IPlantable plantable) {
/* 147 */     PlantType type = plantable.getPlantType(world, pos.func_177972_a(facing));
/* 148 */     return (type == PlantType.Crop);
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 14 ms
	
*/