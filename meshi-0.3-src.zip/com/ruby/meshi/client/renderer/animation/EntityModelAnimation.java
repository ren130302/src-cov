/*    */  package com.ruby.meshi.client.renderer.animation;
/*    */  
/*    */  public interface EntityModelAnimation {
/*    */    boolean shouldRenderPart(RenderPart paramRenderPart);
/*    */    
/*    */    void animationTick();
/*    */    
/*    */    int getMaxTimer();
/*    */    
/* 10 */    public static final ThreadLocalRandom rand = ThreadLocalRandom.current();
/*    */ 
/*    */ 
/* 13 */    public enum RenderPart { HEAD,
/* 14 */      TAIL,
/* 15 */      RIGHT_HAND,
/* 16 */      LEFT_HAND,
/* 17 */      RIGHT_LEG,
/* 18 */      LEFT_LEG; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */    default void translatef(TriConsumer<Float, Float, Float> position, float partialTicks) {
/* 30 */      position.accept(Float.valueOf(0.0F), Float.valueOf(0.0F), Float.valueOf(0.0F));
/*    */    }
/*    */ 
/*    */    default void scalef(TriConsumer<Float, Float, Float> scale, float partialTicks) {
/* 34 */      scale.accept(Float.valueOf(0.0F), Float.valueOf(0.0F), Float.valueOf(0.0F));
/*    */    }
/*    */ 
/*    */    default void rotateX(Consumer<Float> angle, float partialTicks) {
/* 38 */      angle.accept(Float.valueOf(0.0F));
/*    */    }
/*    */ 
/*    */    default void rotateY(Consumer<Float> angle, float partialTicks) {
/* 42 */      angle.accept(Float.valueOf(0.0F));
/*    */    }
/*    */ 
/*    */    default void rotateZ(Consumer<Float> angle, float partialTicks) {
/* 46 */      angle.accept(Float.valueOf(0.0F));
/*    */    }
/*    */ 
/*    */    default float getDiractionVal(float val, Direction direction, Direction.Axis axis) {
/* 50 */      float offset = 0.0F;
/* 51 */      if (direction.func_176740_k() == axis) {
/* 52 */        offset = val;
/*    */      }
/* 54 */      return offset;
/*    */    }
/*    */ 
/*    */    default float getDiractionOffsetVal(float val, Direction direction, Direction.Axis axis) {
/* 58 */      float offset = 0.0F;
/* 59 */      if (direction.func_176740_k() == axis) {
/* 60 */        offset = val * direction.func_176743_c().func_179524_a();
/*    */      }
/* 62 */      return offset;
/*    */    }
/*    */ 
/*    */    default float lerp(float partialTicks, float prev, float now) {
/* 66 */      return MathHelper.func_219799_g(partialTicks, prev, now);
/*    */    }
/*    */  }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 4 ms
	
*/