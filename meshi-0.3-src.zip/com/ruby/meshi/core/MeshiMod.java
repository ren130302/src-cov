/*    */  package com.ruby.meshi.core;
/*    */  
/*    */  import com.ruby.meshi.client.ClientProxy;
/*    */  import com.ruby.meshi.init.HiganContainerType;
/*    */  import com.ruby.meshi.init.SakuraConfig;
/*    */  import com.ruby.meshi.util.CapabilityExtendInventory;
/*    */  import com.ruby.meshi.util.NetworkHandler;
/*    */  import com.ruby.meshi.world.biome.HiganBiomes;
/*    */  import com.ruby.meshi.world.gen.HiganGenerater;
/*    */  import net.minecraftforge.fml.ModLoadingContext;
/*    */  import net.minecraftforge.fml.common.Mod;
/*    */  import net.minecraftforge.fml.config.ModConfig;
/*    */  import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
/*    */  import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
/*    */  import net.minecraftforge.fml.event.lifecycle.FMLFingerprintViolationEvent;
/*    */  import net.minecraftforge.fml.event.lifecycle.InterModProcessEvent;
/*    */  import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
/*    */  import org.apache.logging.log4j.LogManager;
/*    */  import org.apache.logging.log4j.Logger;
/*    */  
/*    */  
/*    */  @Mod("meshi")
/*    */  public class MeshiMod
/*    */  {
/*    */    public static final String MOD_ID = "meshi";
/* 26 */    public static final Logger LOGGER = LogManager.getLogger();
/*    */ 
/*    */    public MeshiMod() {
/* 29 */      FMLJavaModLoadingContext.get().getModEventBus().addListener(this::preInit);
/* 30 */      FMLJavaModLoadingContext.get().getModEventBus().addListener(this::doClientStuff);
/* 31 */      FMLJavaModLoadingContext.get().getModEventBus().addListener(this::postInit);
/* 32 */      FMLJavaModLoadingContext.get().getModEventBus().addListener(this::noSign);
/*    */      
/* 34 */      ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, SakuraConfig.clientSpec);
/*    */    }
/*    */ 
/*    */ 
/*    */ 
/*    */    private void preInit(FMLCommonSetupEvent event) {
/* 40 */      HiganGenerater.addBiomeGen();
/* 41 */      HiganBiomes.addBiomes();
/* 42 */      NetworkHandler.register();
/* 43 */      (new CapabilityExtendInventory()).register();
/*    */    }
/*    */ 
/*    */ 
/*    */ 
/*    */    private void doClientStuff(FMLClientSetupEvent event) {
/* 49 */      HiganContainerType.registerScreenFactories();
/* 50 */      ClientProxy.renderRegister();
/*    */    }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */    public static String modIDAppend(String str) {
/* 58 */      return "meshi:" + str;
/*    */    }
/*    */ 
/*    */    public static void warnlog(String mes) {
/* 62 */      LOGGER.warn("[meshi]:" + mes);
/*    */    }
/*    */    
/*    */    public void noSign(FMLFingerprintViolationEvent event) {}
/*    */  }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 6 ms
	
*/