/*     */ package com.ruby.meshi.item;
/*     */ 
/*     */ import com.google.common.collect.ArrayListMultimap;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ThreadLocalRandom;
/*     */ import java.util.stream.Collectors;
/*     */ import javax.annotation.Nonnull;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityType;
/*     */ import net.minecraft.entity.LivingEntity;
/*     */ import net.minecraft.entity.projectile.AbstractArrowEntity;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.Items;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.Hand;
/*     */ import net.minecraft.util.IItemProvider;
/*     */ import net.minecraftforge.event.entity.living.LivingDeathEvent;
/*     */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*     */ import net.minecraftforge.fml.common.Mod;
/*     */ import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
/*     */ 
/*     */ 
/*     */ @EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
/*     */ public class KatanaDrop
/*     */ {
/*  27 */   public static final ThreadLocalRandom random = ThreadLocalRandom.current();
/*  28 */   private static final ArrayListMultimap<EntityType<? extends Entity>, KatanaDrop> DROP_TABLE = ArrayListMultimap.create();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private KatanaDrop(Item item, int min, int max, float rate) {
/*  36 */     this.item = item;
/*  37 */     this.min = min;
/*  38 */     this.max = Math.max(min, max);
/*  39 */     this.dropRate = rate;
/*     */   }
/*     */ 
/*     */   public static List<ItemStack> getDrop(EntityType<? extends Entity> entity) {
/*  43 */     return (List<ItemStack>)DROP_TABLE.get(entity).stream().filter(KatanaDrop::canDrop).map(KatanaDrop::getStack).collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */   private boolean canDrop() {
/*  47 */     return (random.nextFloat() < this.dropRate);
/*     */   }
/*     */ 
/*     */   private ItemStack getStack() {
/*  51 */     return new ItemStack((IItemProvider)this.item, (this.max - this.min > 1) ? (random.nextInt(this.max - this.min) + this.min) : this.max);
/*     */   }
/*     */ 
/*     */   public static void addTable(EntityType<? extends Entity> type, Item item, float rate) {
/*  55 */     addTable(type, item, 1, 1, rate);
/*     */   }
/*     */ 
/*     */   public static void addTable(EntityType<? extends Entity> type, Item item, int max, float rate) {
/*  59 */     addTable(type, item, 1, max, rate);
/*     */   }
/*     */ 
/*     */   public static void addTable(EntityType<? extends Entity> type, Item item, int min, int max, float rate) {
/*  63 */     DROP_TABLE.put(type, new KatanaDrop(item, min, max, rate));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static interface KatanaDropListener
/*     */   {
/*     */     boolean canKatanaDrop(@Nonnull LivingEntity param1LivingEntity1, @Nonnull LivingEntity param1LivingEntity2, ItemStack param1ItemStack, Hand param1Hand);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     default void onKatanaDrop(@Nonnull LivingEntity target) {
/*  78 */       List<ItemStack> drop = KatanaDrop.getDrop(target.func_200600_R());
/*  79 */       if (!drop.isEmpty()) {
/*  80 */         target.func_199701_a_(drop.get(KatanaDrop.random.nextInt(drop.size())));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   @SubscribeEvent
/*     */   public static void onKill(LivingDeathEvent event) {
/*  87 */     DamageSource source = event.getSource();
/*  88 */     if (source instanceof net.minecraft.util.EntityDamageSource) {
/*  89 */       Entity entity = source.func_76364_f();
/*  90 */       if (entity instanceof AbstractArrowEntity)
/*     */       {
/*  92 */         entity = ((AbstractArrowEntity)entity).func_212360_k();
/*     */       }
/*  94 */       if (entity instanceof LivingEntity) {
/*  95 */         for (Hand hand : Hand.values()) {
/*  96 */           ItemStack handItem = ((LivingEntity)entity).func_184586_b(hand);
/*  97 */           LivingEntity target = event.getEntityLiving();
/*  98 */           if (target != null && 
/*  99 */             handItem.func_77973_b() instanceof KatanaDropListener && (
/* 100 */             (KatanaDropListener)handItem.func_77973_b()).canKatanaDrop((LivingEntity)entity, target, handItem, hand)) {
/* 101 */             ((KatanaDropListener)handItem.func_77973_b()).onKatanaDrop(target);
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static {
/* 113 */     addTable(EntityType.field_200725_aD, Items.field_151116_aA, 3, 0.2F);
/* 114 */     addTable(EntityType.field_200725_aD, Items.field_151103_aS, 3, 0.2F);
/* 115 */     addTable(EntityType.field_200725_aD, Items.field_196186_dz, 0.002F);
/*     */     
/* 117 */     addTable(EntityType.field_200741_ag, Items.field_196182_dv, 0.002F);
/* 118 */     addTable(EntityType.field_200741_ag, Items.field_196183_dw, 0.001F);
/*     */     
/* 120 */     addTable(EntityType.field_200797_k, Items.field_151016_H, 3, 0.2F);
/* 121 */     addTable(EntityType.field_200797_k, Items.field_221649_bM, 2, 0.01F);
/* 122 */     addTable(EntityType.field_200797_k, Items.field_196185_dy, 0.002F);
/*     */     
/* 124 */     addTable(EntityType.field_200748_an, Items.field_221672_ax, 0.1F);
/*     */     
/* 126 */     addTable(EntityType.field_200811_y, Items.field_151059_bz, 3, 0.5F);
/* 127 */     addTable(EntityType.field_200811_y, Items.field_221649_bM, 4, 0.5F);
/* 128 */     addTable(EntityType.field_200811_y, Items.field_151114_aO, 8, 0.5F);
/*     */     
/* 130 */     addTable(EntityType.field_200803_q, Items.field_221620_aV, 4, 0.5F);
/* 131 */     addTable(EntityType.field_200803_q, Items.field_221619_aU, 4, 0.5F);
/* 132 */     addTable(EntityType.field_200803_q, Items.field_221692_bh, 4, 0.5F);
/* 133 */     addTable(EntityType.field_200803_q, Items.field_221694_bi, 4, 0.5F);
/* 134 */     addTable(EntityType.field_200803_q, Items.field_151061_bv, 3, 0.05F);
/*     */     
/* 136 */     addTable(EntityType.field_200740_af, Items.field_151121_aF, 4, 0.5F);
/*     */     
/* 138 */     addTable(EntityType.field_200792_f, Items.field_151059_bz, 3, 0.1F);
/* 139 */     addTable(EntityType.field_200792_f, Items.field_151072_bj, 8, 0.2F);
/*     */     
/* 141 */     addTable(EntityType.field_200784_X, Items.field_151116_aA, 3, 0.8F);
/*     */     
/* 143 */     addTable(EntityType.field_200737_ac, Items.field_151007_F, 4, 0.5F);
/*     */     
/* 145 */     addTable(EntityType.field_200791_e, Items.field_151034_e, 2, 0.5F);
/* 146 */     addTable(EntityType.field_200791_e, Items.field_151153_ao, 0.01F);
/*     */     
/* 148 */     addTable(EntityType.field_200759_ay, Items.field_151114_aO, 4, 0.5F);
/* 149 */     addTable(EntityType.field_200759_ay, Items.field_221816_dr, 4, 0.5F);
/* 150 */     addTable(EntityType.field_200759_ay, Items.field_151069_bo, 4, 0.5F);
/*     */     
/* 152 */     addTable(EntityType.field_200795_i, Items.field_151110_aK, 2, 0.25F);
/*     */     
/* 154 */     addTable(EntityType.field_200724_aC, Items.field_151103_aS, 2, 0.5F);
/* 155 */     addTable(EntityType.field_200724_aC, Items.field_151082_bd, 4, 0.5F);
/* 156 */     addTable(EntityType.field_200724_aC, Items.field_151147_al, 3, 0.5F);
/* 157 */     addTable(EntityType.field_200724_aC, Items.field_151076_bf, 3, 0.5F);
/* 158 */     addTable(EntityType.field_200724_aC, Items.field_179558_bo, 3, 0.5F);
/* 159 */     addTable(EntityType.field_200724_aC, Items.field_151008_G, 4, 0.5F);
/* 160 */     addTable(EntityType.field_200724_aC, Items.field_179561_bm, 4, 0.5F);
/* 161 */     addTable(EntityType.field_200724_aC, Items.field_151116_aA, 3, 0.3F);
/* 162 */     addTable(EntityType.field_200724_aC, Items.field_179556_br, 0.1F);
/*     */     
/* 164 */     addTable(EntityType.field_200736_ab, Items.field_151116_aA, 0.1F);
/* 165 */     addTable(EntityType.field_200736_ab, Items.field_179556_br, 0.05F);
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 17 ms
	
*/