/*     */ package com.ruby.meshi.client.renderer;
/*     */ 
/*     */ import com.ruby.meshi.block.Hearth;
/*     */ import com.ruby.meshi.block.tileentity.HearthTileEntity;
/*     */ import net.minecraft.block.BlockState;
/*     */ import net.minecraft.client.renderer.entity.model.RendererModel;
/*     */ import net.minecraft.client.renderer.model.Model;
/*     */ import net.minecraft.client.renderer.tileentity.TileEntityRenderer;
/*     */ import net.minecraft.state.IProperty;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.Direction;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class HearthRender
/*     */   extends TileEntityRenderer<HearthTileEntity>
/*     */ {
/*  19 */   private static final ModelHearth model = new ModelHearth();
/*  20 */   private static final ResourceLocation RESOURCE = new ResourceLocation("meshi", "textures/entitys/hearth.png");
/*     */ 
/*     */ 
/*     */   public void render(HearthTileEntity tileEntityIn, double x, double y, double z, float partialTicks, int destroyStage) {
/*  24 */     GL11.glPushMatrix();
/*  25 */     func_147499_a(RESOURCE);
/*  26 */     GL11.glTranslatef((float)x + 0.5F, (float)y, (float)z + 0.5F);
/*  27 */     model.renderWood();
/*     */     
/*  29 */     if (tileEntityIn.func_145831_w() != null && tileEntityIn.func_195044_w() != null) {
/*  30 */       BlockState state = tileEntityIn.func_195044_w();
/*  31 */       GL11.glRotatef((90 * ((Direction)state.func_177229_b((IProperty)Hearth.field_185512_D)).func_176736_b()), 0.0F, 1.0F, 0.0F);
/*  32 */       Hearth.HearthStateType type = (Hearth.HearthStateType)state.func_177229_b((IProperty)Hearth.TYPE);
/*  33 */       if (type == Hearth.HearthStateType.MEAT) {
/*  34 */         model.renderRods();
/*  35 */         model.renderMeat(MathHelper.func_219799_g(partialTicks, tileEntityIn.now_roll, tileEntityIn.next_roll));
/*     */       } 
/*  37 */       if (type == Hearth.HearthStateType.FISH) {
/*  38 */         model.renderFish();
/*     */       }
/*  40 */       if (type == Hearth.HearthStateType.OTHER) {
/*  41 */         model.renderRods();
/*  42 */         model.renderPot();
/*     */       } 
/*     */     } 
/*     */     
/*  46 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */   private static class ModelHearth extends Model {
/*     */     public RendererModel bone;
/*     */     public RendererModel potRod;
/*     */     public RendererModel fish;
/*     */     public RendererModel meat;
/*     */     public RendererModel pot;
/*     */     public RendererModel rod;
/*     */     public RendererModel rod2;
/*     */     public RendererModel wood;
/*  58 */     private float[] rotY = new float[8];
/*  59 */     private float[] rotX = new float[8];
/*  60 */     private float[] fishRotY = new float[4];
/*     */ 
/*     */     public ModelHearth() {
/*  63 */       this.bone = new RendererModel(this, 0, 30);
/*  64 */       this.bone.func_78789_a(-8.0F, -0.5F, -0.5F, 16, 1, 1);
/*  65 */       this.bone.field_78795_f = 6.2831855F;
/*  66 */       this.potRod = new RendererModel(this, 0, 30);
/*  67 */       this.potRod.func_78789_a(-8.0F, 9.0F, -0.5F, 16, 1, 1);
/*  68 */       this.potRod.field_78795_f = 6.2831855F;
/*  69 */       this.fish = new RendererModel(this, 0, 17);
/*  70 */       this.fish.func_78789_a(-1.0F, -12.0F, 5.0F, 3, 13, 0);
/*  71 */       this.fish.func_78793_a(0.0F, 10.0F, 0.0F);
/*  72 */       this.fish.field_78795_f = -0.34906584F;
/*     */       
/*  74 */       this.meat = new RendererModel(this, 8, 18);
/*  75 */       this.meat.func_78789_a(-5.0F, -3.0F, -3.0F, 10, 6, 6);
/*  76 */       this.pot = new RendererModel(this, 6, 0);
/*  77 */       this.pot.func_78789_a(-5.0F, 4.0F, -5.0F, 10, 8, 10);
/*  78 */       this.rod = new RendererModel(this, 0, 0);
/*  79 */       this.rod.func_78789_a(-7.0F, 0.0F, -1.0F, 1, 15, 2);
/*  80 */       this.rod2 = new RendererModel(this, 0, 0);
/*  81 */       this.rod2.func_78789_a(-7.0F, 0.0F, -1.0F, 1, 15, 2);
/*  82 */       this.rod2.field_78796_g = 3.1415927F;
/*  83 */       this.wood = new RendererModel(this, 44, 22);
/*  84 */       this.wood.func_78789_a(-1.0F, 0.0F, -1.0F, 2, 2, 8);
/*  85 */       this.wood.func_78793_a(0.0F, 1.0F, 0.0F);
/*  86 */       this.wood.field_78795_f = 0.34906584F;
/*  87 */       this.meat.func_78792_a(this.bone);
/*     */       int i;
/*  89 */       for (i = 0; i < 7; i++) {
/*  90 */         this.rotY[i] = (float)(161.56762218461793D * i) / 180.0F;
/*  91 */         this.rotX[i] = (i % 2 == 0) ? 0.17453292F : 0.34906584F;
/*     */       } 
/*     */       
/*  94 */       for (i = 0; i < 4; i++) {
/*  95 */         this.fishRotY[i] = (float)(Math.PI * (90 * i + 45)) / 180.0F;
/*     */       }
/*     */     }
/*     */ 
/*     */     public void renderWood() {
/* 100 */       this.wood.func_78793_a(0.0F, 1.0F, 0.0F);
/*     */       
/* 102 */       for (int i = 0; i < 7; i++) {
/* 103 */         this.wood.field_78796_g = this.rotY[i];
/* 104 */         this.wood.field_78795_f = this.rotX[i];
/* 105 */         this.wood.func_78785_a(0.0625F);
/*     */       } 
/*     */     }
/*     */ 
/*     */     public void renderRods() {
/* 110 */       this.rod.func_78785_a(0.0625F);
/* 111 */       this.rod2.func_78785_a(0.0625F);
/*     */     }
/*     */ 
/*     */     public void renderMeat(float roll) {
/* 115 */       this.meat.func_78793_a(0.0F, 11.0F, 0.0F);
/* 116 */       this.meat.field_78795_f = roll;
/* 117 */       this.meat.func_78785_a(0.0625F);
/*     */     }
/*     */ 
/*     */     public void renderFish() {
/* 121 */       for (int i = 0; i < 4; i++) {
/* 122 */         this.fish.field_78796_g = this.fishRotY[i];
/* 123 */         this.fish.func_78785_a(0.0625F);
/*     */       } 
/*     */     }
/*     */ 
/*     */     public void renderPot() {
/* 128 */       this.potRod.func_78785_a(0.0625F);
/* 129 */       this.pot.func_78785_a(0.0625F);
/*     */     }
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 14 ms
	
*/