/*     */ package com.ruby.meshi.client.inventory;
/*     */ import com.mojang.blaze3d.platform.GlStateManager;
/*     */ import com.ruby.meshi.common.inventory.MillstoneContainer;
/*     */ import net.minecraft.client.gui.IGuiEventListener;
/*     */ import net.minecraft.client.gui.recipebook.IRecipeShownListener;
/*     */ import net.minecraft.client.gui.recipebook.RecipeBookGui;
/*     */ import net.minecraft.client.gui.screen.inventory.ContainerScreen;
/*     */ import net.minecraft.client.gui.widget.Widget;
/*     */ import net.minecraft.client.gui.widget.button.Button;
/*     */ import net.minecraft.client.gui.widget.button.ImageButton;
/*     */ import net.minecraft.entity.player.PlayerInventory;
/*     */ import net.minecraft.inventory.container.ClickType;
/*     */ import net.minecraft.inventory.container.Container;
/*     */ import net.minecraft.inventory.container.Slot;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ 
/*     */ public class MillstoneScreen extends ContainerScreen<MillstoneContainer> implements IRecipeShownListener {
/*  19 */   private static final ResourceLocation BOOK_BUTTON = new ResourceLocation("textures/gui/recipe_button.png");
/*  20 */   private static final ResourceLocation TEXTURE = new ResourceLocation("meshi", "textures/guis/millstone_gui.png");
/*     */ 
/*     */ 
/*     */ 
/*     */   public MillstoneScreen(MillstoneContainer screenContainer, PlayerInventory inv, ITextComponent titleIn) {
/*  25 */     super((Container)screenContainer, inv, titleIn);
/*  26 */     this.book = new GrindRecipeBookGui();
/*     */   }
/*     */ 
/*     */ 
/*     */   public void init() {
/*  31 */     super.init();
/*  32 */     this.widthTooNarrow = (this.width < 379);
/*  33 */     this.book.func_201520_a(this.width, this.height, this.minecraft, this.widthTooNarrow, (RecipeBookContainer)this.field_147002_h);
/*  34 */     this.field_147003_i = this.book.func_193011_a(this.widthTooNarrow, this.width, this.field_146999_f);
/*  35 */     this.children.add(this.book);
/*  36 */     func_212928_a((IGuiEventListener)this.book);
/*     */     
/*  38 */     addButton((Widget)new ImageButton(this.field_147003_i + 20, this.height / 2 - 49, 20, 18, 0, 0, 19, BOOK_BUTTON, button -> {
/*     */             this.book.func_201518_a(this.widthTooNarrow);
/*     */             this.book.func_191866_a();
/*     */             this.field_147003_i = this.book.func_193011_a(this.widthTooNarrow, this.width, this.field_146999_f);
/*     */             ((ImageButton)button).func_191746_c(this.field_147003_i + 20, this.height / 2 - 49);
/*     */           }));
/*     */   }
/*     */ 
/*     */ 
/*     */   public void render(int mouseX, int mouseY, float partialTicks) {
/*  48 */     renderBackground();
/*  49 */     if (this.book.func_191878_b() && this.widthTooNarrow) {
/*  50 */       func_146976_a(partialTicks, mouseX, mouseY);
/*  51 */       this.book.render(mouseX, mouseY, partialTicks);
/*     */     } else {
/*  53 */       this.book.render(mouseX, mouseY, partialTicks);
/*  54 */       super.render(mouseX, mouseY, partialTicks);
/*  55 */       this.book.func_191864_a(this.field_147003_i, this.field_147009_r, true, partialTicks);
/*     */     } 
/*     */     
/*  58 */     func_191948_b(mouseX, mouseY);
/*  59 */     this.book.func_191876_c(this.field_147003_i, this.field_147009_r, mouseX, mouseY);
/*  60 */     func_212932_b((IGuiEventListener)this.book);
/*     */   }
/*     */ 
/*     */ 
/*     */   protected void func_146979_b(int mouseX, int mouseY) {
/*  65 */     this.font.func_211126_b(this.title.func_150254_d(), 8.0F, 6.0F, 4210752);
/*     */   }
/*     */ 
/*     */ 
/*     */   protected void func_146976_a(float partialTicks, int mouseX, int mouseY) {
/*  70 */     GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  71 */     this.minecraft.func_110434_K().func_110577_a(TEXTURE);
/*  72 */     int k = this.field_147003_i;
/*  73 */     int l = this.field_147009_r;
/*  74 */     blit(k, l, 0, 0, this.field_146999_f, this.field_147000_g);
/*     */     
/*  76 */     int progress = ((MillstoneContainer)func_212873_a_()).getProgress();
/*     */     
/*  78 */     blit(k + 80, l + 28, 176, 16 * (((MillstoneContainer)func_212873_a_()).getGrindtime() - progress) / 10 % 4, 16, 16);
/*     */ 
/*     */     
/*  81 */     blit(k + 80, l + 46, 192, 6 * getRatio((((MillstoneContainer)func_212873_a_()).getGrindtime() - progress), ((MillstoneContainer)func_212873_a_()).getGrindtime()), 16, 6);
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean mouseClicked(double p_mouseClicked_1_, double p_mouseClicked_3_, int p_mouseClicked_5_) {
/*  86 */     if (this.book.mouseClicked(p_mouseClicked_1_, p_mouseClicked_3_, p_mouseClicked_5_)) {
/*  87 */       return true;
/*     */     }
/*  89 */     return (this.widthTooNarrow && this.book.func_191878_b()) ? true : super.mouseClicked(p_mouseClicked_1_, p_mouseClicked_3_, p_mouseClicked_5_);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void func_184098_a(Slot slotIn, int slotId, int mouseButton, ClickType type) {
/*  95 */     super.func_184098_a(slotIn, slotId, mouseButton, type);
/*  96 */     this.book.func_191874_a(slotIn);
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean keyPressed(int p_keyPressed_1_, int p_keyPressed_2_, int p_keyPressed_3_) {
/* 101 */     return this.book.keyPressed(p_keyPressed_1_, p_keyPressed_2_, p_keyPressed_3_) ? false : super.keyPressed(p_keyPressed_1_, p_keyPressed_2_, p_keyPressed_3_);
/*     */   }
/*     */ 
/*     */ 
/*     */   protected boolean func_195361_a(double p_195361_1_, double p_195361_3_, int p_195361_5_, int p_195361_6_, int p_195361_7_) {
/* 106 */     boolean lvt_8_1_ = (p_195361_1_ < p_195361_5_ || p_195361_3_ < p_195361_6_ || p_195361_1_ >= (p_195361_5_ + this.field_146999_f) || p_195361_3_ >= (p_195361_6_ + this.field_147000_g));
/* 107 */     return (this.book.func_195604_a(p_195361_1_, p_195361_3_, this.field_147003_i, this.field_147009_r, this.field_146999_f, this.field_147000_g, p_195361_7_) && lvt_8_1_);
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean charTyped(char p_charTyped_1_, int p_charTyped_2_) {
/* 112 */     return this.book.charTyped(p_charTyped_1_, p_charTyped_2_) ? true : super.charTyped(p_charTyped_1_, p_charTyped_2_);
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_192043_J_() {
/* 117 */     this.book.func_193948_e();
/*     */   }
/*     */ 
/*     */ 
/*     */   public RecipeBookGui func_194310_f() {
/* 122 */     return this.book;
/*     */   }
/*     */ 
/*     */ 
/*     */   public void removed() {
/* 127 */     this.book.func_191871_c();
/* 128 */     super.removed();
/*     */   }
/*     */ 
/*     */   private int getRatio(float min, float max) {
/* 132 */     return (max - min > 0.0F) ? (Math.round(min / max * 3.0F) % 4) : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   public void tick() {
/* 137 */     super.tick();
/* 138 */     this.book.func_193957_d();
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 14 ms
	
*/