/*    */ package com.ruby.meshi.entity;
/*    */ 
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityType;
/*    */ import net.minecraft.entity.item.ArmorStandEntity;
/*    */ import net.minecraft.entity.player.PlayerEntity;
/*    */ import net.minecraft.network.IPacket;
/*    */ import net.minecraft.util.DamageSource;
/*    */ import net.minecraft.util.Hand;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.network.FMLPlayMessages;
/*    */ import net.minecraftforge.fml.network.NetworkHooks;
/*    */ 
/*    */ public class ScarecrowEntity extends ArmorStandEntity {
/*    */   public ScarecrowEntity(FMLPlayMessages.SpawnEntity packet, World worldIn) {
/* 16 */     super(HiganEntityType.SCARECROW, worldIn);
/*    */   }
/*    */ 
/*    */ 
/*    */   public ScarecrowEntity(World worldIn, double posX, double posY, double posZ) {
/* 21 */     this(HiganEntityType.SCARECROW, worldIn);
/* 22 */     func_70107_b(posX, posY, posZ);
/*    */   }
/*    */ 
/*    */   public ScarecrowEntity(EntityType<ScarecrowEntity> scarecrow, World worldIn) {
/* 26 */     super(HiganEntityType.SCARECROW, worldIn);
/*    */   }
/*    */ 
/*    */ 
/*    */   public IPacket<?> func_213297_N() {
/* 31 */     return NetworkHooks.getEntitySpawningPacket((Entity)this);
/*    */   }
/*    */ 
/*    */ 
/*    */   public boolean func_70097_a(DamageSource source, float amount) {
/* 36 */     if (!this.field_70170_p.field_72995_K && !this.field_70128_L) {
/* 37 */       if (DamageSource.field_76380_i.equals(source)) {
/* 38 */         func_70106_y();
/* 39 */         return false;
/*    */       } 
/* 41 */       System.out.println(amount);
/*    */     } 
/* 43 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   public boolean func_184230_a(PlayerEntity player, Hand hand) {
/* 48 */     if (!func_70089_S()) {
/* 49 */       return false;
/*    */     }
/* 51 */     if (player.func_184586_b(hand).func_190926_b()) {
/* 52 */       func_70106_y();
/*    */     }
/*    */     
/* 55 */     return super.func_184230_a(player, hand);
/*    */   }
/*    */ 
/*    */ 
/*    */   public boolean func_190631_cK() {
/* 60 */     return super.func_190631_cK();
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 5 ms
	
*/