/*    */ package com.ruby.meshi.util.packet;
/*    */ import java.util.Map;
/*    */ import java.util.function.Supplier;
/*    */ import net.minecraft.entity.player.PlayerEntity;
/*    */ import net.minecraft.entity.player.PlayerInventory;
/*    */ import net.minecraft.inventory.container.ContainerType;
/*    */ import net.minecraft.inventory.container.INamedContainerProvider;
/*    */ import net.minecraft.inventory.container.SimpleNamedContainerProvider;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraft.util.text.ITextComponent;
/*    */ import net.minecraft.util.text.TranslationTextComponent;
/*    */ import net.minecraftforge.fml.network.NetworkEvent;
/*    */ 
/*    */ public class ContainerHandler {
/*    */   public ContainerHandler(ResourceLocation loc) {
/* 17 */     this.loc = loc;
/*    */   }
/*    */ 
/*    */   public static void encode(ContainerHandler msg, PacketBuffer buf) {
/* 21 */     buf.func_192572_a(msg.loc);
/*    */   }
/*    */ 
/*    */   public static ContainerHandler decode(PacketBuffer buf) {
/* 25 */     return new ContainerHandler(buf.func_192575_l());
/*    */   }
/*    */ 
/*    */   public ResourceLocation getLocation() {
/* 29 */     return this.loc;
/*    */   }
/*    */ 
/*    */   public static void handle(ContainerHandler message, Supplier<NetworkEvent.Context> ctx) {
/* 33 */     ((NetworkEvent.Context)ctx.get()).enqueueWork(() -> ((NetworkEvent.Context)ctx.get()).getSender().func_213829_a((INamedContainerProvider)new SimpleNamedContainerProvider((), (ITextComponent)new TranslationTextComponent("", new Object[0]))));
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 38 */     ((NetworkEvent.Context)ctx.get()).setPacketHandled(true);
/*    */   }
/*    */ 
/*    */   private static ContainerType<?> getContainerType(ResourceLocation loc) {
/* 42 */     return ForgeRegistries.CONTAINERS.getEntries().stream()
/* 43 */       .filter(e -> ((ResourceLocation)e.getKey()).equals(loc))
/* 44 */       .findFirst()
/* 45 */       .map(e -> (ContainerType)e.getValue())
/* 46 */       .orElse(null);
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 11 ms
	
*/