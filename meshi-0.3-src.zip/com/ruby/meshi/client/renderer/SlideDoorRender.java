/*    */ package com.ruby.meshi.client.renderer;
/*    */ 
/*    */ import com.ruby.meshi.block.SlideDoor;
/*    */ import com.ruby.meshi.block.tileentity.SlideDoorTileEntity;
/*    */ import java.util.Random;
/*    */ import net.minecraft.block.BlockState;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.renderer.BlockRendererDispatcher;
/*    */ import net.minecraft.client.renderer.BufferBuilder;
/*    */ import net.minecraft.client.renderer.chunk.ChunkRenderCache;
/*    */ import net.minecraft.client.renderer.model.IBakedModel;
/*    */ import net.minecraft.state.IProperty;
/*    */ import net.minecraft.state.properties.DoorHingeSide;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.Direction;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.util.math.MathHelper;
/*    */ import net.minecraft.world.IEnviromentBlockReader;
/*    */ import net.minecraftforge.client.MinecraftForgeClient;
/*    */ import net.minecraftforge.client.model.ModelDataManager;
/*    */ import net.minecraftforge.client.model.animation.TileEntityRendererFast;
/*    */ import net.minecraftforge.client.model.data.IModelData;
/*    */ 
/*    */ public class SlideDoorRender extends TileEntityRendererFast<SlideDoorTileEntity> {
/*    */   protected static BlockRendererDispatcher blockRenderer;
/*    */   
/*    */   public void renderTileEntityFast(SlideDoorTileEntity te, double x, double y, double z, float partialTicks, int destroyStage, BufferBuilder buffer) {
/* 28 */     BlockState state = te.func_195044_w();
/* 29 */     BlockPos pos = te.func_174877_v();
/* 30 */     if (blockRenderer == null) {
/* 31 */       blockRenderer = Minecraft.func_71410_x().func_175602_ab();
/*    */     }
/* 33 */     ChunkRenderCache chunkRenderCache = MinecraftForgeClient.getRegionRenderCache(te.func_145831_w(), pos);
/* 34 */     IBakedModel model = blockRenderer.func_175023_a().func_178125_b(state);
/* 35 */     IModelData data = model.getModelData((IEnviromentBlockReader)chunkRenderCache, pos, state, ModelDataManager.getModelData(te.func_145831_w(), pos));
/* 36 */     Direction facing = ((Direction)state.func_177229_b((IProperty)SlideDoor.field_176520_a)).func_176735_f();
/* 37 */     if (state.func_177229_b((IProperty)SlideDoor.field_176521_M) == DoorHingeSide.RIGHT) {
/* 38 */       facing = facing.func_176734_d();
/*    */     }
/* 40 */     BlockPos renderPos = pos.func_177971_a(facing.func_176730_m());
/* 41 */     double renderX = x - renderPos.func_177958_n() + MathHelper.func_219799_g(partialTicks, te.nowPosX, te.posX);
/* 42 */     double renderY = y - renderPos.func_177956_o();
/* 43 */     double renderZ = z - renderPos.func_177952_p() + MathHelper.func_219799_g(partialTicks, te.nowPosZ, te.posZ);
/* 44 */     Random rand = new Random();
/* 45 */     buffer.func_178969_c(renderX, renderY, renderZ);
/* 46 */     blockRenderer.func_175019_b().renderModel((IEnviromentBlockReader)chunkRenderCache, model, state, renderPos, buffer, false, rand, 42L, data);
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 8 ms
	
*/