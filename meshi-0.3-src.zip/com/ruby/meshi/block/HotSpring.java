/*    */ package com.ruby.meshi.block;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.BlockState;
/*    */ import net.minecraft.block.FlowingFluidBlock;
/*    */ import net.minecraft.fluid.FlowingFluid;
/*    */ import net.minecraft.fluid.IFluidState;
/*    */ import net.minecraft.state.EnumProperty;
/*    */ import net.minecraft.state.IProperty;
/*    */ import net.minecraft.state.StateContainer;
/*    */ 
/*    */ @HideCreateTab
/*    */ public class HotSpring
/*    */   extends FlowingFluidBlock
/*    */ {
/* 17 */   public static final EnumProperty<com.ruby.meshi.fluid.HotSpring.SpringColor> COLOR = com.ruby.meshi.fluid.HotSpring.COLOR;
/*    */ 
/*    */   public HotSpring(Supplier<? extends FlowingFluid> supplier, Block.Properties p_i48368_1_) {
/* 20 */     super(supplier, p_i48368_1_);
/* 21 */     func_180632_j((BlockState)func_176223_P().func_206870_a((IProperty)COLOR, com.ruby.meshi.fluid.HotSpring.SpringColor.DEFAULT));
/*    */   }
/*    */ 
/*    */ 
/*    */   protected void func_206840_a(StateContainer.Builder<Block, BlockState> builder) {
/* 26 */     super.func_206840_a(builder);
/* 27 */     builder.func_206894_a(new IProperty[] { (IProperty)COLOR });
/*    */   }
/*    */ 
/*    */ 
/*    */   public IFluidState func_204507_t(BlockState state) {
/* 32 */     return (IFluidState)super.func_204507_t(state).func_206870_a((IProperty)COLOR, state.func_177229_b((IProperty)COLOR));
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 4 ms
	
*/