package com.ruby.meshi.block;

import net.minecraft.block.Block;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.item.Item.Properties;

public interface CustomItemBlock {
   Item EMPTY = Items.field_190931_a;

   default Properties getProperty(Properties prop) {
      return prop;
   }

   default Item getBlockItem(Block block, Properties prop) {
      return new BlockItem(block, this.getProperty(prop));
   }
}