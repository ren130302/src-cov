package com.ruby.meshi.crafting;

import com.ruby.meshi.crafting.GrindRecipe.Serializer;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.item.crafting.IRecipeSerializer;
import net.minecraft.util.ResourceLocation;

public class HiganRecipeSerializer {
   public static final IRecipeSerializer<?> GRIND = register("grind", new Serializer());
   public static final IRecipeSerializer<?> HEARTH = register("hearth", new com.ruby.meshi.crafting.HearthRecipe.Serializer());
   public static final IRecipeSerializer<?> HEARTH_SHAPELESS = register("hearth_shapeless", new com.ruby.meshi.crafting.HearthShapelessRecipe.Serializer());

   private static <T extends IRecipe<?>> IRecipeSerializer<?> register(String key, IRecipeSerializer<T> serializer) {
      return (IRecipeSerializer)serializer.setRegistryName(new ResourceLocation("meshi", key));
   }
}