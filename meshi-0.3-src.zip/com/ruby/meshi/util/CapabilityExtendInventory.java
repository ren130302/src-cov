/*     */ package com.ruby.meshi.util;
/*     */ 
/*     */ import com.google.common.collect.ImmutableList;
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.player.PlayerEntity;
/*     */ import net.minecraft.entity.player.ServerPlayerEntity;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.ItemStackHelper;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.CompoundNBT;
/*     */ import net.minecraft.nbt.INBT;
/*     */ import net.minecraft.nbt.ListNBT;
/*     */ import net.minecraft.util.Direction;
/*     */ import net.minecraft.util.NonNullList;
/*     */ import net.minecraftforge.common.capabilities.Capability;
/*     */ import net.minecraftforge.common.capabilities.CapabilityInject;
/*     */ import net.minecraftforge.common.capabilities.CapabilityManager;
/*     */ import net.minecraftforge.event.entity.player.PlayerEvent;
/*     */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*     */ import net.minecraftforge.fml.common.Mod;
/*     */ import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
/*     */ 
/*     */ 
/*     */ @EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
/*     */ public class CapabilityExtendInventory
/*     */ {
/*     */   @CapabilityInject(ExtendInventory.class)
/*  28 */   public static Capability<ExtendInventory> EXTEND_INVENTORY = null;
/*     */ 
/*     */   public void register() {
/*  31 */     CapabilityManager.INSTANCE.register(ExtendInventory.class, new Capability.IStorage<ExtendInventory>()
/*     */         {
/*     */           public INBT writeNBT(Capability<CapabilityExtendInventory.ExtendInventory> capability, CapabilityExtendInventory.ExtendInventory instance, Direction side) {
/*  34 */             ListNBT nbtTagList = new ListNBT();
/*  35 */             int size = instance.func_70302_i_();
/*  36 */             for (int i = 0; i < size; i++) {
/*  37 */               ItemStack stack = instance.func_70301_a(i);
/*  38 */               if (!stack.func_190926_b()) {
/*  39 */                 CompoundNBT itemTag = new CompoundNBT();
/*  40 */                 itemTag.func_74768_a("Slot", i);
/*  41 */                 stack.func_77955_b(itemTag);
/*  42 */                 nbtTagList.add(itemTag);
/*     */               } 
/*     */             } 
/*  45 */             return (INBT)nbtTagList;
/*     */           }
/*     */ 
/*     */           
/*     */           public void readNBT(Capability<CapabilityExtendInventory.ExtendInventory> capability, CapabilityExtendInventory.ExtendInventory instance, Direction side, INBT base) {
/*  50 */             ListNBT tagList = (ListNBT)base;
/*  51 */             for (int i = 0; i < tagList.size(); i++) {
/*  52 */               CompoundNBT itemTags = tagList.func_150305_b(i);
/*  53 */               int j = itemTags.func_74762_e("Slot");
/*     */               
/*  55 */               if (j >= 0 && j < instance.func_70302_i_()) {
/*  56 */                 instance.func_70299_a(j, ItemStack.func_199557_a(itemTags));
/*     */               }
/*     */             } 
/*     */           }
/*     */         }() -> new ExtendInventory());
/*     */   }
/*     */ 
/*     */   @SubscribeEvent
/*     */   public static void playerClone(PlayerEvent.Clone event) {
/*  65 */     if (event.isWasDeath()) {
/*  66 */       INBT nbt = EXTEND_INVENTORY.writeNBT(getInventory(event.getOriginal()), null);
/*  67 */       EXTEND_INVENTORY.readNBT(getInventory(event.getPlayer()), null, nbt);
/*     */     } 
/*     */   }
/*     */ 
/*     */   @SubscribeEvent
/*     */   public static void palyerJoin(PlayerEvent.PlayerLoggedInEvent event) {
/*  73 */     if (!(event.getEntity().func_130014_f_()).field_72995_K && 
/*  74 */       event.getEntity() instanceof PlayerEntity) {
/*  75 */       NetworkHandler.sendExtendInvCap((ServerPlayerEntity)event.getEntity());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   public static ExtendInventory getInventory(PlayerEntity player) {
/*  81 */     return (ExtendInventory)player.getCapability(EXTEND_INVENTORY).orElse(EXTEND_INVENTORY.getDefaultInstance());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class ExtendInventory
/*     */     implements IInventory
/*     */   {
/*  96 */     public final NonNullList<ItemStack> accessoryInventory = NonNullList.func_191197_a(4, ItemStack.field_190927_a);
/*  97 */     public final NonNullList<ItemStack> etcInventory = NonNullList.func_191197_a(1, ItemStack.field_190927_a);
/*  98 */     private final List<NonNullList<ItemStack>> allInventories = (List<NonNullList<ItemStack>>)ImmutableList.of(this.accessoryInventory, this.etcInventory);
/*     */ 
/*     */     public ItemStack func_70301_a(int index) {
/*     */       NonNullList<ItemStack> nonNullList;
/* 102 */       List<ItemStack> list = null;
/*     */       
/* 104 */       for (NonNullList<ItemStack> nonnulllist : this.allInventories) {
/* 105 */         if (index < nonnulllist.size()) {
/* 106 */           nonNullList = nonnulllist;
/*     */           
/*     */           break;
/*     */         } 
/* 110 */         index -= nonnulllist.size();
/*     */       } 
/*     */       
/* 113 */       return (nonNullList == null) ? ItemStack.field_190927_a : nonNullList.get(index);
/*     */     }
/*     */ 
/*     */ 
/*     */     public void func_174888_l() {
/* 118 */       this.accessoryInventory.clear();
/* 119 */       this.etcInventory.clear();
/*     */     }
/*     */ 
/*     */ 
/*     */     public int func_70302_i_() {
/* 124 */       return this.accessoryInventory.size() + this.etcInventory.size();
/*     */     }
/*     */ 
/*     */ 
/*     */     public boolean func_191420_l() {
/* 129 */       for (ItemStack itemstack1 : this.accessoryInventory) {
/* 130 */         if (!itemstack1.func_190926_b()) {
/* 131 */           return false;
/*     */         }
/*     */       } 
/*     */       
/* 135 */       for (ItemStack itemstack2 : this.etcInventory) {
/* 136 */         if (!itemstack2.func_190926_b()) {
/* 137 */           return false;
/*     */         }
/*     */       } 
/*     */       
/* 141 */       return true;
/*     */     }
/*     */ 
/*     */     public ItemStack func_70298_a(int index, int count) {
/*     */       NonNullList<ItemStack> nonNullList;
/* 146 */       List<ItemStack> list = null;
/*     */       
/* 148 */       for (NonNullList<ItemStack> nonnulllist : this.allInventories) {
/* 149 */         if (index < nonnulllist.size()) {
/* 150 */           nonNullList = nonnulllist;
/*     */           
/*     */           break;
/*     */         } 
/* 154 */         index -= nonnulllist.size();
/*     */       } 
/*     */       
/* 157 */       return (nonNullList != null && !((ItemStack)nonNullList.get(index)).func_190926_b()) ? ItemStackHelper.func_188382_a((List)nonNullList, index, count) : ItemStack.field_190927_a;
/*     */     }
/*     */ 
/*     */ 
/*     */     public ItemStack func_70304_b(int index) {
/* 162 */       NonNullList<ItemStack> nonnulllist = null;
/*     */       
/* 164 */       for (NonNullList<ItemStack> nonnulllist1 : this.allInventories) {
/* 165 */         if (index < nonnulllist1.size()) {
/* 166 */           nonnulllist = nonnulllist1;
/*     */           
/*     */           break;
/*     */         } 
/* 170 */         index -= nonnulllist1.size();
/*     */       } 
/*     */       
/* 173 */       if (nonnulllist != null && !((ItemStack)nonnulllist.get(index)).func_190926_b()) {
/* 174 */         ItemStack itemstack = (ItemStack)nonnulllist.get(index);
/* 175 */         nonnulllist.set(index, ItemStack.field_190927_a);
/* 176 */         return itemstack;
/*     */       } 
/* 178 */       return ItemStack.field_190927_a;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     public void func_70299_a(int index, ItemStack stack) {
/* 184 */       NonNullList<ItemStack> nonnulllist = null;
/*     */       
/* 186 */       for (NonNullList<ItemStack> nonnulllist1 : this.allInventories) {
/* 187 */         if (index < nonnulllist1.size()) {
/* 188 */           nonnulllist = nonnulllist1;
/*     */           
/*     */           break;
/*     */         } 
/* 192 */         index -= nonnulllist1.size();
/*     */       } 
/*     */       
/* 195 */       if (nonnulllist != null) {
/* 196 */         nonnulllist.set(index, stack);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean func_70300_a(PlayerEntity player) {
/* 207 */       return player.func_70089_S();
/*     */     }
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 11 ms
	
*/