/*    */ package com.ruby.meshi.enchant;
/*    */ 
/*    */ import net.minecraft.enchantment.Enchantment;
/*    */ import net.minecraft.enchantment.EnchantmentType;
/*    */ import net.minecraft.enchantment.Enchantments;
/*    */ import net.minecraft.inventory.EquipmentSlotType;
/*    */ import net.minecraft.util.text.ITextComponent;
/*    */ 
/*    */ public class FlameThrow
/*    */   extends Enchantment {
/*    */   protected FlameThrow(Enchantment.Rarity rarityIn, EnchantmentType typeIn, EquipmentSlotType... slots) {
/* 12 */     super(rarityIn, typeIn, slots);
/*    */   }
/*    */ 
/*    */ 
/*    */   public int func_77321_a(int enchantmentLevel) {
/* 17 */     return 20;
/*    */   }
/*    */ 
/*    */ 
/*    */   public int func_223551_b(int enchantmentLevel) {
/* 22 */     return 50;
/*    */   }
/*    */ 
/*    */ 
/*    */   public int func_77325_b() {
/* 27 */     return 1;
/*    */   }
/*    */ 
/*    */ 
/*    */   public ITextComponent func_200305_d(int level) {
/* 32 */     return Enchantments.field_185311_w.func_200305_d(level);
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 1 ms
	
*/