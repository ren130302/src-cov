/*    */ package com.ruby.meshi.block.tileentity;
/*    */ 
/*    */ import com.ruby.meshi.block.SlideDoor;
/*    */ import com.ruby.meshi.init.HiganTileEntityType;
/*    */ import net.minecraft.block.BlockState;
/*    */ import net.minecraft.state.IProperty;
/*    */ import net.minecraft.state.properties.DoorHingeSide;
/*    */ import net.minecraft.tileentity.ITickableTileEntity;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.Direction;
/*    */ 
/*    */ public class SlideDoorTileEntity extends TileEntity implements ITickableTileEntity {
/*    */   public float posX;
/*    */   public float posZ;
/*    */   public float nowPosX;
/*    */   public float nowPosZ;
/*    */   
/*    */   public SlideDoorTileEntity() {
/* 19 */     super(HiganTileEntityType.SLIDEDOOR);
/*    */   }
/*    */ 
/*    */ 
/*    */   public void func_73660_a() {
/* 24 */     this.nowPosX = this.posX;
/* 25 */     this.nowPosZ = this.posZ;
/* 26 */     Direction facing = ((Direction)func_195044_w().func_177229_b((IProperty)SlideDoor.field_176520_a)).func_176735_f();
/* 27 */     if (func_195044_w().func_177229_b((IProperty)SlideDoor.field_176521_M) == DoorHingeSide.RIGHT) {
/* 28 */       facing = facing.func_176734_d();
/*    */     }
/* 30 */     boolean isOpen = ((Boolean)func_195044_w().func_177229_b((IProperty)SlideDoor.field_176519_b)).booleanValue();
/* 31 */     if (isOpen) {
/* 32 */       this.posX = facing.func_82601_c();
/* 33 */       this.posZ = facing.func_82599_e();
/* 34 */       if (this.nowPosX != this.posX && this.nowPosZ != this.posZ && 
/* 35 */         !(func_145831_w()).field_72995_K) {
/* 36 */         func_145831_w().func_180501_a(this.field_174879_c, (BlockState)func_195044_w().func_206870_a((IProperty)SlideDoor.MOVED, Boolean.valueOf(true)), 2);
/*    */       }
/*    */     } else {
/*    */       
/* 40 */       this.posX = 0.0F;
/* 41 */       this.posZ = 0.0F;
/* 42 */       if (this.nowPosX == 0.0F && this.nowPosZ == 0.0F) {
/* 43 */         if (!(func_145831_w()).field_72995_K) {
/* 44 */           func_145831_w().func_180501_a(func_174877_v(), (BlockState)func_195044_w().func_206870_a((IProperty)SlideDoor.MOVED, Boolean.valueOf(false)), 2);
/*    */         }
/* 46 */         func_145831_w().func_175713_t(func_174877_v());
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   public boolean hasFastRenderer() {
/* 53 */     return true;
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 5 ms
	
*/