/*    */ package com.ruby.meshi.enchant;
/*    */ 
/*    */ import net.minecraft.enchantment.Enchantment;
/*    */ import net.minecraft.inventory.EquipmentSlotType;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HiganEnchant
/*    */ {
/* 11 */   public static final Enchantment QUICK_THROW = regiter("quick_throw", new QuickThrow(Enchantment.Rarity.COMMON, HiganEnchantType.BRACELET, new EquipmentSlotType[] { EquipmentSlotType.MAINHAND }));
/* 12 */   public static final Enchantment POWER_THROW = regiter("power_throw", new PowerThrow(Enchantment.Rarity.COMMON, HiganEnchantType.BRACELET, new EquipmentSlotType[] { EquipmentSlotType.MAINHAND }));
/* 13 */   public static final Enchantment CRITICAL_THROW = regiter("critical_throw", new CriticalThrow(Enchantment.Rarity.COMMON, HiganEnchantType.BRACELET, new EquipmentSlotType[] { EquipmentSlotType.MAINHAND }));
/* 14 */   public static final Enchantment POISON_THROW = regiter("poison_throw", new PoisonThrow(Enchantment.Rarity.COMMON, HiganEnchantType.BRACELET, new EquipmentSlotType[] { EquipmentSlotType.MAINHAND }));
/* 15 */   public static final Enchantment SNIPE_THROW = regiter("snipe_throw", new SnipeThrow(Enchantment.Rarity.COMMON, HiganEnchantType.BRACELET, new EquipmentSlotType[] { EquipmentSlotType.MAINHAND }));
/*    */ 
/*    */ 
/* 18 */   public static final Enchantment ECONOMY_BRACELET = regiter("economy_bracelet", new EconomyBracelet(Enchantment.Rarity.UNCOMMON, HiganEnchantType.BRACELET, new EquipmentSlotType[] { EquipmentSlotType.MAINHAND }));
/* 19 */   public static final Enchantment UNBREAKING_BRACELET = regiter("unbreaking_bracelet", new UnbreakingBracelet(Enchantment.Rarity.UNCOMMON, HiganEnchantType.BRACELET, new EquipmentSlotType[] { EquipmentSlotType.MAINHAND }));
/* 20 */   public static final Enchantment PICKPOCKET = regiter("pickpocket", new Pickpocket(Enchantment.Rarity.UNCOMMON, HiganEnchantType.BRACELET, new EquipmentSlotType[] { EquipmentSlotType.MAINHAND }));
/*    */ 
/*    */ 
/* 23 */   public static final Enchantment FLAME_THROW = regiter("flame_throw", new FlameThrow(Enchantment.Rarity.RARE, HiganEnchantType.BRACELET, new EquipmentSlotType[] { EquipmentSlotType.MAINHAND }));
/* 24 */   public static final Enchantment HUNTER_THROW = regiter("hunter_throw", new HunterThrow(Enchantment.Rarity.RARE, HiganEnchantType.BRACELET, new EquipmentSlotType[] { EquipmentSlotType.MAINHAND }));
/* 25 */   public static final Enchantment ROGUE_THROW = regiter("rogue_throw", new RogueThrow(Enchantment.Rarity.RARE, HiganEnchantType.BRACELET, new EquipmentSlotType[] { EquipmentSlotType.MAINHAND }));
/* 26 */   public static final Enchantment MULTI_THROW = regiter("multi_throw", new MultiThrow(Enchantment.Rarity.RARE, HiganEnchantType.BRACELET, new EquipmentSlotType[] { EquipmentSlotType.MAINHAND }));
/* 27 */   public static final Enchantment INFINITY_THROW = regiter("infinity_throw", new InfinityThrow(Enchantment.Rarity.RARE, HiganEnchantType.BRACELET, new EquipmentSlotType[] { EquipmentSlotType.MAINHAND }));
/*    */ 
/*    */ 
/* 30 */   public static final Enchantment ASSASSIN_THROW = regiter("assassin_throw", new AssassinThrow(Enchantment.Rarity.VERY_RARE, HiganEnchantType.BRACELET, new EquipmentSlotType[] { EquipmentSlotType.MAINHAND }));
/* 31 */   public static final Enchantment RETURN_THROW = regiter("return_throw", new ReturnThrow(Enchantment.Rarity.VERY_RARE, HiganEnchantType.BRACELET, new EquipmentSlotType[] { EquipmentSlotType.MAINHAND }));
/*    */ 
/*    */ 
/*    */   private static Enchantment regiter(String key, Enchantment enc) {
/* 35 */     return (Enchantment)enc.setRegistryName(new ResourceLocation("meshi", key));
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 4 ms
	
*/