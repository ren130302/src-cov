/*    */ package com.ruby.meshi.crafting;
/*    */ 
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.inventory.container.RecipeBookContainer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.item.crafting.IRecipe;
/*    */ import net.minecraft.item.crafting.ServerRecipePlacer;
/*    */ 
/*    */ public class ServerRecipePlacerGrind<C extends IInventory>
/*    */   extends ServerRecipePlacer<C> {
/*    */   private IRecipe<?> recipe;
/*    */   
/*    */   public ServerRecipePlacerGrind(RecipeBookContainer<C> p_i50752_1_, IRecipe<?> recipe) {
/* 14 */     super(p_i50752_1_);
/*    */     
/* 16 */     GrindRecipeItemHelper.hookHelper(ServerRecipePlacer.class, this);
/* 17 */     this.recipe = recipe;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   public int func_201509_a(boolean placeAll, int maxPossible, boolean recipeMatches) {
/* 23 */     int i = 1;
/* 24 */     if (this.recipe instanceof GrindRecipe) {
/* 25 */       i = ((GrindRecipe)this.recipe).getRequestCount();
/*    */     }
/* 27 */     if (placeAll) {
/* 28 */       i = maxPossible;
/* 29 */     } else if (recipeMatches) {
/* 30 */       i = 64;
/* 31 */       for (int j = 0; j < this.field_201515_d.func_201770_g() * this.field_201515_d.func_201772_h() + 1; j++) {
/* 32 */         if (j != this.field_201515_d.func_201767_f()) {
/* 33 */           ItemStack itemstack = this.field_201515_d.func_75139_a(j).func_75211_c();
/* 34 */           if (!itemstack.func_190926_b() && i > itemstack.func_190916_E()) {
/* 35 */             i = itemstack.func_190916_E();
/*    */           }
/*    */         } 
/*    */       } 
/* 39 */       if (i < 64) {
/* 40 */         i++;
/*    */       }
/*    */     } 
/* 43 */     return i;
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 3 ms
	
*/