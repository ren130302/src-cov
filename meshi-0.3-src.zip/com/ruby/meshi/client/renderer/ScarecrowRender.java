/*    */ package com.ruby.meshi.client.renderer;
/*    */ 
/*    */ import net.minecraft.client.renderer.entity.ArmorStandRenderer;
/*    */ import net.minecraft.client.renderer.entity.EntityRendererManager;
/*    */ 
/*    */ public class ScarecrowRender
/*    */   extends ArmorStandRenderer {
/*    */   public ScarecrowRender(EntityRendererManager manager) {
/*  9 */     super(manager);
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 1 ms
	
*/