/*    */ package com.ruby.meshi.client.paticle;
/*    */ 
/*    */ import com.ruby.meshi.block.ExtraParticle;
/*    */ import java.util.Random;
/*    */ import net.minecraft.block.BlockState;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.particle.Particle;
/*    */ import net.minecraft.entity.player.PlayerEntity;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.util.math.MathHelper;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.api.distmarker.Dist;
/*    */ import net.minecraftforge.api.distmarker.OnlyIn;
/*    */ import net.minecraftforge.event.TickEvent;
/*    */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*    */ import net.minecraftforge.fml.LogicalSide;
/*    */ import net.minecraftforge.fml.common.Mod;
/*    */ import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
/*    */ 
/*    */ 
/*    */ @EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE, value = {Dist.CLIENT})
/*    */ public class SakuraParticleManager
/*    */ {
/*    */   @SubscribeEvent
/*    */   public static void tick(TickEvent.PlayerTickEvent e) {
/* 26 */     if (e.side == LogicalSide.CLIENT)
/*    */     {
/* 28 */       if (e.phase == TickEvent.Phase.START) {
/* 29 */         PlayerEntity player = e.player;
/* 30 */         World world = player.func_130014_f_();
/* 31 */         BlockPos.MutableBlockPos mutableblockpos = new BlockPos.MutableBlockPos();
/*    */         
/* 33 */         int posX = MathHelper.func_76128_c(player.field_70165_t);
/* 34 */         int posY = MathHelper.func_76128_c(player.field_70163_u);
/* 35 */         int posZ = MathHelper.func_76128_c(player.field_70161_v);
/* 36 */         for (int j = 0; j < 500; j++) {
/* 37 */           animateTick(world, posX, posY, posZ, 32, 32, world.field_73012_v, mutableblockpos);
/* 38 */           animateTick(world, posX, posY, posZ, 64, 32, world.field_73012_v, mutableblockpos);
/*    */         } 
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   private static void animateTick(World world, int x, int y, int z, int xzOffset, int yOffset, Random rand, BlockPos.MutableBlockPos pos) {
/* 46 */     int i = x + rand.nextInt(xzOffset) - rand.nextInt(xzOffset);
/* 47 */     int j = y + rand.nextInt(yOffset) - rand.nextInt(yOffset);
/* 48 */     int k = z + rand.nextInt(xzOffset) - rand.nextInt(xzOffset);
/* 49 */     pos.func_181079_c(i, j, k);
/* 50 */     BlockState blockstate = world.func_180495_p((BlockPos)pos);
/* 51 */     if (blockstate.func_177230_c() instanceof ExtraParticle) {
/* 52 */       ((ExtraParticle)blockstate.func_177230_c()).paticleTick(blockstate, world, (BlockPos)pos, rand);
/*    */     }
/*    */   }
/*    */ 
/*    */   @OnlyIn(Dist.CLIENT)
/*    */   public static void addEffect(Particle p) {
/* 58 */     if (p != null)
/* 59 */       (Minecraft.func_71410_x()).field_71452_i.func_78873_a(p); 
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 4 ms
	
*/