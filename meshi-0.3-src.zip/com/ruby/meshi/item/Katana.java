/*     */ package com.ruby.meshi.item;
/*     */ 
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.ThreadLocalRandom;
/*     */ import net.minecraft.client.renderer.Quaternion;
/*     */ import net.minecraft.client.renderer.Vector3f;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.IProjectile;
/*     */ import net.minecraft.entity.LivingEntity;
/*     */ import net.minecraft.entity.player.PlayerEntity;
/*     */ import net.minecraft.item.IItemTier;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.ItemTier;
/*     */ import net.minecraft.item.SwordItem;
/*     */ import net.minecraft.item.UseAction;
/*     */ import net.minecraft.nbt.CompoundNBT;
/*     */ import net.minecraft.particles.IParticleData;
/*     */ import net.minecraft.particles.ParticleTypes;
/*     */ import net.minecraft.util.ActionResult;
/*     */ import net.minecraft.util.ActionResultType;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.Hand;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.server.ServerWorld;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.event.ForgeEventFactory;
/*     */ import net.minecraftforge.event.entity.living.LivingAttackEvent;
/*     */ import net.minecraftforge.event.entity.player.CriticalHitEvent;
/*     */ import net.minecraftforge.eventbus.api.Event;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Katana
/*     */   extends SwordItem
/*     */   implements KatanaDrop.KatanaDropListener
/*     */ {
/*  48 */   public static final ThreadLocalRandom random = ThreadLocalRandom.current();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Katana(Item.Properties builder) {
/*  54 */     super((IItemTier)ItemTier.IRON, 3, -2.0F, builder);
/*  55 */     func_185043_a(new ResourceLocation("blocking"), (stack, world, entity) -> 
/*  56 */         (entity != null && entity.func_184587_cr() && entity.func_184607_cu() == stack) ? 1.0F : 0.0F);
/*     */ 
/*     */     
/*  59 */     eventBusInit();
/*     */   }
/*     */ 
/*     */   public void eventBusInit() {
/*  63 */     MinecraftForge.EVENT_BUS.addListener(this::onReflect);
/*  64 */     MinecraftForge.EVENT_BUS.addListener(this::onAttack);
/*     */   }
/*     */ 
/*     */ 
/*     */   public ItemStack func_77654_b(ItemStack stack, World worldIn, LivingEntity entityLiving) {
/*  69 */     if (entityLiving instanceof PlayerEntity) {
/*  70 */       ((PlayerEntity)entityLiving).func_184811_cZ().func_185145_a((Item)this, 20);
/*     */     }
/*  72 */     return super.func_77654_b(stack, worldIn, entityLiving);
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_77615_a(ItemStack stack, World worldIn, LivingEntity entityLiving, int timeLeft) {
/*  77 */     if (entityLiving instanceof PlayerEntity) {
/*  78 */       ((PlayerEntity)entityLiving).func_184811_cZ().func_185145_a((Item)this, 20 + timeLeft);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   public void onUsingTick(ItemStack stack, LivingEntity player, int count) {
/*  84 */     super.onUsingTick(stack, player, count);
/*  85 */     World world = player.func_130014_f_();
/*  86 */     if (world.field_72995_K)
/*     */     {
/*  88 */       if (isReflect(count)) {
/*  89 */         Vec3d eyeVec = new Vec3d(random.nextDouble() - 0.375D, -0.15D, 0.6D);
/*  90 */         eyeVec = eyeVec.func_178789_a(-player.field_70125_A * 0.017453292F);
/*  91 */         eyeVec = eyeVec.func_178785_b(-player.field_70177_z * 0.017453292F);
/*  92 */         eyeVec = eyeVec.func_72441_c(player.field_70165_t, player.field_70163_u + player.func_70047_e(), player.field_70161_v);
/*     */         
/*  94 */         double randX = random.nextGaussian() * 0.02D;
/*  95 */         double randY = random.nextGaussian() * 0.02D;
/*  96 */         double randZ = random.nextGaussian() * 0.02D;
/*  97 */         Vec3d vec = player.func_213303_ch().func_72441_c(1.0D, 0.0D, 1.0D);
/*  98 */         vec = Vec3d.func_189984_a(player.func_189653_aC());
/*     */         
/* 100 */         world.func_195594_a((IParticleData)ParticleTypes.field_197614_g, eyeVec.field_72450_a, eyeVec.field_72448_b, eyeVec.field_72449_c, randX, randY, randZ);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   private boolean isReflect(int count) {
/* 107 */     return (count <= 18 && count > 10);
/*     */   }
/*     */ 
/*     */ 
/*     */   public UseAction func_77661_b(ItemStack stack) {
/* 112 */     return UseAction.BLOCK;
/*     */   }
/*     */ 
/*     */ 
/*     */   public int func_77626_a(ItemStack stack) {
/* 117 */     return 20;
/*     */   }
/*     */ 
/*     */ 
/*     */   public ActionResult<ItemStack> func_77659_a(World worldIn, PlayerEntity playerIn, Hand handIn) {
/* 122 */     if (!worldIn.field_72995_K && playerIn instanceof net.minecraft.entity.player.ServerPlayerEntity) {
/*     */       
/* 124 */       ItemStack offStack = playerIn.func_184586_b(Hand.OFF_HAND);
/* 125 */       if (offStack.func_190926_b() || isKatana(offStack) || offStack.func_77973_b() instanceof net.minecraft.item.BlockItem) {
/* 126 */         Hand activateHand = handIn;
/* 127 */         if (offStack.func_77973_b() == this)
/*     */         {
/* 129 */           activateHand = Hand.OFF_HAND;
/*     */         }
/* 131 */         playerIn.func_184598_c(activateHand);
/* 132 */         return new ActionResult(ActionResultType.SUCCESS, playerIn.func_184586_b(handIn));
/*     */       } 
/*     */     } 
/*     */     
/* 136 */     return new ActionResult(ActionResultType.FAIL, playerIn.func_184586_b(handIn));
/*     */   }
/*     */ 
/*     */   public boolean isKatana(ItemStack stack) {
/* 140 */     return stack.func_77973_b() instanceof Katana;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMaxDamage(ItemStack stack) {
/* 146 */     return super.getMaxDamage(stack) / 2;
/*     */   }
/*     */ 
/*     */   public void onReflect(LivingAttackEvent event) {
/* 150 */     DamageSource source = event.getSource();
/* 151 */     LivingEntity entity = event.getEntityLiving();
/* 152 */     if (source != null && entity != null) {
/* 153 */       World world = entity.field_70170_p;
/* 154 */       if (!world.field_72995_K && 
/* 155 */         isKatana(entity.func_184607_cu())) {
/* 156 */         Entity sourceEntity = source.func_76364_f();
/* 157 */         if (sourceEntity != null) {
/* 158 */           if (isReflect(entity.func_184605_cv())) {
/* 159 */             boolean isReflected = false;
/* 160 */             if (sourceEntity instanceof IProjectile && source.func_76352_a()) {
/*     */ 
/*     */               
/* 163 */               Entity reflectEntity = sourceEntity.func_200600_R().func_200721_a(world);
/* 164 */               UUID uuid = reflectEntity.func_110124_au();
/* 165 */               CompoundNBT nbt = sourceEntity.func_189511_e(new CompoundNBT());
/*     */               
/* 167 */               nbt.func_186854_a("UUID", uuid);
/* 168 */               reflectEntity.func_70020_e(nbt);
/* 169 */               sourceEntity.func_70106_y();
/*     */               
/* 171 */               Vec3d vec3d1 = entity.func_213286_i(1.0F);
/* 172 */               Quaternion quaternion = new Quaternion(new Vector3f(vec3d1), 0.0F, true);
/* 173 */               Vec3d vec3d = entity.func_70676_i(1.0F);
/* 174 */               Vector3f vector3f = new Vector3f(vec3d);
/* 175 */               vector3f.func_214905_a(quaternion);
/* 176 */               ((IProjectile)reflectEntity).func_70186_c(vector3f.func_195899_a(), vector3f.func_195900_b(), vector3f.func_195902_c(), 1.6F, 0.0F);
/*     */               
/* 178 */               world.func_217376_c(reflectEntity);
/* 179 */               isReflected = true;
/*     */             }
/* 181 */             else if (sourceEntity instanceof LivingEntity) {
/*     */               
/* 183 */               DamageSource reflectDmg = DamageSource.func_76358_a(entity);
/* 184 */               float targetHealth = ((LivingEntity)sourceEntity).func_110143_aJ();
/* 185 */               sourceEntity.func_70097_a(reflectDmg, event.getAmount() * 2.0F);
/* 186 */               if (entity instanceof PlayerEntity) {
/* 187 */                 float attackedTargetHealth = targetHealth - ((LivingEntity)sourceEntity).func_110143_aJ();
/* 188 */                 int pCount = (int)(attackedTargetHealth * 0.5D);
/* 189 */                 ((ServerWorld)world).func_195598_a((IParticleData)ParticleTypes.field_197615_h, sourceEntity.field_70165_t, sourceEntity.field_70163_u + (sourceEntity.func_213302_cg() * 0.5F), sourceEntity.field_70161_v, pCount, 0.1D, 0.0D, 0.1D, 0.2D);
/*     */               } 
/*     */               
/* 192 */               isReflected = true;
/*     */             } 
/* 194 */             if (isReflected && 
/* 195 */               entity instanceof PlayerEntity) {
/* 196 */               double d0 = -MathHelper.func_76126_a(entity.field_70177_z * 0.017453292F);
/* 197 */               double d1 = MathHelper.func_76134_b(entity.field_70177_z * 0.017453292F);
/* 198 */               ((ServerWorld)world).func_195598_a((IParticleData)ParticleTypes.field_197603_N, entity.field_70165_t + d0, entity.field_70163_u + entity.func_213302_cg() * 0.75D, entity.field_70161_v + d1, 0, d0, 0.0D, d1, 0.0D);
/*     */             } 
/*     */             
/* 201 */             event.setCanceled(isReflected);
/*     */           
/*     */           }
/* 204 */           else if (entity instanceof PlayerEntity) {
/* 205 */             entity.func_184607_cu().func_222118_a((MathHelper.func_76141_d(event.getAmount()) + 1) * 2, entity, p -> {
/*     */                   p.func_213334_d(entity.func_184600_cs());
/*     */                   ForgeEventFactory.onPlayerDestroyItem((PlayerEntity)entity, entity.func_184607_cu(), entity.func_184600_cs());
/*     */                 });
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onAttack(CriticalHitEvent event) {
/* 218 */     PlayerEntity player = event.getPlayer();
/*     */     
/* 220 */     if (isTwoHanded((LivingEntity)player)) {
/*     */ 
/*     */       
/* 223 */       event.setDamageModifier(getCritRate(event.getTarget()));
/* 224 */       event.setResult(Event.Result.ALLOW);
/*     */     } 
/*     */   }
/*     */ 
/*     */   public float getCritRate(Entity entity) {
/* 229 */     float mod = 1.5F;
/*     */ 
/*     */     
/* 232 */     if (entity instanceof net.minecraft.entity.monster.SlimeEntity || entity instanceof net.minecraft.entity.passive.CatEntity || entity instanceof net.minecraft.entity.passive.OcelotEntity) {
/* 233 */       mod = 0.0F;
/* 234 */     } else if (entity instanceof net.minecraft.entity.monster.ZombieEntity || entity instanceof net.minecraft.entity.monster.CreeperEntity || entity instanceof net.minecraft.entity.monster.SpiderEntity) {
/* 235 */       mod = 2.0F;
/* 236 */     } else if (entity instanceof net.minecraft.entity.passive.AnimalEntity) {
/* 237 */       mod = 4.0F;
/* 238 */     } else if (entity instanceof net.minecraft.entity.monster.SkeletonEntity) {
/* 239 */       mod = 1.0F;
/* 240 */     } else if (entity instanceof net.minecraft.entity.monster.BlazeEntity) {
/* 241 */       mod = 0.7F;
/* 242 */     } else if (entity instanceof net.minecraft.entity.passive.GolemEntity) {
/* 243 */       mod = 0.1F;
/*     */     } 
/* 245 */     return mod;
/*     */   }
/*     */ 
/*     */   public boolean isTwoHanded(LivingEntity entity) {
/* 249 */     return (isKatana(entity.func_184614_ca()) && entity.func_184592_cb().func_190926_b());
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean canKatanaDrop(LivingEntity source, LivingEntity target, ItemStack stack, Hand hand) {
/* 254 */     return isTwoHanded(source);
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 27 ms
	
*/