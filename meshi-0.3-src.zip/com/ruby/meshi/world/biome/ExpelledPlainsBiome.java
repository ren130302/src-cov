package com.ruby.meshi.world.biome;

import net.minecraft.world.biome.DefaultBiomeFeatures;
import net.minecraft.world.biome.Biome.Builder;
import net.minecraft.world.biome.Biome.Category;
import net.minecraft.world.biome.Biome.RainType;
import net.minecraft.world.gen.surfacebuilders.SurfaceBuilder;

public class ExpelledPlainsBiome extends ExpelledBaseBiome {
   protected ExpelledPlainsBiome() {
      super((new Builder()).func_222351_a(SurfaceBuilder.field_215396_G, SurfaceBuilder.field_215425_v).func_205415_a(RainType.RAIN).func_205419_a(Category.PLAINS).func_205421_a(0.25F).func_205420_b(0.0125F).func_205414_c(0.8F).func_205417_d(0.4F).func_205412_a(4159204).func_205413_b(329011).func_205418_a((String)null));
      DefaultBiomeFeatures.func_222300_a(this);
      DefaultBiomeFeatures.func_222333_d(this);
      DefaultBiomeFeatures.func_222283_Y(this);
      DefaultBiomeFeatures.func_222282_l(this);
      DefaultBiomeFeatures.func_222299_R(this);
      DefaultBiomeFeatures.func_222315_Z(this);
      DefaultBiomeFeatures.func_222311_aa(this);
      DefaultBiomeFeatures.func_222337_am(this);
      DefaultBiomeFeatures.func_222297_ap(this);
   }
}