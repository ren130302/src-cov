/*    */ package com.ruby.meshi.util;
/*    */ 
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.nbt.CompoundNBT;
/*    */ import net.minecraft.nbt.INBT;
/*    */ import net.minecraft.nbt.ListNBT;
/*    */ import net.minecraft.util.Direction;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraftforge.common.capabilities.Capability;
/*    */ import net.minecraftforge.common.capabilities.ICapabilityProvider;
/*    */ import net.minecraftforge.common.capabilities.ICapabilitySerializable;
/*    */ import net.minecraftforge.common.util.LazyOptional;
/*    */ import net.minecraftforge.event.AttachCapabilitiesEvent;
/*    */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*    */ import net.minecraftforge.fml.common.Mod;
/*    */ import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
/*    */ 
/*    */ @EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
/*    */ public class CapabilityHandler
/*    */ {
/* 22 */   public static final ResourceLocation EXTEND_INVENTORY = new ResourceLocation("meshi", "extend_inv");
/*    */ 
/*    */   @SubscribeEvent
/*    */   public static void attach(AttachCapabilitiesEvent<Entity> event) {
/* 26 */     if (event.getObject() instanceof net.minecraft.entity.player.PlayerEntity)
/* 27 */       event.addCapability(EXTEND_INVENTORY, (ICapabilityProvider)new CapExtendInvProvider()); 
/*    */   }
/*    */ 
/*    */   static class CapExtendInvProvider
/*    */     implements ICapabilitySerializable<ListNBT>
/*    */   {
/* 33 */     CapabilityExtendInventory.ExtendInventory inv = (CapabilityExtendInventory.ExtendInventory)CapabilityExtendInventory.EXTEND_INVENTORY.getDefaultInstance();
/* 34 */     LazyOptional<CapabilityExtendInventory.ExtendInventory> opt = LazyOptional.of(() -> this.inv);
/*    */ 
/*    */ 
/*    */     public <T> LazyOptional<T> getCapability(Capability<T> cap, Direction side) {
/* 38 */       if (cap == CapabilityExtendInventory.EXTEND_INVENTORY)
/*    */       {
/*    */         
/* 41 */         return this.opt.cast();
/*    */       }
/* 43 */       return LazyOptional.empty();
/*    */     }
/*    */ 
/*    */ 
/*    */     public ListNBT serializeNBT() {
/* 48 */       ListNBT list = new ListNBT();
/*    */       
/* 50 */       for (int j = 0; j < this.inv.accessoryInventory.size(); j++) {
/* 51 */         if (!((ItemStack)this.inv.accessoryInventory.get(j)).func_190926_b()) {
/* 52 */           CompoundNBT compoundnbt1 = new CompoundNBT();
/* 53 */           compoundnbt1.func_74774_a("Slot", (byte)j);
/* 54 */           ((ItemStack)this.inv.accessoryInventory.get(j)).func_77955_b(compoundnbt1);
/* 55 */           list.add(compoundnbt1);
/*    */         } 
/*    */       } 
/*    */       
/* 59 */       for (int k = 0; k < this.inv.etcInventory.size(); k++) {
/* 60 */         if (!((ItemStack)this.inv.etcInventory.get(k)).func_190926_b()) {
/* 61 */           CompoundNBT compoundnbt2 = new CompoundNBT();
/* 62 */           compoundnbt2.func_74774_a("Slot", (byte)(k + 50));
/* 63 */           ((ItemStack)this.inv.etcInventory.get(k)).func_77955_b(compoundnbt2);
/* 64 */           list.add(compoundnbt2);
/*    */         } 
/*    */       } 
/*    */       
/* 68 */       return list;
/*    */     }
/*    */ 
/*    */ 
/*    */     public void deserializeNBT(ListNBT nbt) {
/* 73 */       this.inv.accessoryInventory.clear();
/* 74 */       this.inv.etcInventory.clear();
/*    */       
/* 76 */       for (int i = 0; i < nbt.size(); i++) {
/* 77 */         CompoundNBT compoundnbt = nbt.func_150305_b(i);
/* 78 */         int j = compoundnbt.func_74771_c("Slot") & 0xFF;
/* 79 */         ItemStack itemstack = ItemStack.func_199557_a(compoundnbt);
/* 80 */         if (!itemstack.func_190926_b())
/* 81 */           if (j >= 0 && j < this.inv.accessoryInventory.size() + 50) {
/* 82 */             this.inv.accessoryInventory.set(j, itemstack);
/* 83 */           } else if (j >= 50 && j < this.inv.etcInventory.size() + 100) {
/* 84 */             this.inv.etcInventory.set(j - 50, itemstack);
/*    */           }  
/*    */       } 
/*    */     }
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 6 ms
	
*/