package com.ruby.meshi.block;

import net.minecraft.block.Block;
import net.minecraft.block.Block.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome.TempCategory;

public class FermentedCask extends Block {
   public FermentedCask(Properties properties) {
      super(properties);
   }

   public void getType(World worldIn, BlockPos pos) {
      TempCategory temp = worldIn.func_180494_b(pos).func_150561_m();
   }
}