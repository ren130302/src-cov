/*     */ package com.ruby.meshi.client.renderer;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.GlStateManager;
/*     */ import com.ruby.meshi.block.tileentity.WallShelfTileEntity;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.renderer.texture.AtlasTexture;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.state.IProperty;
/*     */ import net.minecraft.state.properties.BlockStateProperties;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.Direction;
/*     */ 
/*     */ public class WallShelfItemRender extends SimpleItemRender<WallShelfTileEntity> {
/*  14 */   private final Minecraft mc = Minecraft.func_71410_x();
/*     */ 
/*     */ 
/*     */ 
/*     */   public void render(WallShelfTileEntity entity, double x, double y, double z, float partialTicks, int destroyStage) {
/*  19 */     (this.mc.func_175598_ae()).field_78724_e.func_110577_a(AtlasTexture.field_110575_b);
/*     */     
/*  21 */     GlStateManager.enableLighting();
/*  22 */     if (entity.isDouble()) {
/*  23 */       renderDouble(entity, x, y, z, partialTicks, destroyStage);
/*     */     }
/*  25 */     GlStateManager.enableLighting();
/*     */   }
/*     */ 
/*     */ 
/*     */   private void renderDouble(WallShelfTileEntity entity, double x, double y, double z, float partialTicks, int destroyStage) {
/*  30 */     Direction dir = (Direction)entity.func_195044_w().func_177229_b((IProperty)BlockStateProperties.field_208157_J);
/*     */ 
/*     */     
/*  33 */     int rotateYaw = getRotation(dir);
/*  34 */     if (entity.hasItem((byte)0)) {
/*  35 */       double renderX = getRightOffsetX(dir) + x;
/*  36 */       double renderZ = getRightOffsetZ(dir) + z;
/*  37 */       renderItem(entity.func_70301_a(0), renderX, y, renderZ, rotateYaw);
/*     */     } 
/*  39 */     if (entity.hasItem((byte)1)) {
/*  40 */       double renderX = getLeftOffsetX(dir) + x;
/*  41 */       double renderZ = getLeftOffsetZ(dir) + z;
/*  42 */       renderItem(entity.func_70301_a(1), renderX, y, renderZ, rotateYaw);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void renderItem(ItemStack stack, double x, double y, double z, int rotateYaw) {
/*  52 */     renderItem(stack, s -> GlStateManager.translated(x + 0.5D, y + (this.mc.func_175599_af().func_175050_a(s) ? 0.5D : 0.6D), z + 0.5D), s -> GlStateManager.rotatef((180 - rotateYaw), 0.0F, 1.0F, 0.0F), 0.5F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRotation(Direction dir) {
/*  61 */     switch (dir) {
/*     */       case EAST:
/*     */       case WEST:
/*  64 */         return 90;
/*     */     } 
/*  66 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   public double getRightOffsetX(Direction dir) {
/*  71 */     switch (dir) {
/*     */       case EAST:
/*     */       case NORTH:
/*  74 */         return 0.25D;
/*     */       case WEST:
/*     */       case SOUTH:
/*  77 */         return -0.25D;
/*     */     } 
/*  79 */     return 0.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */   public double getRightOffsetZ(Direction dir) {
/*  84 */     switch (dir) {
/*     */       case EAST:
/*     */       case SOUTH:
/*  87 */         return 0.25D;
/*     */       case WEST:
/*     */       case NORTH:
/*  90 */         return -0.25D;
/*     */     } 
/*  92 */     return 0.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */   public double getLeftOffsetX(Direction dir) {
/*  97 */     switch (dir) {
/*     */       case EAST:
/*     */       case SOUTH:
/* 100 */         return 0.25D;
/*     */       case WEST:
/*     */       case NORTH:
/* 103 */         return -0.25D;
/*     */     } 
/* 105 */     return 0.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */   public double getLeftOffsetZ(Direction dir) {
/* 110 */     switch (dir) {
/*     */       case WEST:
/*     */       case SOUTH:
/* 113 */         return 0.25D;
/*     */       case EAST:
/*     */       case NORTH:
/* 116 */         return -0.25D;
/*     */     } 
/* 118 */     return 0.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */   public double getSingleOffsetX(Direction dir) {
/* 123 */     return 0.0D;
/*     */   }
/*     */ 
/*     */   public double geSingleOffsetZ(Direction dir) {
/* 127 */     return 0.0D;
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 8 ms
	
*/