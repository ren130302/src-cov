package com.ruby.meshi.block;

import net.minecraft.block.SaplingBlock;
import net.minecraft.block.Block.Properties;
import net.minecraft.block.trees.Tree;

public class SakuraSapling extends SaplingBlock {
   public SakuraSapling(Tree p_i48337_1_, Properties properties) {
      super(p_i48337_1_, properties);
   }
}