/*     */ package com.ruby.meshi.block.tileentity;
/*     */ 
/*     */ import com.ruby.meshi.init.HiganTileEntityType;
/*     */ import java.util.List;
/*     */ import java.util.function.Supplier;
/*     */ import net.minecraft.entity.player.PlayerEntity;
/*     */ import net.minecraft.entity.player.PlayerInventory;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.ItemStackHelper;
/*     */ import net.minecraft.inventory.container.Container;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.CompoundNBT;
/*     */ import net.minecraft.tileentity.LockableTileEntity;
/*     */ import net.minecraft.util.Direction;
/*     */ import net.minecraft.util.NonNullList;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TranslationTextComponent;
/*     */ import net.minecraftforge.common.capabilities.Capability;
/*     */ import net.minecraftforge.common.util.LazyOptional;
/*     */ import net.minecraftforge.items.CapabilityItemHandler;
/*     */ import net.minecraftforge.items.IItemHandlerModifiable;
/*     */ import net.minecraftforge.items.wrapper.InvWrapper;
/*     */ 
/*     */ public class ContainerTileEntity
/*     */   extends LockableTileEntity
/*     */ {
/*     */   NonNullList<ItemStack> contents;
/*     */   Supplier<MeshiContainer> container = () -> (MeshiContainer)func_195044_w().func_177230_c();
/*     */   private LazyOptional<IItemHandlerModifiable> chestHandler;
/*     */   
/*     */   public ContainerTileEntity() {
/*  32 */     super(HiganTileEntityType.JPCHEST);
/*     */   }
/*     */ 
/*     */   public ContainerTileEntity setContainerBlock(MeshiContainer container) {
/*  36 */     this.container = (() -> container);
/*  37 */     this.contents = NonNullList.func_191197_a(func_70302_i_(), ItemStack.field_190927_a);
/*  38 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_191420_l() {
/*  43 */     for (ItemStack itemstack : this.contents) {
/*  44 */       if (!itemstack.func_190926_b()) {
/*  45 */         return false;
/*     */       }
/*     */     } 
/*  48 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   public ItemStack func_70301_a(int index) {
/*  53 */     return (ItemStack)this.contents.get(index);
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_70299_a(int index, ItemStack stack) {
/*  58 */     this.contents.set(index, stack);
/*  59 */     if (stack.func_190916_E() > func_70297_j_()) {
/*  60 */       stack.func_190920_e(func_70297_j_());
/*     */     }
/*  62 */     func_70296_d();
/*     */   }
/*     */ 
/*     */ 
/*     */   public ItemStack func_70304_b(int index) {
/*  67 */     return ItemStackHelper.func_188383_a((List)this.contents, index);
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_174888_l() {
/*  72 */     this.contents.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_70300_a(PlayerEntity player) {
/*  77 */     if (this.field_145850_b.func_175625_s(this.field_174879_c) != this) {
/*  78 */       return false;
/*     */     }
/*  80 */     return (player.func_70092_e(this.field_174879_c.func_177958_n() + 0.5D, this.field_174879_c.func_177956_o() + 0.5D, this.field_174879_c.func_177952_p() + 0.5D) <= 64.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   public ItemStack func_70298_a(int index, int count) {
/*  86 */     ItemStack itemstack = ItemStackHelper.func_188382_a((List)this.contents, index, count);
/*  87 */     if (!itemstack.func_190926_b()) {
/*  88 */       func_70296_d();
/*     */     }
/*  90 */     return itemstack;
/*     */   }
/*     */ 
/*     */ 
/*     */   public ITextComponent func_213907_g() {
/*  95 */     return (ITextComponent)new TranslationTextComponent("container.chest", new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */   public int func_70302_i_() {
/* 100 */     return ((MeshiContainer)this.container.get()).getSize();
/*     */   }
/*     */ 
/*     */ 
/*     */   protected Container func_213906_a(int id, PlayerInventory player) {
/* 105 */     return ((MeshiContainer)this.container.get()).createMenu(id, player, (IInventory)this);
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_174889_b(PlayerEntity player) {
/* 110 */     if (!player.func_175149_v()) {
/* 111 */       openOrClose(player);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_174886_c(PlayerEntity player) {
/* 117 */     if (!player.func_175149_v()) {
/* 118 */       openOrClose(player);
/*     */     }
/*     */   }
/*     */ 
/*     */   void openOrClose(PlayerEntity player) {
/* 123 */     if (this.field_145850_b.func_175625_s(func_174877_v()) instanceof ContainerTileEntity) {
/* 124 */       this.field_145850_b.func_195593_d(this.field_174879_c, func_195044_w().func_177230_c());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_145839_a(CompoundNBT compound) {
/* 130 */     super.func_145839_a(compound);
/* 131 */     this.contents = NonNullList.func_191197_a(compound.func_74762_e("invsize"), ItemStack.field_190927_a);
/* 132 */     ItemStackHelper.func_191283_b(compound, this.contents);
/*     */   }
/*     */ 
/*     */ 
/*     */   public CompoundNBT func_189515_b(CompoundNBT compound) {
/* 137 */     super.func_189515_b(compound);
/* 138 */     compound.func_74768_a("invsize", func_70302_i_());
/* 139 */     ItemStackHelper.func_191282_a(compound, this.contents);
/* 140 */     return compound;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void func_145836_u() {
/* 152 */     super.func_145836_u();
/* 153 */     if (this.chestHandler != null) {
/* 154 */       this.chestHandler.invalidate();
/* 155 */       this.chestHandler = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_145843_s() {
/* 161 */     super.func_145843_s();
/* 162 */     if (this.chestHandler != null) {
/* 163 */       this.chestHandler.invalidate();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   public <T> LazyOptional<T> getCapability(Capability<T> cap, Direction side) {
/* 169 */     if (!this.field_145846_f && cap == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY) {
/* 170 */       if (this.chestHandler == null) {
/* 171 */         this.chestHandler = LazyOptional.of(() -> new InvWrapper((IInventory)this));
/*     */       }
/* 173 */       return this.chestHandler.cast();
/*     */     } 
/* 175 */     return super.getCapability(cap, side);
/*     */   }
/*     */   
/*     */   public static interface MeshiContainer {
/*     */     int getSize();
/*     */     
/*     */     Container createMenu(int param1Int, PlayerInventory param1PlayerInventory, IInventory param1IInventory);
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 9 ms
	
*/