/*    */ package com.ruby.meshi.util;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Arrays;
/*    */ import java.util.stream.Stream;
/*    */ import sun.misc.Unsafe;
/*    */ import sun.reflect.ConstructorAccessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnumHelper
/*    */ {
/*    */   public static <T extends Enum<?>> T addEnum(Class<T> target, String name, int ordinal, Class<?>[] paramTypes, Object[] param) {
/*    */     Enum enum_;
/* 27 */     T result = null;
/*    */     try {
/* 29 */       Method m = Constructor.class.getDeclaredMethod("acquireConstructorAccessor", new Class[0]);
/* 30 */       m.setAccessible(true);
/*    */       
/* 32 */       Constructor<T> cnst = target.getDeclaredConstructor((Class[])Stream.concat(Stream.of((Object[])new Class[] { String.class, int.class }, ), Arrays.stream((Object[])paramTypes)).toArray(x$0 -> new Class[x$0]));
/* 33 */       ConstructorAccessor ca = (ConstructorAccessor)m.invoke(cnst, new Object[0]);
/*    */       
/* 35 */       Object[] args = Stream.concat(Stream.of((Object[])new Serializable[] { name, Integer.valueOf(ordinal) }, ), Arrays.stream(param)).toArray();
/* 36 */       enum_ = (Enum)ca.newInstance(args);
/*    */       
/* 38 */       addValueToEnum(enum_);
/* 39 */     } catch (Exception e) {
/* 40 */       e.printStackTrace();
/*    */     } 
/*    */     
/* 43 */     return (T)enum_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   private static <T extends Enum<?>> void addValueToEnum(T newValue) throws Exception {
/*    */     Field f;
/*    */     try {
/* 51 */       f = newValue.getClass().getDeclaredField("$VALUES");
/* 52 */     } catch (NoSuchFieldException e) {
/*    */       
/* 54 */       f = newValue.getClass().getDeclaredField("ENUM$VALUES");
/*    */     } 
/* 56 */     Field uf = Unsafe.class.getDeclaredField("theUnsafe");
/* 57 */     f.setAccessible(true);
/* 58 */     uf.setAccessible(true);
/* 59 */     Enum[] arrayOfEnum1 = (Enum[])f.get(null);
/* 60 */     Enum[] arrayOfEnum2 = Arrays.<Enum>copyOf(arrayOfEnum1, arrayOfEnum1.length + 1);
/* 61 */     arrayOfEnum2[arrayOfEnum1.length] = (Enum)newValue;
/*    */     
/* 63 */     Unsafe unsafe = (Unsafe)uf.get(null);
/* 64 */     unsafe.putObjectVolatile(unsafe.staticFieldBase(f), unsafe.staticFieldOffset(f), arrayOfEnum2);
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 9 ms
	
*/