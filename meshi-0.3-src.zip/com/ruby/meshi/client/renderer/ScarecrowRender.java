package com.ruby.meshi.client.renderer;

import net.minecraft.client.renderer.entity.ArmorStandRenderer;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class ScarecrowRender extends ArmorStandRenderer {
   public ScarecrowRender(EntityRendererManager manager) {
      super(manager);
   }
}