/*    */ package com.ruby.meshi.world.biome;
/*    */ 
/*    */ import net.minecraft.world.biome.Biome;
/*    */ import net.minecraftforge.common.BiomeManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HiganBiomes
/*    */ {
/* 11 */   public static Biome EX_PLAINS_BIOME = register("expelledplains", new ExpelledPlainsBiome());
/* 12 */   public static Biome EX_AUTUMN_BIOME = register("expelledautumn", new ExpelledAutumnBiome());
/* 13 */   public static Biome EX_SPRING_BIOME = register("expelledspring", new ExpelledSpringBiome());
/*    */ 
/*    */   private static Biome register(String key, Biome biomeIn) {
/* 16 */     biomeIn.setRegistryName("meshi", key);
/* 17 */     return biomeIn;
/*    */   }
/*    */ 
/*    */   public static void addBiomes() {
/* 21 */     BiomeManager.addBiome(BiomeManager.BiomeType.WARM, new BiomeManager.BiomeEntry(EX_PLAINS_BIOME, 15));
/* 22 */     BiomeManager.addBiome(BiomeManager.BiomeType.WARM, new BiomeManager.BiomeEntry(EX_AUTUMN_BIOME, 10));
/* 23 */     BiomeManager.addBiome(BiomeManager.BiomeType.WARM, new BiomeManager.BiomeEntry(EX_SPRING_BIOME, 5));
/* 24 */     BiomeManager.addSpawnBiome(EX_PLAINS_BIOME);
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 2 ms
	
*/