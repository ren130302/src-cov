/*    */ package com.ruby.meshi.block.decorate;
/*    */ 
/*    */ import com.ruby.meshi.block.CustomItemBlock;
/*    */ import com.ruby.meshi.client.CreativeTab;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.BlockState;
/*    */ import net.minecraft.entity.EntityType;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.IBlockReader;
/*    */ 
/*    */ public class DecorateBlock
/*    */   extends Block
/*    */   implements CustomItemBlock {
/*    */   public DecorateBlock(Block.Properties properties) {
/* 16 */     super(properties);
/*    */   }
/*    */ 
/*    */ 
/*    */   public Item.Properties getProperty(Item.Properties prop) {
/* 21 */     return prop.func_200916_a(CreativeTab.DECO_GROUP);
/*    */   }
/*    */ 
/*    */ 
/*    */   public boolean func_220067_a(BlockState state, IBlockReader worldIn, BlockPos pos, EntityType<?> type) {
/* 26 */     return false;
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 1 ms
	
*/