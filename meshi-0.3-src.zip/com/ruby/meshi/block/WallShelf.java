/*     */ package com.ruby.meshi.block;
/*     */ 
/*     */ import com.ruby.meshi.block.tileentity.WallShelfTileEntity;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockRenderType;
/*     */ import net.minecraft.block.BlockState;
/*     */ import net.minecraft.block.ContainerBlock;
/*     */ import net.minecraft.entity.EntityType;
/*     */ import net.minecraft.entity.LivingEntity;
/*     */ import net.minecraft.entity.player.PlayerEntity;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.InventoryHelper;
/*     */ import net.minecraft.item.BlockItemUseContext;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.state.DirectionProperty;
/*     */ import net.minecraft.state.IProperty;
/*     */ import net.minecraft.state.StateContainer;
/*     */ import net.minecraft.state.properties.BlockStateProperties;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.BlockRenderLayer;
/*     */ import net.minecraft.util.Direction;
/*     */ import net.minecraft.util.Hand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.BlockRayTraceResult;
/*     */ import net.minecraft.util.math.shapes.ISelectionContext;
/*     */ import net.minecraft.util.math.shapes.VoxelShape;
/*     */ import net.minecraft.world.IBlockReader;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.api.distmarker.Dist;
/*     */ import net.minecraftforge.api.distmarker.OnlyIn;
/*     */ 
/*     */ public class WallShelf
/*     */   extends ContainerBlock {
/*  34 */   public static final VoxelShape AABB_EAST = Block.func_208617_a(8.0D, 5.0D, 0.0D, 16.0D, 6.0D, 16.0D);
/*  35 */   public static final VoxelShape AABB_WEST = Block.func_208617_a(0.0D, 5.0D, 0.0D, 8.0D, 6.0D, 16.0D);
/*  36 */   public static final VoxelShape AABB_NORTH = Block.func_208617_a(0.0D, 5.0D, 0.0D, 16.0D, 6.0D, 8.0D);
/*  37 */   public static final VoxelShape AABB_SOUTH = Block.func_208617_a(0.0D, 5.0D, 8.0D, 16.0D, 6.0D, 16.0D);
/*     */ 
/*  39 */   public static final DirectionProperty HORIZONTAL_FACING = BlockStateProperties.field_208157_J;
/*     */ 
/*     */   public WallShelf(Block.Properties properties) {
/*  42 */     super(properties);
/*  43 */     func_180632_j((BlockState)((BlockState)this.field_176227_L.func_177621_b()).func_206870_a((IProperty)HORIZONTAL_FACING, (Comparable)Direction.NORTH));
/*     */   }
/*     */ 
/*     */ 
/*     */   public BlockState func_196258_a(BlockItemUseContext context) {
/*  48 */     return (BlockState)func_176223_P().func_206870_a((IProperty)HORIZONTAL_FACING, (Comparable)context.func_195992_f());
/*     */   }
/*     */ 
/*     */ 
/*     */   protected void func_206840_a(StateContainer.Builder<Block, BlockState> builder) {
/*  53 */     builder.func_206894_a(new IProperty[] { (IProperty)HORIZONTAL_FACING });
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_180633_a(World worldIn, BlockPos pos, BlockState state, LivingEntity placer, ItemStack stack) {
/*  58 */     super.func_180633_a(worldIn, pos, state, placer, stack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean func_220051_a(BlockState state, World worldIn, BlockPos pos, PlayerEntity player, Hand handIn, BlockRayTraceResult hit) {
/*  64 */     if (!worldIn.field_72995_K) {
/*  65 */       Direction dir = (Direction)state.func_177229_b((IProperty)HORIZONTAL_FACING);
/*  66 */       WallShelfTileEntity tile = (WallShelfTileEntity)worldIn.func_175625_s(pos);
/*  67 */       double hitX = Math.abs(pos.func_177958_n() - hit.func_216347_e().func_82615_a());
/*  68 */       double hitZ = Math.abs(pos.func_177952_p() - hit.func_216347_e().func_82616_c());
/*  69 */       boolean isUpdated = false;
/*  70 */       if (hitX < 0.5D) {
/*  71 */         if (hitZ < 0.5D) {
/*     */           
/*  73 */           if (dir == Direction.NORTH) {
/*  74 */             isUpdated = useTileContiner(tile, (byte)1, worldIn, pos, player, handIn);
/*     */           } else {
/*  76 */             isUpdated = useTileContiner(tile, (byte)0, worldIn, pos, player, handIn);
/*     */           }
/*     */         
/*     */         }
/*  80 */         else if (dir == Direction.SOUTH) {
/*  81 */           isUpdated = useTileContiner(tile, (byte)0, worldIn, pos, player, handIn);
/*     */         } else {
/*  83 */           isUpdated = useTileContiner(tile, (byte)1, worldIn, pos, player, handIn);
/*     */         }
/*     */       
/*     */       }
/*  87 */       else if (hitZ < 0.5D) {
/*     */         
/*  89 */         if (dir == Direction.NORTH) {
/*  90 */           isUpdated = useTileContiner(tile, (byte)0, worldIn, pos, player, handIn);
/*     */         } else {
/*  92 */           isUpdated = useTileContiner(tile, (byte)1, worldIn, pos, player, handIn);
/*     */         }
/*     */       
/*     */       }
/*  96 */       else if (dir == Direction.SOUTH) {
/*  97 */         isUpdated = useTileContiner(tile, (byte)1, worldIn, pos, player, handIn);
/*     */       } else {
/*  99 */         isUpdated = useTileContiner(tile, (byte)0, worldIn, pos, player, handIn);
/*     */       } 
/*     */ 
/*     */       
/* 103 */       if (isUpdated) {
/* 104 */         worldIn.func_184138_a(pos, state, state, 2);
/* 105 */         worldIn.func_195592_c(pos, (Block)this);
/*     */       } 
/*     */     } 
/* 108 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean useTileContiner(WallShelfTileEntity tile, byte side, World worldIn, BlockPos pos, PlayerEntity player, Hand handIn) {
/* 112 */     boolean isCreative = player.func_184812_l_();
/* 113 */     if (tile.hasItem(side)) {
/* 114 */       ItemStack itemStack = tile.func_70304_b(side);
/* 115 */       if (!isCreative) {
/* 116 */         InventoryHelper.func_180173_a(worldIn, pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p(), itemStack);
/*     */       }
/* 118 */       return true;
/*     */     } 
/* 120 */     ItemStack stack = player.func_184586_b(handIn);
/* 121 */     if (!stack.func_190926_b()) {
/* 122 */       if (isCreative) {
/* 123 */         ItemStack copy = stack.func_77946_l();
/* 124 */         copy.func_190920_e(1);
/* 125 */         tile.func_70299_a(side, copy);
/*     */       } else {
/* 127 */         tile.func_70299_a(side, stack.func_77979_a(1));
/*     */       } 
/* 129 */       return true;
/*     */     } 
/*     */     
/* 132 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_196243_a(BlockState state, World worldIn, BlockPos pos, BlockState newState, boolean isMoving) {
/* 137 */     if (state.func_177230_c() != newState.func_177230_c()) {
/* 138 */       TileEntity tileentity = worldIn.func_175625_s(pos);
/* 139 */       if (tileentity instanceof IInventory) {
/* 140 */         InventoryHelper.func_180175_a(worldIn, pos, (IInventory)tileentity);
/* 141 */         worldIn.func_175666_e(pos, (Block)this);
/*     */       } 
/*     */       
/* 144 */       super.func_196243_a(state, worldIn, pos, newState, isMoving);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   public VoxelShape func_220053_a(BlockState state, IBlockReader worldIn, BlockPos pos, ISelectionContext context) {
/* 150 */     Direction dir = (Direction)state.func_177229_b((IProperty)HORIZONTAL_FACING);
/*     */     
/* 152 */     switch (dir) {
/*     */       case EAST:
/* 154 */         return AABB_EAST;
/*     */       case WEST:
/* 156 */         return AABB_WEST;
/*     */       case SOUTH:
/* 158 */         return AABB_SOUTH;
/*     */       case NORTH:
/* 160 */         return AABB_NORTH;
/*     */     } 
/* 162 */     return super.func_220053_a(state, worldIn, pos, context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   public BlockRenderType func_149645_b(BlockState state) {
/* 168 */     return BlockRenderType.MODEL;
/*     */   }
/*     */ 
/*     */ 
/*     */   public TileEntity func_196283_a_(IBlockReader worldIn) {
/* 173 */     return (TileEntity)new WallShelfTileEntity();
/*     */   }
/*     */ 
/*     */ 
/*     */   public BlockRenderLayer func_180664_k() {
/* 178 */     return BlockRenderLayer.CUTOUT;
/*     */   }
/*     */ 
/*     */ 
/*     */   @OnlyIn(Dist.CLIENT)
/*     */   public boolean func_200122_a(BlockState state, BlockState adjacentBlockState, Direction side) {
/* 184 */     return (adjacentBlockState.func_177230_c() == this) ? true : super.func_200122_a(state, adjacentBlockState, side);
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_200123_i(BlockState state, IBlockReader reader, BlockPos pos) {
/* 189 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_220060_c(BlockState state, IBlockReader worldIn, BlockPos pos) {
/* 194 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_220081_d(BlockState state, IBlockReader worldIn, BlockPos pos) {
/* 199 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_220067_a(BlockState state, IBlockReader worldIn, BlockPos pos, EntityType<?> type) {
/* 204 */     return false;
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 11 ms
	
*/