/*    */ package com.ruby.meshi.client.renderer.animation;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import net.minecraft.util.Direction;
/*    */ import net.minecraft.util.math.MathHelper;
/*    */ 
/*    */ 
/*    */ public class SwingHead
/*    */   implements EntityModelAnimation
/*    */ {
/*    */   float prevMoveAmount;
/*    */   float moveAmount;
/*    */   float prevRotateYaw;
/*    */   float rotateYaw;
/*    */   float prevRotatePitch;
/*    */   float rotatePitch;
/* 17 */   int timer = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public SwingHead(Direction direction) {
/* 25 */     this.direction = direction;
/* 26 */     this.maxTimer = 600 + rand.nextInt(600);
/* 27 */     this.moveTime = 8 + rand.nextInt(4) - 2;
/* 28 */     this.moveAmount = 0.37F;
/* 29 */     this.lookX = this.lookY = 0.0F;
/*    */   }
/*    */ 
/*    */ 
/*    */   public void animationTick() {
/* 34 */     this.prevMoveAmount = this.moveAmount;
/* 35 */     this.prevRotateYaw = this.rotateYaw;
/* 36 */     this.prevRotatePitch = this.rotatePitch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 44 */     headMove();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   void headMove() {
/* 50 */     if (Math.abs(this.lookX - this.rotatePitch) > 0.1F) {
/* 51 */       this.rotatePitch = lerp(0.2F, this.rotatePitch, this.lookX);
/* 52 */       this.rotateYaw = lerp(0.2F, this.rotateYaw, this.lookY);
/* 53 */     } else if (rand.nextFloat() < 0.001F) {
/* 54 */       this.lookX = 70.0F * rand.nextFloat() - 35.0F;
/* 55 */       this.lookX += 10.0F * Math.signum(this.lookX);
/* 56 */       this.lookX = MathHelper.func_76131_a(this.lookX, -35.0F, 35.0F);
/* 57 */       this.lookY = 17.5F * rand.nextFloat() - 8.75F;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   public boolean isFinished() {
/* 63 */     return (this.timer > this.maxTimer);
/*    */   }
/*    */ 
/*    */ 
/*    */   public boolean shouldRenderPart(EntityModelAnimation.RenderPart part) {
/* 68 */     return (part == EntityModelAnimation.RenderPart.HEAD);
/*    */   }
/*    */ 
/*    */ 
/*    */   public void translatef(TriConsumer<Float, Float, Float> position, float partialTicks) {
/* 73 */     position.accept(Float.valueOf(getDiractionOffsetVal(lerp(partialTicks, this.prevMoveAmount, this.moveAmount), this.direction, Direction.Axis.X)), 
/* 74 */         Float.valueOf(0.0F), 
/* 75 */         Float.valueOf(getDiractionOffsetVal(lerp(partialTicks, this.prevMoveAmount, this.moveAmount), this.direction, Direction.Axis.Z)));
/*    */   }
/*    */ 
/*    */ 
/*    */   public void rotateY(Consumer<Float> angle, float partialTicks) {
/* 80 */     angle.accept(Float.valueOf(lerp(partialTicks, this.prevRotatePitch, this.rotatePitch)));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   public void rotateX(Consumer<Float> angle, float partialTicks) {
/* 86 */     angle.accept(Float.valueOf(-getDiractionVal(lerp(partialTicks, this.prevRotateYaw, this.rotateYaw), this.direction, Direction.Axis.Z)));
/*    */   }
/*    */ 
/*    */ 
/*    */   public void rotateZ(Consumer<Float> angle, float partialTicks) {
/* 91 */     angle.accept(Float.valueOf(getDiractionOffsetVal(lerp(partialTicks, this.prevRotateYaw, this.rotateYaw), this.direction, Direction.Axis.X)));
/*    */   }
/*    */ 
/*    */ 
/*    */   public int getMaxTimer() {
/* 96 */     return this.maxTimer;
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 5 ms
	
*/