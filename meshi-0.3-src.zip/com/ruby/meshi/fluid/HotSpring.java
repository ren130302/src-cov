/*     */ package com.ruby.meshi.fluid;
/*     */ 
/*     */ import com.ruby.meshi.block.SakuraBlocks;
/*     */ import com.ruby.meshi.block.SpringSpawner;
/*     */ import com.ruby.meshi.item.HiganItems;
/*     */ import java.util.Arrays;
/*     */ import java.util.Random;
/*     */ import java.util.Set;
/*     */ import net.minecraft.block.BlockState;
/*     */ import net.minecraft.block.FlowingFluidBlock;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.ItemEntity;
/*     */ import net.minecraft.fluid.Fluid;
/*     */ import net.minecraft.fluid.Fluids;
/*     */ import net.minecraft.fluid.IFluidState;
/*     */ import net.minecraft.fluid.WaterFluid;
/*     */ import net.minecraft.item.DyeColor;
/*     */ import net.minecraft.item.DyeItem;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.Items;
/*     */ import net.minecraft.particles.IParticleData;
/*     */ import net.minecraft.particles.ParticleTypes;
/*     */ import net.minecraft.state.EnumProperty;
/*     */ import net.minecraft.state.IProperty;
/*     */ import net.minecraft.state.StateContainer;
/*     */ import net.minecraft.tags.Tag;
/*     */ import net.minecraft.util.Direction;
/*     */ import net.minecraft.util.IStringSerializable;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.SoundCategory;
/*     */ import net.minecraft.util.SoundEvents;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.CubeCoordinateIterator;
/*     */ import net.minecraft.world.IEnviromentBlockReader;
/*     */ import net.minecraft.world.IWorld;
/*     */ import net.minecraft.world.IWorldReader;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.biome.Biome;
/*     */ import net.minecraftforge.api.distmarker.Dist;
/*     */ import net.minecraftforge.api.distmarker.OnlyIn;
/*     */ import net.minecraftforge.common.BiomeDictionary;
/*     */ import net.minecraftforge.fluids.FluidAttributes;
/*     */ 
/*     */ public abstract class HotSpring
/*     */   extends WaterFluid
/*     */ {
/*  49 */   public static final EnumProperty<SpringColor> COLOR = EnumProperty.func_177709_a("color", SpringColor.class);
/*     */ 
/*     */ 
/*     */   HotSpring() {
/*  53 */     func_207183_f((IFluidState)func_207188_f().func_206870_a((IProperty)COLOR, SpringColor.DEFAULT));
/*     */   }
/*     */ 
/*     */ 
/*     */   protected void func_207184_a(StateContainer.Builder<Fluid, IFluidState> builder) {
/*  58 */     super.func_207184_a(builder);
/*  59 */     builder.func_206894_a(new IProperty[] { (IProperty)COLOR });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEntityInside(IFluidState state, IWorldReader reader, BlockPos pos, Entity entity, double yToTest, Tag<Fluid> tag, boolean testingHead) {
/*  65 */     if (!reader.func_201670_d() && 
/*  66 */       entity instanceof ItemEntity) {
/*  67 */       ItemStack stack = ((ItemEntity)entity).func_92059_d();
/*  68 */       if (stack.func_77973_b() instanceof DyeItem) {
/*  69 */         DyeColor dye = ((DyeItem)stack.func_77973_b()).func_195962_g();
/*  70 */         SpringColor dyeToColor = SpringColor.getColorToDye(dye);
/*  71 */         SpringColor stateColor = (SpringColor)state.func_177229_b((IProperty)COLOR);
/*  72 */         if (dyeToColor != null && dye != stateColor.dye) {
/*  73 */           IWorld world = reader.func_217349_x(pos).getWorldForge();
/*  74 */           if (world != null) {
/*  75 */             Set<BlockPos> fluidPos = SpringSpawner.getFluidToList(reader, pos, (Fluid)this, 100);
/*  76 */             if (dye == DyeColor.BLACK) {
/*  77 */               dyeToColor = SpringColor.DEFAULT;
/*     */             }
/*  79 */             for (BlockPos p : fluidPos) {
/*  80 */               world.func_180501_a(p, (BlockState)world.func_204610_c(p).func_206883_i().func_206870_a((IProperty)COLOR, dyeToColor), 3);
/*     */             }
/*     */             
/*  83 */             stack.func_190918_g(1);
/*     */           } 
/*     */         } 
/*  86 */       } else if (stack.func_77973_b() == Items.field_151123_aH) {
/*  87 */         IWorld world = reader.func_217349_x(pos).getWorldForge();
/*  88 */         if (world != null) {
/*  89 */           Set<BlockPos> fluidPos = SpringSpawner.getFluidToList(reader, pos, (Fluid)this, 100);
/*  90 */           fluidPos.forEach(p -> world.func_180501_a(p, (BlockState)world.func_204610_c(p).func_206883_i().func_206870_a((IProperty)COLOR, SpringColor.VANILLA), 3));
/*  91 */           stack.func_190918_g(1);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  96 */     return super.isEntityInside(state, reader, pos, entity, yToTest, tag, testingHead);
/*     */   }
/*     */ 
/*     */ 
/*     */   protected void func_205574_a(IWorld worldIn, BlockPos pos, BlockState blockStateIn, Direction direction, IFluidState fluidStateIn) {
/* 101 */     super.func_205574_a(worldIn, pos, blockStateIn, direction, (IFluidState)fluidStateIn.func_206870_a((IProperty)COLOR, worldIn.func_180495_p(pos.func_177972_a(direction.func_176734_d())).func_177229_b((IProperty)COLOR)));
/*     */   }
/*     */ 
/*     */ 
/*     */   protected IFluidState func_205576_a(IWorldReader worldIn, BlockPos pos, BlockState blockStateIn) {
/* 106 */     IFluidState state = super.func_205576_a(worldIn, pos, blockStateIn);
/* 107 */     return (state.func_206886_c() == getFluid() && blockStateIn.func_177230_c() == SakuraBlocks.HOT_SPRING) ? (IFluidState)state.func_206870_a((IProperty)COLOR, blockStateIn.func_204520_s().func_177229_b((IProperty)COLOR)) : state;
/*     */   }
/*     */ 
/*     */ 
/*     */   public Fluid func_210197_e() {
/* 112 */     return (Fluid)MeshiFluids.FLOWING_HOT_SPING;
/*     */   }
/*     */ 
/*     */ 
/*     */   public Fluid func_210198_f() {
/* 117 */     return (Fluid)MeshiFluids.HOT_SPING;
/*     */   }
/*     */ 
/*     */ 
/*     */   public Item func_204524_b() {
/* 122 */     return HiganItems.HOT_SPRING_BUCKET;
/*     */   }
/*     */ 
/*     */ 
/*     */   @OnlyIn(Dist.CLIENT)
/*     */   public void func_204522_a(World worldIn, BlockPos pos, IFluidState state, Random random) {
/* 128 */     super.func_204522_a(worldIn, pos, state, random);
/*     */     
/* 130 */     if (worldIn.func_175623_d(pos.func_177984_a()) && random.nextFloat() < 0.05F) {
/* 131 */       double d0 = (pos.func_177958_n() + random.nextFloat());
/* 132 */       double d1 = (pos.func_177956_o() + 0.2F + state.func_206882_g() * 0.1F);
/* 133 */       double d2 = (pos.func_177952_p() + random.nextFloat());
/* 134 */       float color = 0.7F + 0.1F * random.nextFloat();
/* 135 */       (Minecraft.func_71410_x()).field_71452_i.func_199280_a((IParticleData)ParticleTypes.field_197601_L, d0, d1, d2, 0.0D, 0.0D, 0.0D).func_70538_b(color, color, color);
/*     */     } 
/* 137 */     Biome biome = worldIn.func_180494_b(pos);
/* 138 */     float bubbleRate = BiomeDictionary.getTypes(biome).contains(BiomeDictionary.Type.NETHER) ? 0.2F : 0.02F;
/*     */     
/* 140 */     if (state.func_206889_d() && random.nextFloat() < bubbleRate) {
/* 141 */       double d0 = (pos.func_177958_n() + random.nextFloat());
/* 142 */       double d1 = (pos.func_177956_o() + 0.5F * random.nextFloat());
/* 143 */       double d2 = (pos.func_177952_p() + random.nextFloat());
/* 144 */       (Minecraft.func_71410_x()).field_71452_i.func_199280_a((IParticleData)ParticleTypes.field_197612_e, d0, d1, d2, 0.0D, 0.5D, 0.0D);
/* 145 */       worldIn.func_184134_a(d0, d1, d2, SoundEvents.field_203253_U, SoundCategory.BLOCKS, random.nextFloat() * 0.25F + 0.5F, random.nextFloat() + 0.5F, false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   public BlockState func_204527_a(IFluidState state) {
/* 151 */     return (BlockState)((BlockState)SakuraBlocks.HOT_SPRING.func_176223_P().func_206870_a((IProperty)FlowingFluidBlock.field_176367_b, Integer.valueOf(func_207205_e(state)))).func_206870_a((IProperty)COLOR, state.func_177229_b((IProperty)COLOR));
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_207187_a(Fluid fluidIn) {
/* 156 */     return (fluidIn == MeshiFluids.HOT_SPING || fluidIn == MeshiFluids.FLOWING_HOT_SPING);
/*     */   }
/*     */ 
/*     */ 
/*     */   protected boolean func_205579_d() {
/* 161 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   protected FluidAttributes createAttributes() {
/* 167 */     return (FluidAttributes)new HotWater(FluidAttributes.Water.builder(new ResourceLocation("block/water_still"), new ResourceLocation("block/water_flow"))
/*     */ 
/*     */         
/* 170 */         .overlay(new ResourceLocation("block/water_overlay"))
/* 171 */         .translationKey("block.meshi.hot_spring")
/* 172 */         .color(-12618012), (Fluid)this);
/*     */   }
/*     */ 
/*     */   public static class Flowing
/*     */     extends HotSpring {
/*     */     protected void func_207184_a(StateContainer.Builder<Fluid, IFluidState> builder) {
/* 178 */       super.func_207184_a(builder);
/* 179 */       builder.func_206894_a(new IProperty[] { (IProperty)field_207210_b });
/*     */     }
/*     */ 
/*     */ 
/*     */     public int func_207192_d(IFluidState state) {
/* 184 */       return ((Integer)state.func_177229_b((IProperty)field_207210_b)).intValue();
/*     */     }
/*     */ 
/*     */ 
/*     */     public boolean func_207193_c(IFluidState state) {
/* 189 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class Source
/*     */     extends HotSpring {
/*     */     public int func_207192_d(IFluidState state) {
/* 196 */       return 8;
/*     */     }
/*     */ 
/*     */ 
/*     */     public boolean func_207193_c(IFluidState state) {
/* 201 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class HotWater extends FluidAttributes.Water {
/*     */     protected HotWater(FluidAttributes.Builder builder, Fluid fluid) {
/* 207 */       super(builder, fluid);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getColor(IEnviromentBlockReader world, BlockPos pos) {
/* 213 */       int a = 0;
/* 214 */       int r = 0;
/* 215 */       int g = 0;
/* 216 */       int b = 0;
/* 217 */       int l = Math.min((Minecraft.func_71410_x()).field_71474_y.field_205217_U, 2);
/* 218 */       int i1 = (l * 2 + 1) * (l * 2 + 1);
/*     */       
/* 220 */       CubeCoordinateIterator cubecoordinateiterator = new CubeCoordinateIterator(pos.func_177958_n() - l, pos.func_177956_o(), pos.func_177952_p() - l, pos.func_177958_n() + l, pos.func_177956_o(), pos.func_177952_p() + l);
/*     */ 
/*     */       
/* 223 */       for (BlockPos.MutableBlockPos blockpos$mutableblockpos = new BlockPos.MutableBlockPos(); cubecoordinateiterator.func_218301_a(); ) {
/* 224 */         int j1; blockpos$mutableblockpos.func_181079_c(cubecoordinateiterator.func_218304_b(), cubecoordinateiterator.func_218302_c(), cubecoordinateiterator.func_218303_d());
/* 225 */         IFluidState fstate = world.func_204610_c((BlockPos)blockpos$mutableblockpos);
/* 226 */         if (fstate.func_206886_c() == Fluids.field_204541_a) {
/* 227 */           i1--;
/*     */           continue;
/*     */         } 
/* 230 */         HotSpring.SpringColor cstate = (fstate.func_206886_c() instanceof HotSpring) ? (HotSpring.SpringColor)world.func_204610_c((BlockPos)blockpos$mutableblockpos).func_177229_b((IProperty)HotSpring.COLOR) : HotSpring.SpringColor.VANILLA;
/* 231 */         switch (cstate) {
/*     */           case DEFAULT:
/* 233 */             j1 = getSpringColor(world, (BlockPos)blockpos$mutableblockpos);
/*     */             break;
/*     */           case VANILLA:
/* 236 */             j1 = super.getColor(world, (BlockPos)blockpos$mutableblockpos);
/*     */             break;
/*     */           default:
/* 239 */             j1 = cstate.color;
/*     */             break;
/*     */         } 
/* 242 */         a += j1 >> 24 & 0xFF;
/* 243 */         r += j1 >> 16 & 0xFF;
/* 244 */         g += j1 >> 8 & 0xFF;
/* 245 */         b += j1 & 0xFF;
/*     */       } 
/* 247 */       return (a / i1 & 0xFF) << 24 | (r / i1 & 0xFF) << 16 | (g / i1 & 0xFF) << 8 | b / i1 & 0xFF;
/*     */     }
/*     */ 
/*     */ 
/*     */     int getSpringColor(IEnviromentBlockReader world, BlockPos pos) {
/* 252 */       Biome biome = world.func_180494_b(pos);
/* 253 */       Set<BiomeDictionary.Type> type = BiomeDictionary.getTypes(biome);
/* 254 */       if (biome instanceof com.ruby.meshi.world.biome.ExpelledBaseBiome) {
/* 255 */         return HotSpring.SpringColor.PINK.color;
/*     */       }
/* 257 */       return ((Integer)Arrays.<HotSpring.SpringColor>stream(HotSpring.SpringColor.values())
/* 258 */         .filter(c -> Arrays.<BiomeDictionary.Type>stream(c.type).anyMatch(type::contains))
/* 259 */         .findFirst()
/* 260 */         .map(c -> Integer.valueOf(c.color))
/* 261 */         .orElse(Integer.valueOf(biome.func_185361_o() | 0xFF000000))).intValue();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     int colorMarge(int from, int to, int margeCount) {
/* 286 */       int a = (from >> 24 & 0xFF) + (to >> 24 & 0xFF) / margeCount;
/* 287 */       int r = (from >> 16 & 0xFF) + (to >> 16 & 0xFF) / margeCount;
/* 288 */       int g = (from >> 8 & 0xFF) + (to >> 8 & 0xFF) / margeCount;
/* 289 */       int b = (from & 0xFF) + (to & 0xFF) / margeCount;
/* 290 */       return a / 2 << 24 | r / 2 << 16 | g / 2 << 8 | b / 2;
/*     */     }
/*     */   }
/*     */ 
/*     */   public enum SpringColor
/*     */     implements IStringSerializable {
/* 296 */     DEFAULT(0, new BiomeDictionary.Type[0]),
/* 297 */     VANILLA(0, new BiomeDictionary.Type[0]),
/* 298 */     WHITE((String)DyeColor.WHITE, -3355966, (DyeColor)new BiomeDictionary.Type[] { BiomeDictionary.Type.RIVER }),
/* 299 */     ORANGE((String)DyeColor.ORANGE, -14948, (DyeColor)new BiomeDictionary.Type[] { BiomeDictionary.Type.MESA }),
/* 300 */     MAGENTA((String)DyeColor.MAGENTA, -363777, (DyeColor)new BiomeDictionary.Type[0]),
/* 301 */     LIGHT_BLUE((String)DyeColor.LIGHT_BLUE, -9576202, (DyeColor)new BiomeDictionary.Type[] { BiomeDictionary.Type.BEACH }),
/* 302 */     YELLOW((String)DyeColor.YELLOW, -3695, (DyeColor)new BiomeDictionary.Type[] { BiomeDictionary.Type.SANDY }),
/* 303 */     LIME((String)DyeColor.LIME, -5965430, (DyeColor)new BiomeDictionary.Type[] { BiomeDictionary.Type.FOREST }),
/* 304 */     PINK((String)DyeColor.PINK, -29042, (DyeColor)new BiomeDictionary.Type[0]),
/* 305 */     GRAY((String)DyeColor.GRAY, -12895429, (DyeColor)new BiomeDictionary.Type[] { BiomeDictionary.Type.SWAMP }),
/* 306 */     LIGHT_GRAY((String)DyeColor.LIGHT_GRAY, -9211021, (DyeColor)new BiomeDictionary.Type[0]),
/* 307 */     CYAN((String)DyeColor.CYAN, -9309744, (DyeColor)new BiomeDictionary.Type[] { BiomeDictionary.Type.OCEAN }),
/* 308 */     PURPLE((String)DyeColor.PURPLE, -5083137, (DyeColor)new BiomeDictionary.Type[] { BiomeDictionary.Type.END }),
/* 309 */     BLUE((String)DyeColor.BLUE, -8153857, (DyeColor)new BiomeDictionary.Type[] { BiomeDictionary.Type.PLAINS }),
/* 310 */     BROWN((String)DyeColor.BROWN, -4433617, (DyeColor)new BiomeDictionary.Type[] { BiomeDictionary.Type.MOUNTAIN }),
/* 311 */     GREEN((String)DyeColor.GREEN, -16720799, (DyeColor)new BiomeDictionary.Type[] { BiomeDictionary.Type.JUNGLE }),
/* 312 */     RED((String)DyeColor.RED, -53193, (DyeColor)new BiomeDictionary.Type[] { BiomeDictionary.Type.NETHER }),
/* 313 */     BLACK((String)DyeColor.BLACK, -15987700, (DyeColor)new BiomeDictionary.Type[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     SpringColor(int color, BiomeDictionary.Type... type) {
/* 320 */       this.color = color;
/* 321 */       this.type = type;
/*     */     }
/*     */ 
/*     */ 
/*     */     SpringColor(DyeColor vanilla, int color, BiomeDictionary.Type... type) {
/* 326 */       this.dye = vanilla;
/*     */     }
/*     */ 
/*     */ 
/*     */     public String func_176610_l() {
/* 331 */       return toString().toLowerCase();
/*     */     }
/*     */ 
/*     */     public static SpringColor getColorToDye(DyeColor d) {
/* 335 */       for (SpringColor c : values()) {
/* 336 */         if (c.dye == d) {
/* 337 */           return c;
/*     */         }
/*     */       } 
/* 340 */       return DEFAULT;
/*     */     }
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 57 ms
	
*/