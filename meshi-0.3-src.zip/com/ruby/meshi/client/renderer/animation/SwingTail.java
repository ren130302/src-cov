/*    */ package com.ruby.meshi.client.renderer.animation;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import net.minecraft.util.Direction;
/*    */ import net.minecraft.util.math.MathHelper;
/*    */ 
/*    */ public class SwingTail
/*    */   implements EntityModelAnimation
/*    */ {
/*    */   float prevMoveAmount;
/*    */   float moveAmount;
/*    */   float prevRotateYaw;
/*    */   float rotateYaw;
/*    */   float prevRotatePitch;
/*    */   float rotatePitch;
/*    */   int timer;
/*    */   int maxTimer;
/*    */   int moveTime;
/*    */   final Direction direction;
/*    */   static final float ANGLE_LIMIT = 35.0F;
/*    */   float rotateAngleX;
/*    */   float rotateAngleY;
/*    */   float moveLength;
/*    */   
/*    */   public SwingTail(Direction direction) {
/* 26 */     this.direction = direction;
/* 27 */     this.maxTimer = 600 + rand.nextInt(600);
/* 28 */     this.moveAmount = this.moveLength = 0.15F;
/*    */     
/* 30 */     this.rotateAngleX = 70.0F * rand.nextFloat() - 35.0F;
/* 31 */     this.rotateAngleX += 10.0F * Math.signum(this.rotateAngleX);
/* 32 */     this.rotatePitch = this.rotateAngleX = MathHelper.func_76131_a(this.rotateAngleX, -35.0F, 35.0F);
/* 33 */     this.rotateYaw = this.rotateAngleY = 17.5F * rand.nextFloat() - 8.75F;
/*    */   }
/*    */ 
/*    */ 
/*    */   public boolean shouldRenderPart(EntityModelAnimation.RenderPart part) {
/* 38 */     return (part == EntityModelAnimation.RenderPart.TAIL);
/*    */   }
/*    */ 
/*    */ 
/*    */   public void animationTick() {
/* 43 */     this.prevMoveAmount = this.moveAmount;
/* 44 */     this.prevRotateYaw = this.rotateYaw;
/* 45 */     this.prevRotatePitch = this.rotatePitch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 52 */     taildMove();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   private void taildMove() {
/* 58 */     if (Math.abs(this.rotateAngleX - this.rotatePitch) > 0.1F) {
/* 59 */       this.rotatePitch = lerp(0.1F, this.rotatePitch, this.rotateAngleX);
/* 60 */       this.rotateYaw = lerp(0.1F, this.rotateYaw, this.rotateAngleY);
/*    */     } else {
/* 62 */       this.rotateAngleX = -this.rotateAngleX;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getMaxTimer() {
/* 69 */     return this.maxTimer;
/*    */   }
/*    */ 
/*    */ 
/*    */   public boolean isFinished() {
/* 74 */     return (this.timer > this.maxTimer);
/*    */   }
/*    */ 
/*    */ 
/*    */   public void translatef(TriConsumer<Float, Float, Float> position, float partialTicks) {
/* 79 */     position.accept(Float.valueOf(getDiractionOffsetVal(lerp(partialTicks, this.prevMoveAmount, this.moveAmount), this.direction, Direction.Axis.X)), 
/* 80 */         Float.valueOf(0.0F), 
/* 81 */         Float.valueOf(getDiractionOffsetVal(lerp(partialTicks, this.prevMoveAmount, this.moveAmount), this.direction, Direction.Axis.Z)));
/*    */   }
/*    */ 
/*    */ 
/*    */   public void rotateY(Consumer<Float> angle, float partialTicks) {
/* 86 */     angle.accept(Float.valueOf(lerp(partialTicks, this.prevRotatePitch, this.rotatePitch)));
/*    */   }
/*    */ 
/*    */ 
/*    */   public void rotateX(Consumer<Float> angle, float partialTicks) {
/* 91 */     angle.accept(Float.valueOf(-getDiractionVal(lerp(partialTicks, this.prevRotateYaw, this.rotateYaw), this.direction, Direction.Axis.Z)));
/*    */   }
/*    */ 
/*    */ 
/*    */   public void rotateZ(Consumer<Float> angle, float partialTicks) {
/* 96 */     angle.accept(Float.valueOf(getDiractionOffsetVal(lerp(partialTicks, this.prevRotateYaw, this.rotateYaw), this.direction, Direction.Axis.X)));
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 4 ms
	
*/