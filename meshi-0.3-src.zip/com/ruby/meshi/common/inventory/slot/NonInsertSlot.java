/*    */ package com.ruby.meshi.common.inventory.slot;
/*    */ 
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.inventory.container.Slot;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class NonInsertSlot
/*    */   extends Slot {
/*    */   public NonInsertSlot(IInventory inventoryIn, int index, int xPosition, int yPosition) {
/* 10 */     super(inventoryIn, index, xPosition, yPosition);
/*    */   }
/*    */ 
/*    */ 
/*    */   public boolean func_75214_a(ItemStack stack) {
/* 15 */     return false;
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 0 ms
	
*/