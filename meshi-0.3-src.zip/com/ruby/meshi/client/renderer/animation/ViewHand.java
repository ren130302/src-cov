/*    */ package com.ruby.meshi.client.renderer.animation;
/*    */ 
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraft.util.Direction;
/*    */ 
/*    */ public class ViewHand
/*    */   implements EntityModelAnimation
/*    */ {
/*    */   float prevMoveAmount;
/*    */   float moveAmount;
/*    */   float prevRotateYaw;
/*    */   float rotateYaw;
/*    */   float prevRotatePitch;
/*    */   float rotatePitch;
/* 15 */   int timer = 0;
/*    */ 
/*    */ 
/*    */   @Nullable
/* 19 */   EntityModelAnimation.RenderPart part = null; final Direction direction;  EntityModelAnimation.RenderPart part = null; final Direction direction;
/*    */ 
/*    */ 
/*    */   public ViewHand(Direction direction) {
/* 23 */     this.direction = direction;
/* 24 */     this.maxTimer = 100 + rand.nextInt(100);
/* 25 */     this.moveAmount = 0.3F;
/*    */   }
/*    */ 
/*    */   public ViewHand(Direction direction, EntityModelAnimation.RenderPart part) {
/* 29 */     this(direction);
/* 30 */     this.part = part;
/*    */   }
/*    */ 
/*    */ 
/*    */   public boolean shouldRenderPart(EntityModelAnimation.RenderPart part) {
/* 35 */     if (this.part != null) {
/* 36 */       return (this.part == part);
/*    */     }
/* 38 */     return (part == EntityModelAnimation.RenderPart.LEFT_HAND || part == EntityModelAnimation.RenderPart.RIGHT_HAND);
/*    */   }
/*    */ 
/*    */ 
/*    */   public void animationTick() {
/* 43 */     this.prevMoveAmount = this.moveAmount;
/* 44 */     this.prevRotateYaw = this.rotateYaw;
/* 45 */     this.prevRotatePitch = this.rotatePitch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 53 */     handMove();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ViewHand setParent(EntityModelAnimation parent) {
/* 62 */     this.parent = parent;
/* 63 */     this.maxTimer = parent.getMaxTimer();
/* 64 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */   public void translatef(TriConsumer<Float, Float, Float> position, float partialTicks) {
/* 69 */     position.accept(Float.valueOf(getDiractionOffsetVal(lerp(partialTicks, this.prevMoveAmount, this.moveAmount), this.direction, Direction.Axis.X)), 
/* 70 */         Float.valueOf(0.0F), 
/* 71 */         Float.valueOf(getDiractionOffsetVal(lerp(partialTicks, this.prevMoveAmount, this.moveAmount), this.direction, Direction.Axis.Z)));
/*    */   }
/*    */ 
/*    */ 
/*    */   public boolean isFinished() {
/* 76 */     return (this.timer > this.maxTimer);
/*    */   }
/*    */ 
/*    */ 
/*    */   public int getMaxTimer() {
/* 81 */     return this.maxTimer;
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 3 ms
	
*/