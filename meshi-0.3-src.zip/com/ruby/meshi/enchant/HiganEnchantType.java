package com.ruby.meshi.enchant;

import com.ruby.meshi.item.NinjaBracelet;
import java.util.function.Predicate;
import net.minecraft.enchantment.EnchantmentType;

public class HiganEnchantType {
   public static final EnchantmentType BRACELET = EnchantmentType.create("bracelet", (item) -> {
      return item instanceof NinjaBracelet;
   });
}