/*     */ package com.ruby.meshi.block.tileentity;
/*     */ import com.ruby.meshi.block.Millstone;
/*     */ import com.ruby.meshi.common.inventory.MillstoneContainer;
/*     */ import com.ruby.meshi.crafting.GrindRecipe;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.BlockState;
/*     */ import net.minecraft.entity.player.PlayerEntity;
/*     */ import net.minecraft.entity.player.PlayerInventory;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.IRecipeHelperPopulator;
/*     */ import net.minecraft.inventory.ISidedInventory;
/*     */ import net.minecraft.inventory.ItemStackHelper;
/*     */ import net.minecraft.inventory.container.Container;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.crafting.RecipeItemHelper;
/*     */ import net.minecraft.nbt.CompoundNBT;
/*     */ import net.minecraft.network.NetworkManager;
/*     */ import net.minecraft.network.play.server.SUpdateTileEntityPacket;
/*     */ import net.minecraft.particles.IParticleData;
/*     */ import net.minecraft.particles.ItemParticleData;
/*     */ import net.minecraft.particles.ParticleTypes;
/*     */ import net.minecraft.state.IProperty;
/*     */ import net.minecraft.tileentity.ITickableTileEntity;
/*     */ import net.minecraft.tileentity.LockableTileEntity;
/*     */ import net.minecraft.util.Direction;
/*     */ import net.minecraft.util.IntArray;
/*     */ import net.minecraft.util.NonNullList;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TranslationTextComponent;
/*     */ import net.minecraftforge.common.capabilities.Capability;
/*     */ import net.minecraftforge.common.util.LazyOptional;
/*     */ import net.minecraftforge.items.CapabilityItemHandler;
/*     */ import net.minecraftforge.items.IItemHandler;
/*     */ import net.minecraftforge.items.wrapper.SidedInvWrapper;
/*     */ 
/*     */ public class MillstoneTileEntity extends LockableTileEntity implements ITickableTileEntity, ISidedInventory, IRecipeHelperPopulator {
/*  38 */   private static final int[] slots_top = new int[] { 0 };
/*  39 */   private static final int[] slots_bottom = new int[] { 2, 1 };
/*  40 */   private static final int[] slots_sides = new int[] { 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       return true;  return false; } private boolean hasInsert(int slot, ItemStack stack) { if (isSlotEmpty(slot))
/*     */       return true;  if (stack == null || stack.func_190926_b() || !func_70301_a(slot).func_77969_a(stack))
/*  52 */       return false;  int outResult = func_70301_a(slot).func_190916_E() + stack.func_190916_E(); return (outResult <= func_70297_j_() && outResult <= stack.func_77976_d()); } private void grindItem() { if (!isSlotEmpty(0)) { GrindRecipe gr = getRecipe(); if (gr != null) { ItemStack output = gr.getResult(); ItemStack bonus = ((func_145831_w()).field_73012_v.nextFloat() <= gr.getBonusWeight()) ? gr.getBonus() : ItemStack.field_190927_a; insertInventorySlotContents(1, output); insertInventorySlotContents(2, bonus); func_70298_a(0, gr.getRequestCount()); }  }  } public GrindRecipe getRecipe() { return func_145831_w().func_199532_z().func_215371_a(GrindRecipe.TYPE, (IInventory)this, func_145831_w()).orElse(null); } public int getGrindTime() { return ((Integer)func_145831_w().func_199532_z().func_215371_a(GrindRecipe.TYPE, (IInventory)this, func_145831_w()).map(GrindRecipe::getGrindingTime).orElse(Integer.valueOf(200))).intValue(); } private boolean isSlotEmpty(int slot) { return ((ItemStack)this.contents.get(slot)).func_190926_b(); } public double getRoll() { return this.roll; } public void func_145839_a(CompoundNBT compound) { super.func_145839_a(compound); this.roll = compound.func_74762_e("roll"); this.contents = NonNullList.func_191197_a(func_70302_i_(), ItemStack.field_190927_a); readData(compound); } public MillstoneTileEntity() { super(HiganTileEntityType.MILLSTONE);      return false;  int outResult = func_70301_a(slot).func_190916_E() + stack.func_190916_E(); return (outResult <= func_70297_j_() && outResult <= stack.func_77976_d()); } private void grindItem() { if (!isSlotEmpty(0)) { GrindRecipe gr = getRecipe(); if (gr != null) { ItemStack output = gr.getResult(); ItemStack bonus = ((func_145831_w()).field_73012_v.nextFloat() <= gr.getBonusWeight()) ? gr.getBonus() : ItemStack.field_190927_a; insertInventorySlotContents(1, output); insertInventorySlotContents(2, bonus); func_70298_a(0, gr.getRequestCount()); }  }  } public GrindRecipe getRecipe() { return func_145831_w().func_199532_z().func_215371_a(GrindRecipe.TYPE, (IInventory)this, func_145831_w()).orElse(null); } public int getGrindTime() { return ((Integer)func_145831_w().func_199532_z().func_215371_a(GrindRecipe.TYPE, (IInventory)this, func_145831_w()).map(GrindRecipe::getGrindingTime).orElse(Integer.valueOf(200))).intValue(); } private boolean isSlotEmpty(int slot) { return ((ItemStack)this.contents.get(slot)).func_190926_b(); } public double getRoll() { return this.roll; } public void func_145839_a(CompoundNBT compound) { super.func_145839_a(compound); this.roll = compound.func_74762_e("roll"); this.contents = NonNullList.func_191197_a(func_70302_i_(), ItemStack.field_190927_a); readData(compound); } public MillstoneTileEntity() { super(HiganTileEntityType.MILLSTONE);      return false;  int outResult = func_70301_a(slot).func_190916_E() + stack.func_190916_E(); return (outResult <= func_70297_j_() && outResult <= stack.func_77976_d()); } private void grindItem() { if (!isSlotEmpty(0)) { GrindRecipe gr = getRecipe(); if (gr != null) { ItemStack output = gr.getResult(); ItemStack bonus = ((func_145831_w()).field_73012_v.nextFloat() <= gr.getBonusWeight()) ? gr.getBonus() : ItemStack.field_190927_a; insertInventorySlotContents(1, output); insertInventorySlotContents(2, bonus); func_70298_a(0, gr.getRequestCount()); }  }  } public GrindRecipe getRecipe() { return func_145831_w().func_199532_z().func_215371_a(GrindRecipe.TYPE, (IInventory)this, func_145831_w()).orElse(null); } public int getGrindTime() { return ((Integer)func_145831_w().func_199532_z().func_215371_a(GrindRecipe.TYPE, (IInventory)this, func_145831_w()).map(GrindRecipe::getGrindingTime).orElse(Integer.valueOf(200))).intValue(); } private boolean isSlotEmpty(int slot) { return ((ItemStack)this.contents.get(slot)).func_190926_b(); } public double getRoll() { return this.roll; } public void func_145839_a(CompoundNBT compound) { super.func_145839_a(compound); this.roll = compound.func_74762_e("roll"); this.contents = NonNullList.func_191197_a(func_70302_i_(), ItemStack.field_190927_a); readData(compound); } public MillstoneTileEntity() { super(HiganTileEntityType.MILLSTONE);      return false;  int outResult = func_70301_a(slot).func_190916_E() + stack.func_190916_E(); return (outResult <= func_70297_j_() && outResult <= stack.func_77976_d()); } private void grindItem() { if (!isSlotEmpty(0)) { GrindRecipe gr = getRecipe(); if (gr != null) { ItemStack output = gr.getResult(); ItemStack bonus = ((func_145831_w()).field_73012_v.nextFloat() <= gr.getBonusWeight()) ? gr.getBonus() : ItemStack.field_190927_a; insertInventorySlotContents(1, output); insertInventorySlotContents(2, bonus); func_70298_a(0, gr.getRequestCount()); }  }  } public GrindRecipe getRecipe() { return func_145831_w().func_199532_z().func_215371_a(GrindRecipe.TYPE, (IInventory)this, func_145831_w()).orElse(null); } public int getGrindTime() { return ((Integer)func_145831_w().func_199532_z().func_215371_a(GrindRecipe.TYPE, (IInventory)this, func_145831_w()).map(GrindRecipe::getGrindingTime).orElse(Integer.valueOf(200))).intValue(); } private boolean isSlotEmpty(int slot) { return ((ItemStack)this.contents.get(slot)).func_190926_b(); } public double getRoll() { return this.roll; } public void func_145839_a(CompoundNBT compound) { super.func_145839_a(compound); this.roll = compound.func_74762_e("roll"); this.contents = NonNullList.func_191197_a(func_70302_i_(), ItemStack.field_190927_a); readData(compound); } public MillstoneTileEntity() { super(HiganTileEntityType.MILLSTONE);      return false;  int outResult = func_70301_a(slot).func_190916_E() + stack.func_190916_E(); return (outResult <= func_70297_j_() && outResult <= stack.func_77976_d()); } private void grindItem() { if (!isSlotEmpty(0)) { GrindRecipe gr = getRecipe(); if (gr != null) { ItemStack output = gr.getResult(); ItemStack bonus = ((func_145831_w()).field_73012_v.nextFloat() <= gr.getBonusWeight()) ? gr.getBonus() : ItemStack.field_190927_a; insertInventorySlotContents(1, output); insertInventorySlotContents(2, bonus); func_70298_a(0, gr.getRequestCount()); }  }  } public GrindRecipe getRecipe() { return func_145831_w().func_199532_z().func_215371_a(GrindRecipe.TYPE, (IInventory)this, func_145831_w()).orElse(null); } public int getGrindTime() { return ((Integer)func_145831_w().func_199532_z().func_215371_a(GrindRecipe.TYPE, (IInventory)this, func_145831_w()).map(GrindRecipe::getGrindingTime).orElse(Integer.valueOf(200))).intValue(); } private boolean isSlotEmpty(int slot) { return ((ItemStack)this.contents.get(slot)).func_190926_b(); } public double getRoll() { return this.roll; } public void func_145839_a(CompoundNBT compound) { super.func_145839_a(compound); this.roll = compound.func_74762_e("roll"); this.contents = NonNullList.func_191197_a(func_70302_i_(), ItemStack.field_190927_a); readData(compound); } public MillstoneTileEntity() { super(HiganTileEntityType.MILLSTONE);      return false;  int outResult = func_70301_a(slot).func_190916_E() + stack.func_190916_E(); return (outResult <= func_70297_j_() && outResult <= stack.func_77976_d()); } private void grindItem() { if (!isSlotEmpty(0)) { GrindRecipe gr = getRecipe(); if (gr != null) { ItemStack output = gr.getResult(); ItemStack bonus = ((func_145831_w()).field_73012_v.nextFloat() <= gr.getBonusWeight()) ? gr.getBonus() : ItemStack.field_190927_a; insertInventorySlotContents(1, output); insertInventorySlotContents(2, bonus); func_70298_a(0, gr.getRequestCount()); }  }  } public GrindRecipe getRecipe() { return func_145831_w().func_199532_z().func_215371_a(GrindRecipe.TYPE, (IInventory)this, func_145831_w()).orElse(null); } public int getGrindTime() { return ((Integer)func_145831_w().func_199532_z().func_215371_a(GrindRecipe.TYPE, (IInventory)this, func_145831_w()).map(GrindRecipe::getGrindingTime).orElse(Integer.valueOf(200))).intValue(); } private boolean isSlotEmpty(int slot) { return ((ItemStack)this.contents.get(slot)).func_190926_b(); } public double getRoll() { return this.roll; } public void func_145839_a(CompoundNBT compound) { super.func_145839_a(compound); this.roll = compound.func_74762_e("roll"); this.contents = NonNullList.func_191197_a(func_70302_i_(), ItemStack.field_190927_a); readData(compound); } public MillstoneTileEntity() { super(HiganTileEntityType.MILLSTONE);      return false;  int outResult = func_70301_a(slot).func_190916_E() + stack.func_190916_E(); return (outResult <= func_70297_j_() && outResult <= stack.func_77976_d()); } private void grindItem() { if (!isSlotEmpty(0)) { GrindRecipe gr = getRecipe(); if (gr != null) { ItemStack output = gr.getResult(); ItemStack bonus = ((func_145831_w()).field_73012_v.nextFloat() <= gr.getBonusWeight()) ? gr.getBonus() : ItemStack.field_190927_a; insertInventorySlotContents(1, output); insertInventorySlotContents(2, bonus); func_70298_a(0, gr.getRequestCount()); }  }  } public GrindRecipe getRecipe() { return func_145831_w().func_199532_z().func_215371_a(GrindRecipe.TYPE, (IInventory)this, func_145831_w()).orElse(null); } public int getGrindTime() { return ((Integer)func_145831_w().func_199532_z().func_215371_a(GrindRecipe.TYPE, (IInventory)this, func_145831_w()).map(GrindRecipe::getGrindingTime).orElse(Integer.valueOf(200))).intValue(); } private boolean isSlotEmpty(int slot) { return ((ItemStack)this.contents.get(slot)).func_190926_b(); } public double getRoll() { return this.roll; } public void func_145839_a(CompoundNBT compound) { super.func_145839_a(compound); this.roll = compound.func_74762_e("roll"); this.contents = NonNullList.func_191197_a(func_70302_i_(), ItemStack.field_190927_a); readData(compound); } public MillstoneTileEntity() { super(HiganTileEntityType.MILLSTONE);      return false;  int outResult = func_70301_a(slot).func_190916_E() + stack.func_190916_E(); return (outResult <= func_70297_j_() && outResult <= stack.func_77976_d()); } private void grindItem() { if (!isSlotEmpty(0)) { GrindRecipe gr = getRecipe(); if (gr != null) { ItemStack output = gr.getResult(); ItemStack bonus = ((func_145831_w()).field_73012_v.nextFloat() <= gr.getBonusWeight()) ? gr.getBonus() : ItemStack.field_190927_a; insertInventorySlotContents(1, output); insertInventorySlotContents(2, bonus); func_70298_a(0, gr.getRequestCount()); }  }  } public GrindRecipe getRecipe() { return func_145831_w().func_199532_z().func_215371_a(GrindRecipe.TYPE, (IInventory)this, func_145831_w()).orElse(null); } public int getGrindTime() { return ((Integer)func_145831_w().func_199532_z().func_215371_a(GrindRecipe.TYPE, (IInventory)this, func_145831_w()).map(GrindRecipe::getGrindingTime).orElse(Integer.valueOf(200))).intValue(); } private boolean isSlotEmpty(int slot) { return ((ItemStack)this.contents.get(slot)).func_190926_b(); } public double getRoll() { return this.roll; } public void func_145839_a(CompoundNBT compound) { super.func_145839_a(compound); this.roll = compound.func_74762_e("roll"); this.contents = NonNullList.func_191197_a(func_70302_i_(), ItemStack.field_190927_a); readData(compound); } public MillstoneTileEntity() { super(HiganTileEntityType.MILLSTONE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 369 */     this.handlerTop = LazyOptional.of(() -> new SidedInvWrapper(this, Direction.UP));
/* 370 */     this.handlerBottom = LazyOptional.of(() -> new SidedInvWrapper(this, Direction.DOWN));
/* 371 */     this.handlerSide = LazyOptional.of(() -> new SidedInvWrapper(this, Direction.WEST)); this.contents = NonNullList.func_191197_a(func_70302_i_(), ItemStack.field_190927_a); this.progress = -1; }
/*     */ 
/*     */ 
/*     */ 
/* 375 */   private void itemCrackParticle(ItemStack nowgi) { if (!nowgi.func_190926_b()) { float pitch = 0.0F; float yaw = (func_145831_w()).field_73012_v.nextFloat() * 20.0F - 1.0F; for (int j = 0; j < 1; j++) { Vec3d vec3d = new Vec3d(((func_145831_w()).field_73012_v.nextFloat() - 0.5D) * 0.1D, Math.random() * 0.1D + 0.1D, 0.0D); vec3d = vec3d.func_178789_a(-pitch * 3.1415927F / 180.0F); vec3d = vec3d.func_178785_b(-yaw * 3.1415927F); double d0 = -(func_145831_w()).field_73012_v.nextFloat() * 0.6D - 0.3D; Vec3d vec3d1 = new Vec3d(((func_145831_w()).field_73012_v.nextFloat() - 0.5D) * 0.3D, d0, 0.6D); vec3d1 = vec3d1.func_178789_a(-pitch * 3.1415927F / 180.0F); vec3d1 = vec3d1.func_178785_b(-yaw * 3.1415927F); vec3d1 = vec3d1.func_72441_c((func_174877_v().func_177958_n() + 0.5F), (func_174877_v().func_177956_o() + 1.0F), (func_174877_v().func_177952_p() + 0.5F)); func_145831_w().func_195594_a((IParticleData)new ItemParticleData(ParticleTypes.field_197591_B, nowgi), vec3d1.func_82615_a(), vec3d1.func_82617_b(), vec3d1.func_82616_c(), vec3d.func_82615_a(), vec3d.func_82617_b() - 0.15D, vec3d.func_82616_c()); }  }  } public int getProgress() { return this.progress; } public int func_70302_i_() { return 3; } public boolean func_191420_l() { for (ItemStack itemstack : this.contents) { if (!itemstack.func_190926_b()) return false;  }  return true; } public ItemStack func_70301_a(int index) { return (ItemStack)this.contents.get(index); } public <T> LazyOptional<T> getCapability(Capability<T> capability, Direction facing) { if (capability == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY) {  private void itemCrackParticle(ItemStack nowgi) { if (!nowgi.func_190926_b()) { float pitch = 0.0F; float yaw = (func_145831_w()).field_73012_v.nextFloat() * 20.0F - 1.0F; for (int j = 0; j < 1; j++) { Vec3d vec3d = new Vec3d(((func_145831_w()).field_73012_v.nextFloat() - 0.5D) * 0.1D, Math.random() * 0.1D + 0.1D, 0.0D); vec3d = vec3d.func_178789_a(-pitch * 3.1415927F / 180.0F); vec3d = vec3d.func_178785_b(-yaw * 3.1415927F); double d0 = -(func_145831_w()).field_73012_v.nextFloat() * 0.6D - 0.3D; Vec3d vec3d1 = new Vec3d(((func_145831_w()).field_73012_v.nextFloat() - 0.5D) * 0.3D, d0, 0.6D); vec3d1 = vec3d1.func_178789_a(-pitch * 3.1415927F / 180.0F); vec3d1 = vec3d1.func_178785_b(-yaw * 3.1415927F); vec3d1 = vec3d1.func_72441_c((func_174877_v().func_177958_n() + 0.5F), (func_174877_v().func_177956_o() + 1.0F), (func_174877_v().func_177952_p() + 0.5F)); func_145831_w().func_195594_a((IParticleData)new ItemParticleData(ParticleTypes.field_197591_B, nowgi), vec3d1.func_82615_a(), vec3d1.func_82617_b(), vec3d1.func_82616_c(), vec3d.func_82615_a(), vec3d.func_82617_b() - 0.15D, vec3d.func_82616_c()); }  }  } public int getProgress() { return this.progress; } public int func_70302_i_() { return 3; } public boolean func_191420_l() { for (ItemStack itemstack : this.contents) { if (!itemstack.func_190926_b()) return false;  }  return true; } public ItemStack func_70301_a(int index) { return (ItemStack)this.contents.get(index); } public <T> LazyOptional<T> getCapability(Capability<T> capability, Direction facing) { if (capability == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY) {  private void itemCrackParticle(ItemStack nowgi) { if (!nowgi.func_190926_b()) { float pitch = 0.0F; float yaw = (func_145831_w()).field_73012_v.nextFloat() * 20.0F - 1.0F; for (int j = 0; j < 1; j++) { Vec3d vec3d = new Vec3d(((func_145831_w()).field_73012_v.nextFloat() - 0.5D) * 0.1D, Math.random() * 0.1D + 0.1D, 0.0D); vec3d = vec3d.func_178789_a(-pitch * 3.1415927F / 180.0F); vec3d = vec3d.func_178785_b(-yaw * 3.1415927F); double d0 = -(func_145831_w()).field_73012_v.nextFloat() * 0.6D - 0.3D; Vec3d vec3d1 = new Vec3d(((func_145831_w()).field_73012_v.nextFloat() - 0.5D) * 0.3D, d0, 0.6D); vec3d1 = vec3d1.func_178789_a(-pitch * 3.1415927F / 180.0F); vec3d1 = vec3d1.func_178785_b(-yaw * 3.1415927F); vec3d1 = vec3d1.func_72441_c((func_174877_v().func_177958_n() + 0.5F), (func_174877_v().func_177956_o() + 1.0F), (func_174877_v().func_177952_p() + 0.5F)); func_145831_w().func_195594_a((IParticleData)new ItemParticleData(ParticleTypes.field_197591_B, nowgi), vec3d1.func_82615_a(), vec3d1.func_82617_b(), vec3d1.func_82616_c(), vec3d.func_82615_a(), vec3d.func_82617_b() - 0.15D, vec3d.func_82616_c()); }  }  } public int getProgress() { return this.progress; } public int func_70302_i_() { return 3; } public boolean func_191420_l() { for (ItemStack itemstack : this.contents) { if (!itemstack.func_190926_b()) return false;  }  return true; } public ItemStack func_70301_a(int index) { return (ItemStack)this.contents.get(index); } public <T> LazyOptional<T> getCapability(Capability<T> capability, Direction facing) { if (capability == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY) {  private void itemCrackParticle(ItemStack nowgi) { if (!nowgi.func_190926_b()) { float pitch = 0.0F; float yaw = (func_145831_w()).field_73012_v.nextFloat() * 20.0F - 1.0F; for (int j = 0; j < 1; j++) { Vec3d vec3d = new Vec3d(((func_145831_w()).field_73012_v.nextFloat() - 0.5D) * 0.1D, Math.random() * 0.1D + 0.1D, 0.0D); vec3d = vec3d.func_178789_a(-pitch * 3.1415927F / 180.0F); vec3d = vec3d.func_178785_b(-yaw * 3.1415927F); double d0 = -(func_145831_w()).field_73012_v.nextFloat() * 0.6D - 0.3D; Vec3d vec3d1 = new Vec3d(((func_145831_w()).field_73012_v.nextFloat() - 0.5D) * 0.3D, d0, 0.6D); vec3d1 = vec3d1.func_178789_a(-pitch * 3.1415927F / 180.0F); vec3d1 = vec3d1.func_178785_b(-yaw * 3.1415927F); vec3d1 = vec3d1.func_72441_c((func_174877_v().func_177958_n() + 0.5F), (func_174877_v().func_177956_o() + 1.0F), (func_174877_v().func_177952_p() + 0.5F)); func_145831_w().func_195594_a((IParticleData)new ItemParticleData(ParticleTypes.field_197591_B, nowgi), vec3d1.func_82615_a(), vec3d1.func_82617_b(), vec3d1.func_82616_c(), vec3d.func_82615_a(), vec3d.func_82617_b() - 0.15D, vec3d.func_82616_c()); }  }  } public int getProgress() { return this.progress; } public int func_70302_i_() { return 3; } public boolean func_191420_l() { for (ItemStack itemstack : this.contents) { if (!itemstack.func_190926_b()) return false;  }  return true; } public ItemStack func_70301_a(int index) { return (ItemStack)this.contents.get(index); } public <T> LazyOptional<T> getCapability(Capability<T> capability, Direction facing) { if (capability == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY) {  private void itemCrackParticle(ItemStack nowgi) { if (!nowgi.func_190926_b()) { float pitch = 0.0F; float yaw = (func_145831_w()).field_73012_v.nextFloat() * 20.0F - 1.0F; for (int j = 0; j < 1; j++) { Vec3d vec3d = new Vec3d(((func_145831_w()).field_73012_v.nextFloat() - 0.5D) * 0.1D, Math.random() * 0.1D + 0.1D, 0.0D); vec3d = vec3d.func_178789_a(-pitch * 3.1415927F / 180.0F); vec3d = vec3d.func_178785_b(-yaw * 3.1415927F); double d0 = -(func_145831_w()).field_73012_v.nextFloat() * 0.6D - 0.3D; Vec3d vec3d1 = new Vec3d(((func_145831_w()).field_73012_v.nextFloat() - 0.5D) * 0.3D, d0, 0.6D); vec3d1 = vec3d1.func_178789_a(-pitch * 3.1415927F / 180.0F); vec3d1 = vec3d1.func_178785_b(-yaw * 3.1415927F); vec3d1 = vec3d1.func_72441_c((func_174877_v().func_177958_n() + 0.5F), (func_174877_v().func_177956_o() + 1.0F), (func_174877_v().func_177952_p() + 0.5F)); func_145831_w().func_195594_a((IParticleData)new ItemParticleData(ParticleTypes.field_197591_B, nowgi), vec3d1.func_82615_a(), vec3d1.func_82617_b(), vec3d1.func_82616_c(), vec3d.func_82615_a(), vec3d.func_82617_b() - 0.15D, vec3d.func_82616_c()); }  }  } public int getProgress() { return this.progress; } public int func_70302_i_() { return 3; } public boolean func_191420_l() { for (ItemStack itemstack : this.contents) { if (!itemstack.func_190926_b()) return false;  }  return true; } public ItemStack func_70301_a(int index) { return (ItemStack)this.contents.get(index); } public <T> LazyOptional<T> getCapability(Capability<T> capability, Direction facing) { if (capability == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY) {  private void itemCrackParticle(ItemStack nowgi) { if (!nowgi.func_190926_b()) { float pitch = 0.0F; float yaw = (func_145831_w()).field_73012_v.nextFloat() * 20.0F - 1.0F; for (int j = 0; j < 1; j++) { Vec3d vec3d = new Vec3d(((func_145831_w()).field_73012_v.nextFloat() - 0.5D) * 0.1D, Math.random() * 0.1D + 0.1D, 0.0D); vec3d = vec3d.func_178789_a(-pitch * 3.1415927F / 180.0F); vec3d = vec3d.func_178785_b(-yaw * 3.1415927F); double d0 = -(func_145831_w()).field_73012_v.nextFloat() * 0.6D - 0.3D; Vec3d vec3d1 = new Vec3d(((func_145831_w()).field_73012_v.nextFloat() - 0.5D) * 0.3D, d0, 0.6D); vec3d1 = vec3d1.func_178789_a(-pitch * 3.1415927F / 180.0F); vec3d1 = vec3d1.func_178785_b(-yaw * 3.1415927F); vec3d1 = vec3d1.func_72441_c((func_174877_v().func_177958_n() + 0.5F), (func_174877_v().func_177956_o() + 1.0F), (func_174877_v().func_177952_p() + 0.5F)); func_145831_w().func_195594_a((IParticleData)new ItemParticleData(ParticleTypes.field_197591_B, nowgi), vec3d1.func_82615_a(), vec3d1.func_82617_b(), vec3d1.func_82616_c(), vec3d.func_82615_a(), vec3d.func_82617_b() - 0.15D, vec3d.func_82616_c()); }  }  } public int getProgress() { return this.progress; } public int func_70302_i_() { return 3; } public boolean func_191420_l() { for (ItemStack itemstack : this.contents) { if (!itemstack.func_190926_b()) return false;  }  return true; } public ItemStack func_70301_a(int index) { return (ItemStack)this.contents.get(index); } public <T> LazyOptional<T> getCapability(Capability<T> capability, Direction facing) { if (capability == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY) {
/* 376 */       if (facing == Direction.DOWN)
/* 377 */         return this.handlerBottom.cast(); 
/* 378 */       if (facing == Direction.UP) {
/* 379 */         return this.handlerTop.cast();
/*     */       }
/* 381 */       return this.handlerSide.cast();
/*     */     } 
/*     */     
/* 384 */     return super.getCapability(capability, facing); } public ItemStack func_70298_a(int index, int count) { ItemStack itemstack = ItemStackHelper.func_188382_a((List)this.contents, index, count); if (!itemstack.func_190926_b()) func_70296_d();  if (index == 0 && !canGrind()) reset();  return itemstack; } public ItemStack func_70304_b(int index) { return ItemStackHelper.func_188383_a((List)this.contents, index); } public void func_70299_a(int index, ItemStack stack) { if (index == 0 && !func_70301_a(index).func_77969_a(stack)) reset();  this.contents.set(index, stack); if (stack.func_190916_E() > func_70297_j_()) stack.func_190920_e(func_70297_j_());  func_70296_d(); } private void reset() { this.progress = -1; func_145831_w().func_175656_a(this.field_174879_c, (BlockState)func_195044_w().func_206870_a((IProperty)Millstone.ENABLE, Boolean.valueOf(false))); } public void insertInventorySlotContents(int index, ItemStack insertStack) { if (insertStack == null || insertStack.func_190926_b()) return;  if (isSlotEmpty(index)) { func_70299_a(index, insertStack); } else if (func_70301_a(index).func_77969_a(insertStack)) { ItemStack stack = (ItemStack)this.contents.get(index); stack.func_190920_e(stack.func_190916_E() + insertStack.func_190916_E()); if (stack.func_190916_E() > func_70297_j_()) stack.func_190920_e(func_70297_j_());  func_70296_d(); }  } public boolean func_70300_a(PlayerEntity player) { if (this.field_145850_b.func_175625_s(this.field_174879_c) != this) return false;  return (player.func_70092_e(this.field_174879_c.func_177958_n() + 0.5D, this.field_174879_c.func_177956_o() + 0.5D, this.field_174879_c.func_177952_p() + 0.5D) <= 64.0D); } public void func_174888_l() { this.contents.clear(); } public ITextComponent func_213907_g() { return (ITextComponent)new TranslationTextComponent(String.join(".", new CharSequence[] { "container", "meshi", func_195044_w().func_177230_c().getRegistryName().func_110623_a() }), new Object[0]); } protected Container func_213906_a(int id, PlayerInventory player) { IntArray intArray = new IntArray(2); intArray.func_221477_a(0, this.progress); intArray.func_221477_a(1, getGrindTime()); return (Container)new MillstoneContainer(id, player, this, intArray); } public void handleUpdateTag(CompoundNBT tag) { super.handleUpdateTag(tag); readData(tag); } public CompoundNBT func_189517_E_() { CompoundNBT tag = super.func_189517_E_(); writeData(tag); return tag; } public void onDataPacket(NetworkManager net, SUpdateTileEntityPacket pkt) { readData(pkt.func_148857_g()); } public SUpdateTileEntityPacket func_189518_D_() { CompoundNBT var1 = new CompoundNBT(); writeData(var1); return new SUpdateTileEntityPacket(func_174877_v(), 5, var1); }    return super.getCapability(capability, facing); } public ItemStack func_70298_a(int index, int count) { ItemStack itemstack = ItemStackHelper.func_188382_a((List)this.contents, index, count); if (!itemstack.func_190926_b()) func_70296_d();  if (index == 0 && !canGrind()) reset();  return itemstack; } public ItemStack func_70304_b(int index) { return ItemStackHelper.func_188383_a((List)this.contents, index); } public void func_70299_a(int index, ItemStack stack) { if (index == 0 && !func_70301_a(index).func_77969_a(stack)) reset();  this.contents.set(index, stack); if (stack.func_190916_E() > func_70297_j_()) stack.func_190920_e(func_70297_j_());  func_70296_d(); } private void reset() { this.progress = -1; func_145831_w().func_175656_a(this.field_174879_c, (BlockState)func_195044_w().func_206870_a((IProperty)Millstone.ENABLE, Boolean.valueOf(false))); } public void insertInventorySlotContents(int index, ItemStack insertStack) { if (insertStack == null || insertStack.func_190926_b()) return;  if (isSlotEmpty(index)) { func_70299_a(index, insertStack); } else if (func_70301_a(index).func_77969_a(insertStack)) { ItemStack stack = (ItemStack)this.contents.get(index); stack.func_190920_e(stack.func_190916_E() + insertStack.func_190916_E()); if (stack.func_190916_E() > func_70297_j_()) stack.func_190920_e(func_70297_j_());  func_70296_d(); }  } public boolean func_70300_a(PlayerEntity player) { if (this.field_145850_b.func_175625_s(this.field_174879_c) != this) return false;  return (player.func_70092_e(this.field_174879_c.func_177958_n() + 0.5D, this.field_174879_c.func_177956_o() + 0.5D, this.field_174879_c.func_177952_p() + 0.5D) <= 64.0D); } public void func_174888_l() { this.contents.clear(); } public ITextComponent func_213907_g() { return (ITextComponent)new TranslationTextComponent(String.join(".", new CharSequence[] { "container", "meshi", func_195044_w().func_177230_c().getRegistryName().func_110623_a() }), new Object[0]); } protected Container func_213906_a(int id, PlayerInventory player) { IntArray intArray = new IntArray(2); intArray.func_221477_a(0, this.progress); intArray.func_221477_a(1, getGrindTime()); return (Container)new MillstoneContainer(id, player, this, intArray); } public void handleUpdateTag(CompoundNBT tag) { super.handleUpdateTag(tag); readData(tag); } public CompoundNBT func_189517_E_() { CompoundNBT tag = super.func_189517_E_(); writeData(tag); return tag; } public void onDataPacket(NetworkManager net, SUpdateTileEntityPacket pkt) { readData(pkt.func_148857_g()); } public SUpdateTileEntityPacket func_189518_D_() { CompoundNBT var1 = new CompoundNBT(); writeData(var1); return new SUpdateTileEntityPacket(func_174877_v(), 5, var1); }    return super.getCapability(capability, facing); } public ItemStack func_70298_a(int index, int count) { ItemStack itemstack = ItemStackHelper.func_188382_a((List)this.contents, index, count); if (!itemstack.func_190926_b()) func_70296_d();  if (index == 0 && !canGrind()) reset();  return itemstack; } public ItemStack func_70304_b(int index) { return ItemStackHelper.func_188383_a((List)this.contents, index); } public void func_70299_a(int index, ItemStack stack) { if (index == 0 && !func_70301_a(index).func_77969_a(stack)) reset();  this.contents.set(index, stack); if (stack.func_190916_E() > func_70297_j_()) stack.func_190920_e(func_70297_j_());  func_70296_d(); } private void reset() { this.progress = -1; func_145831_w().func_175656_a(this.field_174879_c, (BlockState)func_195044_w().func_206870_a((IProperty)Millstone.ENABLE, Boolean.valueOf(false))); } public void insertInventorySlotContents(int index, ItemStack insertStack) { if (insertStack == null || insertStack.func_190926_b()) return;  if (isSlotEmpty(index)) { func_70299_a(index, insertStack); } else if (func_70301_a(index).func_77969_a(insertStack)) { ItemStack stack = (ItemStack)this.contents.get(index); stack.func_190920_e(stack.func_190916_E() + insertStack.func_190916_E()); if (stack.func_190916_E() > func_70297_j_()) stack.func_190920_e(func_70297_j_());  func_70296_d(); }  } public boolean func_70300_a(PlayerEntity player) { if (this.field_145850_b.func_175625_s(this.field_174879_c) != this) return false;  return (player.func_70092_e(this.field_174879_c.func_177958_n() + 0.5D, this.field_174879_c.func_177956_o() + 0.5D, this.field_174879_c.func_177952_p() + 0.5D) <= 64.0D); } public void func_174888_l() { this.contents.clear(); } public ITextComponent func_213907_g() { return (ITextComponent)new TranslationTextComponent(String.join(".", new CharSequence[] { "container", "meshi", func_195044_w().func_177230_c().getRegistryName().func_110623_a() }), new Object[0]); } protected Container func_213906_a(int id, PlayerInventory player) { IntArray intArray = new IntArray(2); intArray.func_221477_a(0, this.progress); intArray.func_221477_a(1, getGrindTime()); return (Container)new MillstoneContainer(id, player, this, intArray); } public void handleUpdateTag(CompoundNBT tag) { super.handleUpdateTag(tag); readData(tag); } public CompoundNBT func_189517_E_() { CompoundNBT tag = super.func_189517_E_(); writeData(tag); return tag; } public void onDataPacket(NetworkManager net, SUpdateTileEntityPacket pkt) { readData(pkt.func_148857_g()); } public SUpdateTileEntityPacket func_189518_D_() { CompoundNBT var1 = new CompoundNBT(); writeData(var1); return new SUpdateTileEntityPacket(func_174877_v(), 5, var1); }    return super.getCapability(capability, facing); } public ItemStack func_70298_a(int index, int count) { ItemStack itemstack = ItemStackHelper.func_188382_a((List)this.contents, index, count); if (!itemstack.func_190926_b()) func_70296_d();  if (index == 0 && !canGrind()) reset();  return itemstack; } public ItemStack func_70304_b(int index) { return ItemStackHelper.func_188383_a((List)this.contents, index); } public void func_70299_a(int index, ItemStack stack) { if (index == 0 && !func_70301_a(index).func_77969_a(stack)) reset();  this.contents.set(index, stack); if (stack.func_190916_E() > func_70297_j_()) stack.func_190920_e(func_70297_j_());  func_70296_d(); } private void reset() { this.progress = -1; func_145831_w().func_175656_a(this.field_174879_c, (BlockState)func_195044_w().func_206870_a((IProperty)Millstone.ENABLE, Boolean.valueOf(false))); } public void insertInventorySlotContents(int index, ItemStack insertStack) { if (insertStack == null || insertStack.func_190926_b()) return;  if (isSlotEmpty(index)) { func_70299_a(index, insertStack); } else if (func_70301_a(index).func_77969_a(insertStack)) { ItemStack stack = (ItemStack)this.contents.get(index); stack.func_190920_e(stack.func_190916_E() + insertStack.func_190916_E()); if (stack.func_190916_E() > func_70297_j_()) stack.func_190920_e(func_70297_j_());  func_70296_d(); }  } public boolean func_70300_a(PlayerEntity player) { if (this.field_145850_b.func_175625_s(this.field_174879_c) != this) return false;  return (player.func_70092_e(this.field_174879_c.func_177958_n() + 0.5D, this.field_174879_c.func_177956_o() + 0.5D, this.field_174879_c.func_177952_p() + 0.5D) <= 64.0D); } public void func_174888_l() { this.contents.clear(); } public ITextComponent func_213907_g() { return (ITextComponent)new TranslationTextComponent(String.join(".", new CharSequence[] { "container", "meshi", func_195044_w().func_177230_c().getRegistryName().func_110623_a() }), new Object[0]); } protected Container func_213906_a(int id, PlayerInventory player) { IntArray intArray = new IntArray(2); intArray.func_221477_a(0, this.progress); intArray.func_221477_a(1, getGrindTime()); return (Container)new MillstoneContainer(id, player, this, intArray); } public void handleUpdateTag(CompoundNBT tag) { super.handleUpdateTag(tag); readData(tag); } public CompoundNBT func_189517_E_() { CompoundNBT tag = super.func_189517_E_(); writeData(tag); return tag; } public void onDataPacket(NetworkManager net, SUpdateTileEntityPacket pkt) { readData(pkt.func_148857_g()); } public SUpdateTileEntityPacket func_189518_D_() { CompoundNBT var1 = new CompoundNBT(); writeData(var1); return new SUpdateTileEntityPacket(func_174877_v(), 5, var1); }    return super.getCapability(capability, facing); } public ItemStack func_70298_a(int index, int count) { ItemStack itemstack = ItemStackHelper.func_188382_a((List)this.contents, index, count); if (!itemstack.func_190926_b()) func_70296_d();  if (index == 0 && !canGrind()) reset();  return itemstack; } public ItemStack func_70304_b(int index) { return ItemStackHelper.func_188383_a((List)this.contents, index); } public void func_70299_a(int index, ItemStack stack) { if (index == 0 && !func_70301_a(index).func_77969_a(stack)) reset();  this.contents.set(index, stack); if (stack.func_190916_E() > func_70297_j_()) stack.func_190920_e(func_70297_j_());  func_70296_d(); } private void reset() { this.progress = -1; func_145831_w().func_175656_a(this.field_174879_c, (BlockState)func_195044_w().func_206870_a((IProperty)Millstone.ENABLE, Boolean.valueOf(false))); } public void insertInventorySlotContents(int index, ItemStack insertStack) { if (insertStack == null || insertStack.func_190926_b()) return;  if (isSlotEmpty(index)) { func_70299_a(index, insertStack); } else if (func_70301_a(index).func_77969_a(insertStack)) { ItemStack stack = (ItemStack)this.contents.get(index); stack.func_190920_e(stack.func_190916_E() + insertStack.func_190916_E()); if (stack.func_190916_E() > func_70297_j_()) stack.func_190920_e(func_70297_j_());  func_70296_d(); }  } public boolean func_70300_a(PlayerEntity player) { if (this.field_145850_b.func_175625_s(this.field_174879_c) != this) return false;  return (player.func_70092_e(this.field_174879_c.func_177958_n() + 0.5D, this.field_174879_c.func_177956_o() + 0.5D, this.field_174879_c.func_177952_p() + 0.5D) <= 64.0D); } public void func_174888_l() { this.contents.clear(); } public ITextComponent func_213907_g() { return (ITextComponent)new TranslationTextComponent(String.join(".", new CharSequence[] { "container", "meshi", func_195044_w().func_177230_c().getRegistryName().func_110623_a() }), new Object[0]); } protected Container func_213906_a(int id, PlayerInventory player) { IntArray intArray = new IntArray(2); intArray.func_221477_a(0, this.progress); intArray.func_221477_a(1, getGrindTime()); return (Container)new MillstoneContainer(id, player, this, intArray); } public void handleUpdateTag(CompoundNBT tag) { super.handleUpdateTag(tag); readData(tag); } public CompoundNBT func_189517_E_() { CompoundNBT tag = super.func_189517_E_(); writeData(tag); return tag; } public void onDataPacket(NetworkManager net, SUpdateTileEntityPacket pkt) { readData(pkt.func_148857_g()); } public SUpdateTileEntityPacket func_189518_D_() { CompoundNBT var1 = new CompoundNBT(); writeData(var1); return new SUpdateTileEntityPacket(func_174877_v(), 5, var1); }    return super.getCapability(capability, facing); } public ItemStack func_70298_a(int index, int count) { ItemStack itemstack = ItemStackHelper.func_188382_a((List)this.contents, index, count); if (!itemstack.func_190926_b()) func_70296_d();  if (index == 0 && !canGrind()) reset();  return itemstack; } public ItemStack func_70304_b(int index) { return ItemStackHelper.func_188383_a((List)this.contents, index); } public void func_70299_a(int index, ItemStack stack) { if (index == 0 && !func_70301_a(index).func_77969_a(stack)) reset();  this.contents.set(index, stack); if (stack.func_190916_E() > func_70297_j_()) stack.func_190920_e(func_70297_j_());  func_70296_d(); } private void reset() { this.progress = -1; func_145831_w().func_175656_a(this.field_174879_c, (BlockState)func_195044_w().func_206870_a((IProperty)Millstone.ENABLE, Boolean.valueOf(false))); } public void insertInventorySlotContents(int index, ItemStack insertStack) { if (insertStack == null || insertStack.func_190926_b()) return;  if (isSlotEmpty(index)) { func_70299_a(index, insertStack); } else if (func_70301_a(index).func_77969_a(insertStack)) { ItemStack stack = (ItemStack)this.contents.get(index); stack.func_190920_e(stack.func_190916_E() + insertStack.func_190916_E()); if (stack.func_190916_E() > func_70297_j_()) stack.func_190920_e(func_70297_j_());  func_70296_d(); }  } public boolean func_70300_a(PlayerEntity player) { if (this.field_145850_b.func_175625_s(this.field_174879_c) != this) return false;  return (player.func_70092_e(this.field_174879_c.func_177958_n() + 0.5D, this.field_174879_c.func_177956_o() + 0.5D, this.field_174879_c.func_177952_p() + 0.5D) <= 64.0D); } public void func_174888_l() { this.contents.clear(); } public ITextComponent func_213907_g() { return (ITextComponent)new TranslationTextComponent(String.join(".", new CharSequence[] { "container", "meshi", func_195044_w().func_177230_c().getRegistryName().func_110623_a() }), new Object[0]); } protected Container func_213906_a(int id, PlayerInventory player) { IntArray intArray = new IntArray(2); intArray.func_221477_a(0, this.progress); intArray.func_221477_a(1, getGrindTime()); return (Container)new MillstoneContainer(id, player, this, intArray); } public void handleUpdateTag(CompoundNBT tag) { super.handleUpdateTag(tag); readData(tag); } public CompoundNBT func_189517_E_() { CompoundNBT tag = super.func_189517_E_(); writeData(tag); return tag; } public void onDataPacket(NetworkManager net, SUpdateTileEntityPacket pkt) { readData(pkt.func_148857_g()); } public SUpdateTileEntityPacket func_189518_D_() { CompoundNBT var1 = new CompoundNBT(); writeData(var1); return new SUpdateTileEntityPacket(func_174877_v(), 5, var1); }    return super.getCapability(capability, facing); } public ItemStack func_70298_a(int index, int count) { ItemStack itemstack = ItemStackHelper.func_188382_a((List)this.contents, index, count); if (!itemstack.func_190926_b()) func_70296_d();  if (index == 0 && !canGrind()) reset();  return itemstack; } public ItemStack func_70304_b(int index) { return ItemStackHelper.func_188383_a((List)this.contents, index); } public void func_70299_a(int index, ItemStack stack) { if (index == 0 && !func_70301_a(index).func_77969_a(stack)) reset();  this.contents.set(index, stack); if (stack.func_190916_E() > func_70297_j_()) stack.func_190920_e(func_70297_j_());  func_70296_d(); } private void reset() { this.progress = -1; func_145831_w().func_175656_a(this.field_174879_c, (BlockState)func_195044_w().func_206870_a((IProperty)Millstone.ENABLE, Boolean.valueOf(false))); } public void insertInventorySlotContents(int index, ItemStack insertStack) { if (insertStack == null || insertStack.func_190926_b()) return;  if (isSlotEmpty(index)) { func_70299_a(index, insertStack); } else if (func_70301_a(index).func_77969_a(insertStack)) { ItemStack stack = (ItemStack)this.contents.get(index); stack.func_190920_e(stack.func_190916_E() + insertStack.func_190916_E()); if (stack.func_190916_E() > func_70297_j_()) stack.func_190920_e(func_70297_j_());  func_70296_d(); }  } public boolean func_70300_a(PlayerEntity player) { if (this.field_145850_b.func_175625_s(this.field_174879_c) != this) return false;  return (player.func_70092_e(this.field_174879_c.func_177958_n() + 0.5D, this.field_174879_c.func_177956_o() + 0.5D, this.field_174879_c.func_177952_p() + 0.5D) <= 64.0D); } public void func_174888_l() { this.contents.clear(); } public ITextComponent func_213907_g() { return (ITextComponent)new TranslationTextComponent(String.join(".", new CharSequence[] { "container", "meshi", func_195044_w().func_177230_c().getRegistryName().func_110623_a() }), new Object[0]); } protected Container func_213906_a(int id, PlayerInventory player) { IntArray intArray = new IntArray(2); intArray.func_221477_a(0, this.progress); intArray.func_221477_a(1, getGrindTime()); return (Container)new MillstoneContainer(id, player, this, intArray); } public void handleUpdateTag(CompoundNBT tag) { super.handleUpdateTag(tag); readData(tag); } public CompoundNBT func_189517_E_() { CompoundNBT tag = super.func_189517_E_(); writeData(tag); return tag; } public void onDataPacket(NetworkManager net, SUpdateTileEntityPacket pkt) { readData(pkt.func_148857_g()); } public SUpdateTileEntityPacket func_189518_D_() { CompoundNBT var1 = new CompoundNBT(); writeData(var1); return new SUpdateTileEntityPacket(func_174877_v(), 5, var1); }    return super.getCapability(capability, facing); } public ItemStack func_70298_a(int index, int count) { ItemStack itemstack = ItemStackHelper.func_188382_a((List)this.contents, index, count); if (!itemstack.func_190926_b()) func_70296_d();  if (index == 0 && !canGrind()) reset();  return itemstack; } public ItemStack func_70304_b(int index) { return ItemStackHelper.func_188383_a((List)this.contents, index); } public void func_70299_a(int index, ItemStack stack) { if (index == 0 && !func_70301_a(index).func_77969_a(stack)) reset();  this.contents.set(index, stack); if (stack.func_190916_E() > func_70297_j_()) stack.func_190920_e(func_70297_j_());  func_70296_d(); } private void reset() { this.progress = -1; func_145831_w().func_175656_a(this.field_174879_c, (BlockState)func_195044_w().func_206870_a((IProperty)Millstone.ENABLE, Boolean.valueOf(false))); } public void insertInventorySlotContents(int index, ItemStack insertStack) { if (insertStack == null || insertStack.func_190926_b()) return;  if (isSlotEmpty(index)) { func_70299_a(index, insertStack); } else if (func_70301_a(index).func_77969_a(insertStack)) { ItemStack stack = (ItemStack)this.contents.get(index); stack.func_190920_e(stack.func_190916_E() + insertStack.func_190916_E()); if (stack.func_190916_E() > func_70297_j_()) stack.func_190920_e(func_70297_j_());  func_70296_d(); }  } public boolean func_70300_a(PlayerEntity player) { if (this.field_145850_b.func_175625_s(this.field_174879_c) != this) return false;  return (player.func_70092_e(this.field_174879_c.func_177958_n() + 0.5D, this.field_174879_c.func_177956_o() + 0.5D, this.field_174879_c.func_177952_p() + 0.5D) <= 64.0D); } public void func_174888_l() { this.contents.clear(); } public ITextComponent func_213907_g() { return (ITextComponent)new TranslationTextComponent(String.join(".", new CharSequence[] { "container", "meshi", func_195044_w().func_177230_c().getRegistryName().func_110623_a() }), new Object[0]); } protected Container func_213906_a(int id, PlayerInventory player) { IntArray intArray = new IntArray(2); intArray.func_221477_a(0, this.progress); intArray.func_221477_a(1, getGrindTime()); return (Container)new MillstoneContainer(id, player, this, intArray); } public void handleUpdateTag(CompoundNBT tag) { super.handleUpdateTag(tag); readData(tag); } public CompoundNBT func_189517_E_() { CompoundNBT tag = super.func_189517_E_(); writeData(tag); return tag; } public void onDataPacket(NetworkManager net, SUpdateTileEntityPacket pkt) { readData(pkt.func_148857_g()); } public SUpdateTileEntityPacket func_189518_D_() { CompoundNBT var1 = new CompoundNBT(); writeData(var1); return new SUpdateTileEntityPacket(func_174877_v(), 5, var1); }    return super.getCapability(capability, facing); } public ItemStack func_70298_a(int index, int count) { ItemStack itemstack = ItemStackHelper.func_188382_a((List)this.contents, index, count); if (!itemstack.func_190926_b()) func_70296_d();  if (index == 0 && !canGrind()) reset();  return itemstack; } public ItemStack func_70304_b(int index) { return ItemStackHelper.func_188383_a((List)this.contents, index); } public void func_70299_a(int index, ItemStack stack) { if (index == 0 && !func_70301_a(index).func_77969_a(stack)) reset();  this.contents.set(index, stack); if (stack.func_190916_E() > func_70297_j_()) stack.func_190920_e(func_70297_j_());  func_70296_d(); } private void reset() { this.progress = -1; func_145831_w().func_175656_a(this.field_174879_c, (BlockState)func_195044_w().func_206870_a((IProperty)Millstone.ENABLE, Boolean.valueOf(false))); } public void insertInventorySlotContents(int index, ItemStack insertStack) { if (insertStack == null || insertStack.func_190926_b()) return;  if (isSlotEmpty(index)) { func_70299_a(index, insertStack); } else if (func_70301_a(index).func_77969_a(insertStack)) { ItemStack stack = (ItemStack)this.contents.get(index); stack.func_190920_e(stack.func_190916_E() + insertStack.func_190916_E()); if (stack.func_190916_E() > func_70297_j_()) stack.func_190920_e(func_70297_j_());  func_70296_d(); }  } public boolean func_70300_a(PlayerEntity player) { if (this.field_145850_b.func_175625_s(this.field_174879_c) != this) return false;  return (player.func_70092_e(this.field_174879_c.func_177958_n() + 0.5D, this.field_174879_c.func_177956_o() + 0.5D, this.field_174879_c.func_177952_p() + 0.5D) <= 64.0D); } public void func_174888_l() { this.contents.clear(); } public ITextComponent func_213907_g() { return (ITextComponent)new TranslationTextComponent(String.join(".", new CharSequence[] { "container", "meshi", func_195044_w().func_177230_c().getRegistryName().func_110623_a() }), new Object[0]); } protected Container func_213906_a(int id, PlayerInventory player) { IntArray intArray = new IntArray(2); intArray.func_221477_a(0, this.progress); intArray.func_221477_a(1, getGrindTime()); return (Container)new MillstoneContainer(id, player, this, intArray); } public void handleUpdateTag(CompoundNBT tag) { super.handleUpdateTag(tag); readData(tag); } public CompoundNBT func_189517_E_() { CompoundNBT tag = super.func_189517_E_(); writeData(tag); return tag; } public void onDataPacket(NetworkManager net, SUpdateTileEntityPacket pkt) { readData(pkt.func_148857_g()); } public SUpdateTileEntityPacket func_189518_D_() { CompoundNBT var1 = new CompoundNBT(); writeData(var1); return new SUpdateTileEntityPacket(func_174877_v(), 5, var1); }    return super.getCapability(capability, facing); } public ItemStack func_70298_a(int index, int count) { ItemStack itemstack = ItemStackHelper.func_188382_a((List)this.contents, index, count); if (!itemstack.func_190926_b()) func_70296_d();  if (index == 0 && !canGrind()) reset();  return itemstack; } public ItemStack func_70304_b(int index) { return ItemStackHelper.func_188383_a((List)this.contents, index); } public void func_70299_a(int index, ItemStack stack) { if (index == 0 && !func_70301_a(index).func_77969_a(stack)) reset();  this.contents.set(index, stack); if (stack.func_190916_E() > func_70297_j_()) stack.func_190920_e(func_70297_j_());  func_70296_d(); } private void reset() { this.progress = -1; func_145831_w().func_175656_a(this.field_174879_c, (BlockState)func_195044_w().func_206870_a((IProperty)Millstone.ENABLE, Boolean.valueOf(false))); } public void insertInventorySlotContents(int index, ItemStack insertStack) { if (insertStack == null || insertStack.func_190926_b()) return;  if (isSlotEmpty(index)) { func_70299_a(index, insertStack); } else if (func_70301_a(index).func_77969_a(insertStack)) { ItemStack stack = (ItemStack)this.contents.get(index); stack.func_190920_e(stack.func_190916_E() + insertStack.func_190916_E()); if (stack.func_190916_E() > func_70297_j_()) stack.func_190920_e(func_70297_j_());  func_70296_d(); }  } public boolean func_70300_a(PlayerEntity player) { if (this.field_145850_b.func_175625_s(this.field_174879_c) != this) return false;  return (player.func_70092_e(this.field_174879_c.func_177958_n() + 0.5D, this.field_174879_c.func_177956_o() + 0.5D, this.field_174879_c.func_177952_p() + 0.5D) <= 64.0D); } public void func_174888_l() { this.contents.clear(); } public ITextComponent func_213907_g() { return (ITextComponent)new TranslationTextComponent(String.join(".", new CharSequence[] { "container", "meshi", func_195044_w().func_177230_c().getRegistryName().func_110623_a() }), new Object[0]); } protected Container func_213906_a(int id, PlayerInventory player) { IntArray intArray = new IntArray(2); intArray.func_221477_a(0, this.progress); intArray.func_221477_a(1, getGrindTime()); return (Container)new MillstoneContainer(id, player, this, intArray); } public void handleUpdateTag(CompoundNBT tag) { super.handleUpdateTag(tag); readData(tag); } public CompoundNBT func_189517_E_() { CompoundNBT tag = super.func_189517_E_(); writeData(tag); return tag; } public void onDataPacket(NetworkManager net, SUpdateTileEntityPacket pkt) { readData(pkt.func_148857_g()); } public SUpdateTileEntityPacket func_189518_D_() { CompoundNBT var1 = new CompoundNBT(); writeData(var1); return new SUpdateTileEntityPacket(func_174877_v(), 5, var1); }    return super.getCapability(capability, facing); } public ItemStack func_70298_a(int index, int count) { ItemStack itemstack = ItemStackHelper.func_188382_a((List)this.contents, index, count); if (!itemstack.func_190926_b()) func_70296_d();  if (index == 0 && !canGrind()) reset();  return itemstack; } public ItemStack func_70304_b(int index) { return ItemStackHelper.func_188383_a((List)this.contents, index); } public void func_70299_a(int index, ItemStack stack) { if (index == 0 && !func_70301_a(index).func_77969_a(stack)) reset();  this.contents.set(index, stack); if (stack.func_190916_E() > func_70297_j_()) stack.func_190920_e(func_70297_j_());  func_70296_d(); } private void reset() { this.progress = -1; func_145831_w().func_175656_a(this.field_174879_c, (BlockState)func_195044_w().func_206870_a((IProperty)Millstone.ENABLE, Boolean.valueOf(false))); } public void insertInventorySlotContents(int index, ItemStack insertStack) { if (insertStack == null || insertStack.func_190926_b()) return;  if (isSlotEmpty(index)) { func_70299_a(index, insertStack); } else if (func_70301_a(index).func_77969_a(insertStack)) { ItemStack stack = (ItemStack)this.contents.get(index); stack.func_190920_e(stack.func_190916_E() + insertStack.func_190916_E()); if (stack.func_190916_E() > func_70297_j_()) stack.func_190920_e(func_70297_j_());  func_70296_d(); }  } public boolean func_70300_a(PlayerEntity player) { if (this.field_145850_b.func_175625_s(this.field_174879_c) != this) return false;  return (player.func_70092_e(this.field_174879_c.func_177958_n() + 0.5D, this.field_174879_c.func_177956_o() + 0.5D, this.field_174879_c.func_177952_p() + 0.5D) <= 64.0D); } public void func_174888_l() { this.contents.clear(); } public ITextComponent func_213907_g() { return (ITextComponent)new TranslationTextComponent(String.join(".", new CharSequence[] { "container", "meshi", func_195044_w().func_177230_c().getRegistryName().func_110623_a() }), new Object[0]); } protected Container func_213906_a(int id, PlayerInventory player) { IntArray intArray = new IntArray(2); intArray.func_221477_a(0, this.progress); intArray.func_221477_a(1, getGrindTime()); return (Container)new MillstoneContainer(id, player, this, intArray); } public void handleUpdateTag(CompoundNBT tag) { super.handleUpdateTag(tag); readData(tag); } public CompoundNBT func_189517_E_() { CompoundNBT tag = super.func_189517_E_(); writeData(tag); return tag; } public void onDataPacket(NetworkManager net, SUpdateTileEntityPacket pkt) { readData(pkt.func_148857_g()); } public SUpdateTileEntityPacket func_189518_D_() { CompoundNBT var1 = new CompoundNBT(); writeData(var1); return new SUpdateTileEntityPacket(func_174877_v(), 5, var1); }    return super.getCapability(capability, facing); } public ItemStack func_70298_a(int index, int count) { ItemStack itemstack = ItemStackHelper.func_188382_a((List)this.contents, index, count); if (!itemstack.func_190926_b()) func_70296_d();  if (index == 0 && !canGrind()) reset();  return itemstack; } public ItemStack func_70304_b(int index) { return ItemStackHelper.func_188383_a((List)this.contents, index); } public void func_70299_a(int index, ItemStack stack) { if (index == 0 && !func_70301_a(index).func_77969_a(stack)) reset();  this.contents.set(index, stack); if (stack.func_190916_E() > func_70297_j_()) stack.func_190920_e(func_70297_j_());  func_70296_d(); } private void reset() { this.progress = -1; func_145831_w().func_175656_a(this.field_174879_c, (BlockState)func_195044_w().func_206870_a((IProperty)Millstone.ENABLE, Boolean.valueOf(false))); } public void insertInventorySlotContents(int index, ItemStack insertStack) { if (insertStack == null || insertStack.func_190926_b()) return;  if (isSlotEmpty(index)) { func_70299_a(index, insertStack); } else if (func_70301_a(index).func_77969_a(insertStack)) { ItemStack stack = (ItemStack)this.contents.get(index); stack.func_190920_e(stack.func_190916_E() + insertStack.func_190916_E()); if (stack.func_190916_E() > func_70297_j_()) stack.func_190920_e(func_70297_j_());  func_70296_d(); }  } public boolean func_70300_a(PlayerEntity player) { if (this.field_145850_b.func_175625_s(this.field_174879_c) != this) return false;  return (player.func_70092_e(this.field_174879_c.func_177958_n() + 0.5D, this.field_174879_c.func_177956_o() + 0.5D, this.field_174879_c.func_177952_p() + 0.5D) <= 64.0D); } public void func_174888_l() { this.contents.clear(); } public ITextComponent func_213907_g() { return (ITextComponent)new TranslationTextComponent(String.join(".", new CharSequence[] { "container", "meshi", func_195044_w().func_177230_c().getRegistryName().func_110623_a() }), new Object[0]); } protected Container func_213906_a(int id, PlayerInventory player) { IntArray intArray = new IntArray(2); intArray.func_221477_a(0, this.progress); intArray.func_221477_a(1, getGrindTime()); return (Container)new MillstoneContainer(id, player, this, intArray); } public void handleUpdateTag(CompoundNBT tag) { super.handleUpdateTag(tag); readData(tag); } public CompoundNBT func_189517_E_() { CompoundNBT tag = super.func_189517_E_(); writeData(tag); return tag; } public void onDataPacket(NetworkManager net, SUpdateTileEntityPacket pkt) { readData(pkt.func_148857_g()); } public SUpdateTileEntityPacket func_189518_D_() { CompoundNBT var1 = new CompoundNBT(); writeData(var1); return new SUpdateTileEntityPacket(func_174877_v(), 5, var1); }    return super.getCapability(capability, facing); } public ItemStack func_70298_a(int index, int count) { ItemStack itemstack = ItemStackHelper.func_188382_a((List)this.contents, index, count); if (!itemstack.func_190926_b()) func_70296_d();  if (index == 0 && !canGrind()) reset();  return itemstack; } public ItemStack func_70304_b(int index) { return ItemStackHelper.func_188383_a((List)this.contents, index); } public void func_70299_a(int index, ItemStack stack) { if (index == 0 && !func_70301_a(index).func_77969_a(stack)) reset();  this.contents.set(index, stack); if (stack.func_190916_E() > func_70297_j_()) stack.func_190920_e(func_70297_j_());  func_70296_d(); } private void reset() { this.progress = -1; func_145831_w().func_175656_a(this.field_174879_c, (BlockState)func_195044_w().func_206870_a((IProperty)Millstone.ENABLE, Boolean.valueOf(false))); } public void insertInventorySlotContents(int index, ItemStack insertStack) { if (insertStack == null || insertStack.func_190926_b()) return;  if (isSlotEmpty(index)) { func_70299_a(index, insertStack); } else if (func_70301_a(index).func_77969_a(insertStack)) { ItemStack stack = (ItemStack)this.contents.get(index); stack.func_190920_e(stack.func_190916_E() + insertStack.func_190916_E()); if (stack.func_190916_E() > func_70297_j_()) stack.func_190920_e(func_70297_j_());  func_70296_d(); }  } public boolean func_70300_a(PlayerEntity player) { if (this.field_145850_b.func_175625_s(this.field_174879_c) != this) return false;  return (player.func_70092_e(this.field_174879_c.func_177958_n() + 0.5D, this.field_174879_c.func_177956_o() + 0.5D, this.field_174879_c.func_177952_p() + 0.5D) <= 64.0D); } public void func_174888_l() { this.contents.clear(); } public ITextComponent func_213907_g() { return (ITextComponent)new TranslationTextComponent(String.join(".", new CharSequence[] { "container", "meshi", func_195044_w().func_177230_c().getRegistryName().func_110623_a() }), new Object[0]); } protected Container func_213906_a(int id, PlayerInventory player) { IntArray intArray = new IntArray(2); intArray.func_221477_a(0, this.progress); intArray.func_221477_a(1, getGrindTime()); return (Container)new MillstoneContainer(id, player, this, intArray); } public void handleUpdateTag(CompoundNBT tag) { super.handleUpdateTag(tag); readData(tag); } public CompoundNBT func_189517_E_() { CompoundNBT tag = super.func_189517_E_(); writeData(tag); return tag; } public void onDataPacket(NetworkManager net, SUpdateTileEntityPacket pkt) { readData(pkt.func_148857_g()); } public SUpdateTileEntityPacket func_189518_D_() { CompoundNBT var1 = new CompoundNBT(); writeData(var1); return new SUpdateTileEntityPacket(func_174877_v(), 5, var1); }    return super.getCapability(capability, facing); } public ItemStack func_70298_a(int index, int count) { ItemStack itemstack = ItemStackHelper.func_188382_a((List)this.contents, index, count); if (!itemstack.func_190926_b()) func_70296_d();  if (index == 0 && !canGrind()) reset();  return itemstack; } public ItemStack func_70304_b(int index) { return ItemStackHelper.func_188383_a((List)this.contents, index); } public void func_70299_a(int index, ItemStack stack) { if (index == 0 && !func_70301_a(index).func_77969_a(stack)) reset();  this.contents.set(index, stack); if (stack.func_190916_E() > func_70297_j_()) stack.func_190920_e(func_70297_j_());  func_70296_d(); } private void reset() { this.progress = -1; func_145831_w().func_175656_a(this.field_174879_c, (BlockState)func_195044_w().func_206870_a((IProperty)Millstone.ENABLE, Boolean.valueOf(false))); } public void insertInventorySlotContents(int index, ItemStack insertStack) { if (insertStack == null || insertStack.func_190926_b()) return;  if (isSlotEmpty(index)) { func_70299_a(index, insertStack); } else if (func_70301_a(index).func_77969_a(insertStack)) { ItemStack stack = (ItemStack)this.contents.get(index); stack.func_190920_e(stack.func_190916_E() + insertStack.func_190916_E()); if (stack.func_190916_E() > func_70297_j_()) stack.func_190920_e(func_70297_j_());  func_70296_d(); }  } public boolean func_70300_a(PlayerEntity player) { if (this.field_145850_b.func_175625_s(this.field_174879_c) != this) return false;  return (player.func_70092_e(this.field_174879_c.func_177958_n() + 0.5D, this.field_174879_c.func_177956_o() + 0.5D, this.field_174879_c.func_177952_p() + 0.5D) <= 64.0D); } public void func_174888_l() { this.contents.clear(); } public ITextComponent func_213907_g() { return (ITextComponent)new TranslationTextComponent(String.join(".", new CharSequence[] { "container", "meshi", func_195044_w().func_177230_c().getRegistryName().func_110623_a() }), new Object[0]); } protected Container func_213906_a(int id, PlayerInventory player) { IntArray intArray = new IntArray(2); intArray.func_221477_a(0, this.progress); intArray.func_221477_a(1, getGrindTime()); return (Container)new MillstoneContainer(id, player, this, intArray); } public void handleUpdateTag(CompoundNBT tag) { super.handleUpdateTag(tag); readData(tag); } public CompoundNBT func_189517_E_() { CompoundNBT tag = super.func_189517_E_(); writeData(tag); return tag; } public void onDataPacket(NetworkManager net, SUpdateTileEntityPacket pkt) { readData(pkt.func_148857_g()); } public SUpdateTileEntityPacket func_189518_D_() { CompoundNBT var1 = new CompoundNBT(); writeData(var1); return new SUpdateTileEntityPacket(func_174877_v(), 5, var1); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 389 */   public void func_145843_s() { super.func_145843_s();
/* 390 */     this.handlerBottom.invalidate();
/* 391 */     this.handlerSide.invalidate();
/* 392 */     this.handlerTop.invalidate(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   public void func_194018_a(RecipeItemHelper helper) {
/* 397 */     for (ItemStack itemstack : this.contents)
/* 398 */       helper.func_194112_a(itemstack); 
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 23 ms
	
*/