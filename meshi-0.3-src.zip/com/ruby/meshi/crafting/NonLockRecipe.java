/*    */ package com.ruby.meshi.crafting;
/*    */ 
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.item.crafting.IRecipe;
/*    */ 
/*    */ public interface NonLockRecipe
/*    */ {
/*    */   default boolean isUnlocked(IRecipe<? extends IInventory> recipe) {
/*  9 */     return true;
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 0 ms
	
*/