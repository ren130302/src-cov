package com.ruby.meshi.fluid;

import com.ruby.meshi.fluid.HotSpring.Flowing;
import com.ruby.meshi.fluid.HotSpring.Source;
import net.minecraft.fluid.FlowingFluid;
import net.minecraft.fluid.Fluid;

public class MeshiFluids {
   public static final FlowingFluid FLOWING_HOT_SPING = (FlowingFluid)register("flowing_hot_spring", new Flowing());
   public static final FlowingFluid HOT_SPING = (FlowingFluid)register("hot_spring", new Source());

   private static <T extends Fluid> T register(String name, T fluid) {
      return (Fluid)fluid.setRegistryName("meshi", name);
   }
}