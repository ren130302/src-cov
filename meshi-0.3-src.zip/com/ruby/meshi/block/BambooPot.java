/*    */ package com.ruby.meshi.block;
/*    */ 
/*    */ import com.ruby.meshi.block.tileentity.BambooPotTileEntity;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.BlockRenderType;
/*    */ import net.minecraft.block.BlockState;
/*    */ import net.minecraft.entity.EntityType;
/*    */ import net.minecraft.item.BlockItemUseContext;
/*    */ import net.minecraft.state.BooleanProperty;
/*    */ import net.minecraft.state.IProperty;
/*    */ import net.minecraft.state.StateContainer;
/*    */ import net.minecraft.state.properties.BlockStateProperties;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.BlockRenderLayer;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.util.math.shapes.ISelectionContext;
/*    */ import net.minecraft.util.math.shapes.VoxelShape;
/*    */ import net.minecraft.world.IBlockReader;
/*    */ 
/*    */ public class BambooPot
/*    */   extends Block {
/* 22 */   public static final VoxelShape SHAPE = Block.func_208617_a(6.0D, 0.0D, 6.0D, 10.0D, 4.0D, 10.0D);
/*    */ 
/* 24 */   public static final BooleanProperty ATTACHED = BlockStateProperties.field_208174_a;
/*    */ 
/*    */   public BambooPot(Block.Properties properties) {
/* 27 */     super(properties);
/* 28 */     func_180632_j((BlockState)func_176223_P().func_206870_a((IProperty)ATTACHED, Boolean.valueOf(false)));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public BlockState func_196258_a(BlockItemUseContext context) {
/* 35 */     return super.func_196258_a(context);
/*    */   }
/*    */ 
/*    */ 
/*    */   protected void func_206840_a(StateContainer.Builder<Block, BlockState> builder) {
/* 40 */     super.func_206840_a(builder);
/* 41 */     builder.func_206894_a(new IProperty[] { (IProperty)ATTACHED });
/*    */   }
/*    */ 
/*    */ 
/*    */   public BlockRenderType func_149645_b(BlockState state) {
/* 46 */     return BlockRenderType.MODEL;
/*    */   }
/*    */ 
/*    */ 
/*    */   public BlockRenderLayer func_180664_k() {
/* 51 */     return BlockRenderLayer.CUTOUT;
/*    */   }
/*    */ 
/*    */ 
/*    */   public VoxelShape func_220053_a(BlockState state, IBlockReader worldIn, BlockPos pos, ISelectionContext context) {
/* 56 */     return SHAPE;
/*    */   }
/*    */ 
/*    */ 
/*    */   public boolean func_200123_i(BlockState state, IBlockReader reader, BlockPos pos) {
/* 61 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   public boolean func_220060_c(BlockState state, IBlockReader worldIn, BlockPos pos) {
/* 66 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   public boolean func_220081_d(BlockState state, IBlockReader worldIn, BlockPos pos) {
/* 71 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   public boolean func_220067_a(BlockState state, IBlockReader worldIn, BlockPos pos, EntityType<?> type) {
/* 76 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   public boolean hasTileEntity(BlockState state) {
/* 81 */     return ((Boolean)state.func_177229_b((IProperty)ATTACHED)).booleanValue();
/*    */   }
/*    */ 
/*    */ 
/*    */   public TileEntity createTileEntity(BlockState state, IBlockReader world) {
/* 86 */     return new BambooPotTileEntity();
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 4 ms
	
*/