/*    */ package com.ruby.meshi.common;
/*    */ 
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.tags.ItemTags;
/*    */ import net.minecraft.tags.Tag;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ public class HiganTags
/*    */ {
/*    */   public static class ITEM
/*    */   {
/* 12 */     public static final Tag<Item> MEAT = (Tag<Item>)new ItemTags.Wrapper(new ResourceLocation("meshi", "meat"));
/* 13 */     public static final Tag<Item> FISH = (Tag<Item>)new ItemTags.Wrapper(new ResourceLocation("meshi", "fish"));
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 1 ms
	
*/