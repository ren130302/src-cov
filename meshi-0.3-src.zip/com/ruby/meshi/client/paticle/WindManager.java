/*     */ package com.ruby.meshi.client.paticle;
/*     */ 
/*     */ import java.util.Random;
/*     */ import net.minecraft.util.Direction;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraftforge.api.distmarker.Dist;
/*     */ import net.minecraftforge.event.TickEvent;
/*     */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*     */ import net.minecraftforge.fml.LogicalSide;
/*     */ import net.minecraftforge.fml.common.Mod;
/*     */ import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE, value = {Dist.CLIENT})
/*     */ public class WindManager
/*     */ {
/*  33 */   private static Direction windDir = Direction.NORTH; private static int prevWindAngle;  private static Direction windDir = Direction.NORTH; private static int prevWindAngle;
/*  34 */   private static int windAngle = (int)(360.0D * Math.random()); private static float prevWindPower; private static float windPower; private static double motionX;  private static int windAngle = (int)(360.0D * Math.random()); private static float prevWindPower; private static float windPower; private static double motionX;  private static int windAngle = (int)(360.0D * Math.random()); private static float prevWindPower; private static float windPower; private static double motionX;  private static int windAngle = (int)(360.0D * Math.random()); private static float prevWindPower; private static float windPower; private static double motionX;
/*  35 */   private static int maxChangeAngle = 180; private static double motionY; private static double motionZ; private static int coolTimer; private static int chengeTime;  private static int maxChangeAngle = 180; private static double motionY; private static double motionZ; private static int coolTimer; private static int chengeTime;  private static int maxChangeAngle = 180; private static double motionY; private static double motionZ; private static int coolTimer; private static int chengeTime;  private static int maxChangeAngle = 180; private static double motionY; private static double motionZ; private static int coolTimer; private static int chengeTime;  private static int maxChangeAngle = 180; private static double motionY; private static double motionZ; private static int coolTimer; private static int chengeTime;
/*  36 */   private static int minChangeAngle = 40;
/*  37 */   private static float maxWindPow = 0.04F;
/*  38 */   private static int updateRate = 100;
/*     */   static {
/*  40 */     chengeTime = 1800 / updateRate;
/*     */   }
/*     */ 
/*     */ 
/*     */   @SubscribeEvent
/*     */   public static void tick(TickEvent.PlayerTickEvent e) {
/*  46 */     if (e.side == LogicalSide.CLIENT)
/*     */     {
/*  48 */       if (e.phase == TickEvent.Phase.START) {
/*  49 */         if (e.player.field_70170_p.func_82737_E() % updateRate == 0L) {
/*  50 */           Random rand = e.player.field_70170_p.field_73012_v;
/*  51 */           prevWindAngle = windAngle;
/*  52 */           prevWindPower = windPower;
/*  53 */           if (--coolTimer < 0) {
/*     */             
/*  55 */             windAngle += getRandomChange(rand, maxChangeAngle) % 360;
/*  56 */             windPower = maxWindPow * rand.nextFloat();
/*  57 */             coolTimer = chengeTime + rand.nextInt(chengeTime);
/*     */           } else {
/*     */             
/*  60 */             if (rand.nextFloat() < 0.3F) {
/*  61 */               windAngle += getRandomChange(rand, minChangeAngle) % 360;
/*     */             }
/*     */             
/*  64 */             windPower += getRandomChange(rand, maxWindPow) * 0.2F;
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  71 */         calcMotion((float)(e.player.field_70170_p.func_82737_E() % updateRate) / updateRate);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   private static int getRandomChange(Random rand, int i) {
/*  78 */     return rand.nextInt(i) - rand.nextInt(i);
/*     */   }
/*     */ 
/*     */   private static float getRandomChange(Random rand, float f) {
/*  82 */     return f * rand.nextFloat() - f * rand.nextFloat();
/*     */   }
/*     */ 
/*     */   private static void calcMotion(float partialTicks) {
/*  86 */     float pow = MathHelper.func_219799_g(partialTicks, prevWindPower, windPower);
/*  87 */     float angle = MathHelper.func_219799_g(partialTicks, prevWindAngle, windAngle);
/*  88 */     double rad = Math.toRadians(angle);
/*  89 */     motionZ = (pow * MathHelper.func_76134_b((float)rad));
/*  90 */     motionX = (pow * -MathHelper.func_76126_a((float)rad));
/*  91 */     windDir = Direction.func_176733_a(angle);
/*     */   }
/*     */ 
/*     */ 
/*     */   public static void setWind(int angle, float power) {
/*  96 */     prevWindAngle = windAngle;
/*  97 */     windAngle = angle;
/*  98 */     prevWindPower = windPower;
/*  99 */     windPower = power;
/*     */   }
/*     */ 
/*     */   public static boolean isStrongWind() {
/* 103 */     return (prevWindPower > 0.025F);
/*     */   }
/*     */ 
/*     */   public static float getWindPow() {
/* 107 */     return prevWindPower;
/*     */   }
/*     */ 
/*     */   public static Direction getWindDir() {
/* 111 */     return windDir;
/*     */   }
/*     */ 
/*     */   public static double getMotionX() {
/* 115 */     return motionX;
/*     */   }
/*     */ 
/*     */   public static double getMotionY() {
/* 119 */     return motionY;
/*     */   }
/*     */ 
/*     */   public static double getMotionZ() {
/* 123 */     return motionZ;
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 5 ms
	
*/