/*    */ package com.ruby.meshi.item;
/*    */ 
/*    */ import com.ruby.meshi.entity.ShurikenEntity;
/*    */ import java.util.List;
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraft.client.util.ITooltipFlag;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ import net.minecraft.entity.ai.attributes.AttributeModifier;
/*    */ import net.minecraft.entity.player.PlayerEntity;
/*    */ import net.minecraft.item.IItemTier;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.stats.Stats;
/*    */ import net.minecraft.util.ActionResult;
/*    */ import net.minecraft.util.ActionResultType;
/*    */ import net.minecraft.util.Hand;
/*    */ import net.minecraft.util.SoundCategory;
/*    */ import net.minecraft.util.SoundEvents;
/*    */ import net.minecraft.util.text.ITextComponent;
/*    */ import net.minecraft.util.text.TextFormatting;
/*    */ import net.minecraft.util.text.TranslationTextComponent;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.api.distmarker.Dist;
/*    */ import net.minecraftforge.api.distmarker.OnlyIn;
/*    */ 
/*    */ public class Shuriken
/*    */   extends Item
/*    */ {
/*    */   private final IItemTier tier;
/*    */   
/*    */   public Shuriken(IItemTier tierIn, Item.Properties builder) {
/* 33 */     super(builder);
/* 34 */     this.tier = tierIn;
/*    */   }
/*    */ 
/*    */   public IItemTier getTier() {
/* 38 */     return this.tier;
/*    */   }
/*    */ 
/*    */ 
/*    */   public ActionResult<ItemStack> func_77659_a(World worldIn, PlayerEntity playerIn, Hand handIn) {
/* 43 */     ItemStack itemstack = playerIn.func_184586_b(handIn);
/* 44 */     if (!playerIn.field_71075_bZ.field_75098_d) {
/* 45 */       itemstack.func_190918_g(1);
/*    */     }
/*    */     
/* 48 */     worldIn.func_184148_a((PlayerEntity)null, playerIn.field_70165_t, playerIn.field_70163_u, playerIn.field_70161_v, SoundEvents.field_187797_fA, SoundCategory.PLAYERS, 0.5F, 0.4F / (field_77697_d.nextFloat() * 0.4F + 0.8F));
/* 49 */     if (!worldIn.field_72995_K) {
/* 50 */       ShurikenEntity entity = new ShurikenEntity((LivingEntity)playerIn, worldIn);
/* 51 */       entity.setItemStack(itemstack);
/* 52 */       entity.func_184547_a((Entity)playerIn, playerIn.field_70125_A, playerIn.field_70177_z, 0.0F, 0.8F, 5.0F);
/* 53 */       worldIn.func_217376_c((Entity)entity);
/* 54 */       playerIn.func_184811_cZ().func_185145_a(this, 25);
/*    */     } 
/*    */     
/* 57 */     playerIn.func_71029_a(Stats.field_75929_E.func_199076_b(this));
/* 58 */     return new ActionResult(ActionResultType.SUCCESS, itemstack);
/*    */   }
/*    */ 
/*    */ 
/*    */   public boolean func_82789_a(ItemStack toRepair, ItemStack repair) {
/* 63 */     return false;
/*    */   }
/*    */ 
/*    */   public float getAttackDamage(ItemStack itemStack) {
/* 67 */     return this.tier.func_200929_c();
/*    */   }
/*    */ 
/*    */ 
/*    */   @OnlyIn(Dist.CLIENT)
/*    */   public void func_77624_a(ItemStack stack, @Nullable World worldIn, List<ITextComponent> tooltip, ITooltipFlag flagIn) {
/* 73 */     tooltip.add((new TranslationTextComponent("attribute.modifier.plus." + AttributeModifier.Operation.ADDITION.func_220371_a(), new Object[] { ItemStack.field_111284_a.format(getAttackDamage(stack)), new TranslationTextComponent("tooltip.meshi.throwing_damage", new Object[0]) })).func_211708_a(TextFormatting.DARK_GREEN));
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 9 ms
	
*/