/*    */ package com.ruby.meshi.block;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.BlockState;
/*    */ import net.minecraft.block.LogBlock;
/*    */ import net.minecraft.block.material.MaterialColor;
/*    */ import net.minecraftforge.common.ToolType;
/*    */ 
/*    */ public class HiganLogBlock extends LogBlock {
/*    */   public HiganLogBlock(MaterialColor color, Block.Properties prop) {
/* 11 */     super(color, prop);
/*    */   }
/*    */ 
/*    */ 
/*    */   public ToolType getHarvestTool(BlockState state) {
/* 16 */     return ToolType.AXE;
/*    */   }
/*    */ 
/*    */ 
/*    */   public int getHarvestLevel(BlockState state) {
/* 21 */     return 0;
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 1 ms
	
*/