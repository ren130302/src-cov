package com.ruby.meshi.crafting;

public interface CookingTimerRecipe {
   int getCookTime();
}