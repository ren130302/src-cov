/*    */ package com.ruby.meshi.client.renderer;
/*    */ 
/*    */ import com.ruby.meshi.block.tileentity.MillstoneTileEntity;
/*    */ import net.minecraft.client.renderer.entity.model.RendererModel;
/*    */ import net.minecraft.client.renderer.model.Model;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntityRenderer;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class MillstoneRender
/*    */   extends TileEntityRenderer<MillstoneTileEntity>
/*    */ {
/* 14 */   private static final ModelMillStone model = new ModelMillStone();
/* 15 */   private static final ResourceLocation RESOURCE = new ResourceLocation("meshi", "textures/entitys/millstone.png");
/*    */ 
/*    */ 
/*    */   public void render(MillstoneTileEntity entity, double x, double y, double z, float partialTicks, int destroyStage) {
/* 19 */     GL11.glPushMatrix();
/* 20 */     func_147499_a(RESOURCE);
/* 21 */     GL11.glTranslatef((float)x + 0.5F, (float)y + 0.5F, (float)z + 0.5F);
/* 22 */     model.render(entity, partialTicks, 0.0625F);
/* 23 */     GL11.glPopMatrix();
/*    */   }
/*    */ 
/*    */   private static class ModelMillStone
/*    */     extends Model
/*    */   {
/*    */     private RendererModel top;
/*    */     private RendererModel bottm;
/*    */     
/*    */     public ModelMillStone() {
/* 33 */       this.field_78090_t = 64;
/* 34 */       this.field_78089_u = 64;
/* 35 */       this.bottm = new RendererModel(this, 0, 25);
/* 36 */       this.bottm.func_78789_a(-8.0F, 0.0F, -8.0F, 16, 8, 16);
/* 37 */       this.bottm.func_78793_a(0.0F, 0.0F, 0.0F);
/* 38 */       this.bottm.func_78787_b(64, 64);
/* 39 */       this.bottm.field_78809_i = true;
/* 40 */       setRotation(this.bottm, 0.0F, 0.0F, 0.0F);
/* 41 */       this.top = new RendererModel(this, 0, 0);
/* 42 */       this.top.func_78789_a(-8.0F, -8.0F, -8.0F, 16, 8, 16);
/* 43 */       this.top.func_78793_a(0.0F, 0.0F, 0.0F);
/* 44 */       this.top.func_78787_b(64, 64);
/* 45 */       this.top.field_78809_i = true;
/* 46 */       setRotation(this.top, 0.0F, 0.0F, 0.0F);
/*    */     }
/*    */ 
/*    */     public void render(MillstoneTileEntity entity, float partialTicks, float scale) {
/* 50 */       this.bottm.field_78796_g = (float)(Math.PI * entity.getRoll()) / 180.0F;
/* 51 */       this.bottm.func_78785_a(scale);
/* 52 */       this.top.func_78785_a(scale);
/*    */     }
/*    */ 
/*    */     private void setRotation(RendererModel model, float x, float y, float z) {
/* 56 */       model.field_78795_f = x;
/* 57 */       model.field_78796_g = y;
/* 58 */       model.field_78808_h = z;
/*    */     }
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 6 ms
	
*/