/*     */ package com.ruby.meshi.client.paticle;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.GlStateManager;
/*     */ import com.ruby.meshi.block.SakuraLeave;
/*     */ import net.minecraft.client.particle.IParticleRenderType;
/*     */ import net.minecraft.client.particle.Particle;
/*     */ import net.minecraft.client.renderer.ActiveRenderInfo;
/*     */ import net.minecraft.client.renderer.BufferBuilder;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.texture.TextureManager;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.fluid.Fluid;
/*     */ import net.minecraft.fluid.IFluidState;
/*     */ import net.minecraft.tags.Tag;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.shapes.VoxelShape;
/*     */ import net.minecraft.world.IBlockReader;
/*     */ import net.minecraft.world.IWorldReader;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ public class PetalParticle
/*     */   extends Particle
/*     */ {
/*     */   static final float PI180 = 0.017453292F;
/*  31 */   float scale = 0.1F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PetalParticle(World worldIn, double posXIn, double posYIn, double posZIn) {
/*  43 */     this(worldIn, posXIn, posYIn, posZIn, 0.0D, 0.0D, 0.0D);
/*     */   }
/*     */ 
/*     */   public PetalParticle(World worldIn, double xCoordIn, double yCoordIn, double zCoordIn, double xSpeedIn, double ySpeedIn, double zSpeedIn) {
/*  47 */     super(worldIn, xCoordIn, yCoordIn, zCoordIn, xSpeedIn, ySpeedIn, zSpeedIn);
/*  48 */     func_187115_a(0.1F, 0.1F);
/*  49 */     this.field_187129_i = 0.0D;
/*  50 */     this.field_187130_j = (-this.field_187136_p.nextFloat() * 0.05F);
/*  51 */     this.field_187131_k = 0.0D;
/*  52 */     this.field_70547_e = Math.max((int)(600.0D / (Math.random() * 0.8D + 0.6D)), 1);
/*  53 */     this.pitch = 90.0F * (this.field_187136_p.nextFloat() - 0.5F) * 0.5F + 90.0F;
/*  54 */     this.prevPitch = this.pitch;
/*  55 */     this.yaw = 360.0F * this.field_187136_p.nextFloat();
/*  56 */     this.rotateMotion = 20.0F * (this.field_187136_p.nextFloat() - 0.5F);
/*  57 */     this.petalType = SakuraLeave.SakuraType.GREEN;
/*  58 */     float c = 1.0F - this.field_187136_p.nextFloat() * 0.3F;
/*  59 */     func_70538_b(1.0F, c, c);
/*     */     
/*  61 */     this.field_70545_g = 1.0F - (this.field_187136_p.nextFloat() - 0.2F) * 0.6F;
/*  62 */     this.moveResistance = 1.0F - this.field_187136_p.nextFloat() * 0.6F;
/*     */     
/*  64 */     func_189213_a();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PetalParticle setPetal(SakuraLeave.SakuraType type) {
/*  75 */     this.petalType = type;
/*  76 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_189213_a() {
/*  81 */     this.field_187123_c = this.field_187126_f;
/*  82 */     this.field_187124_d = this.field_187127_g;
/*  83 */     this.field_187125_e = this.field_187128_h;
/*  84 */     this.prevYaw = this.yaw;
/*  85 */     if (this.field_70546_d++ >= this.field_70547_e) {
/*  86 */       func_187112_i();
/*     */     } else {
/*  88 */       if (!this.onWater && isInWater()) {
/*  89 */         this.onWater = true;
/*  90 */         this.rotateMotion = 0.0F;
/*     */       } 
/*  92 */       this.field_187130_j -= 0.004D * this.petalType.MASS * this.field_70545_g;
/*     */       
/*  94 */       func_187110_a(this.field_187129_i, this.field_187130_j, this.field_187131_k);
/*     */       
/*  96 */       this.field_187129_i *= 0.9599999785423279D * this.moveResistance;
/*  97 */       this.field_187130_j *= 0.9599999785423279D;
/*  98 */       this.field_187131_k *= 0.9599999785423279D * this.moveResistance;
/*  99 */       this.yaw += this.rotateMotion;
/* 100 */       if (this.field_187124_d == this.field_187127_g) {
/* 101 */         this.field_187132_l = true;
/* 102 */         this.rotateMotion = 0.0F;
/* 103 */         this.field_70546_d++;
/*     */       } 
/* 105 */       if (this.field_187132_l) {
/* 106 */         this.field_187129_i *= 0.8999999761581421D - (this.petalType.MASS * 0.2F);
/* 107 */         this.field_187131_k *= 0.8999999761581421D - (this.petalType.MASS * 0.2F);
/*     */       }
/* 109 */       else if (this.onWater) {
/* 110 */         waterMove();
/*     */       } else {
/* 112 */         windMove();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   private boolean isInWater() {
/* 119 */     if (this.field_187122_b.func_72953_d(func_187116_l())) {
/* 120 */       BlockPos blockpos = new BlockPos(this.field_187126_f, this.field_187127_g, this.field_187128_h);
/* 121 */       IFluidState ifluidstate = this.field_187122_b.func_204610_c(blockpos);
/*     */       
/* 123 */       VoxelShape box = ifluidstate.func_215676_d((IBlockReader)this.field_187122_b, blockpos);
/* 124 */       if (!box.func_197766_b()) {
/* 125 */         AxisAlignedBB aabb = ifluidstate.func_215676_d((IBlockReader)this.field_187122_b, blockpos).func_197752_a().func_186670_a(blockpos).func_72317_d(0.0D, 0.1D, 0.0D);
/* 126 */         return func_187116_l().func_72326_a(aabb);
/*     */       } 
/*     */     } 
/* 129 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   private void waterMove() {
/* 134 */     BlockPos blockpos = new BlockPos(this.field_187126_f, this.field_187127_g, this.field_187128_h);
/* 135 */     IFluidState ifluidstate = this.field_187122_b.func_204610_c(blockpos);
/* 136 */     VoxelShape box = ifluidstate.func_215676_d((IBlockReader)this.field_187122_b, blockpos);
/* 137 */     if (!box.func_197766_b()) {
/* 138 */       AxisAlignedBB aabb = ifluidstate.func_215676_d((IBlockReader)this.field_187122_b, blockpos).func_197752_a().func_186670_a(blockpos).func_72317_d(0.0D, 0.1D, 0.0D);
/* 139 */       if (func_187116_l().func_72326_a(aabb)) {
/* 140 */         Vec3d vec = ifluidstate.func_215673_c((IBlockReader)this.field_187122_b, blockpos).func_186678_a(0.1D);
/* 141 */         this.field_187129_i = vec.field_72450_a;
/* 142 */         this.field_187127_g = aabb.field_72337_e;
/* 143 */         this.field_187131_k = vec.field_72449_c;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   public boolean isInFluid(Tag<Fluid> p_213290_1_) {
/* 149 */     BlockPos blockpos = new BlockPos(this.field_187126_f, this.field_187127_g, this.field_187128_h);
/* 150 */     if (!this.field_187122_b.func_217354_b(blockpos.func_177958_n() >> 4, blockpos.func_177952_p() >> 4)) {
/* 151 */       return false;
/*     */     }
/* 153 */     this.field_187122_b.func_72953_d(func_187116_l());
/* 154 */     IFluidState ifluidstate = this.field_187122_b.func_204610_c(blockpos);
/* 155 */     return ifluidstate.getFluidState().func_206886_c().isAABBInsideLiquid(ifluidstate, (IWorldReader)this.field_187122_b, blockpos, func_187116_l()).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   void windMove() {
/* 160 */     this.field_187129_i += WindManager.getMotionX();
/* 161 */     this.field_187130_j += WindManager.getMotionY();
/* 162 */     this.field_187131_k += WindManager.getMotionZ();
/*     */   }
/*     */ 
/*     */   public int getTextuerID() {
/* 166 */     return this.petalType.ID;
/*     */   }
/*     */ 
/*     */ 
/*     */   public IParticleRenderType func_217558_b() {
/* 171 */     return PETAL;
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_180434_a(BufferBuilder buffer, ActiveRenderInfo entityIn, float partialTicks, float rotationX, float rotationZ, float rotationYZ, float rotationXY, float rotationXZ) {
/* 176 */     float partialPitch = (float)MathHelper.func_219803_d(partialTicks, this.prevPitch, this.pitch);
/* 177 */     float partialYaw = (float)MathHelper.func_219803_d(partialTicks, this.prevYaw, this.yaw);
/* 178 */     rotationX = MathHelper.func_76134_b(partialYaw * 0.017453292F);
/* 179 */     rotationYZ = MathHelper.func_76126_a(partialYaw * 0.017453292F);
/* 180 */     rotationXY = -rotationYZ * MathHelper.func_76126_a(partialPitch * 0.017453292F);
/* 181 */     rotationXZ = rotationX * MathHelper.func_76126_a(partialPitch * 0.017453292F);
/* 182 */     rotationZ = MathHelper.func_76134_b(partialPitch * 0.017453292F);
/* 183 */     float minU = 0.15625F * getTextuerID();
/* 184 */     float maxU = minU + 0.15625F;
/* 185 */     float minV = 0.3125F * (getTextuerID() / 6);
/* 186 */     float maxV = minV + 0.3125F;
/* 187 */     float x = (float)(MathHelper.func_219803_d(partialTicks, this.field_187123_c, this.field_187126_f) - field_70556_an);
/* 188 */     float y = (float)(MathHelper.func_219803_d(partialTicks, this.field_187124_d, this.field_187127_g) - field_70554_ao);
/* 189 */     float z = (float)(MathHelper.func_219803_d(partialTicks, this.field_187125_e, this.field_187128_h) - field_70555_ap);
/* 190 */     Vec3d[] avec3d = { new Vec3d((-rotationX * this.scale - rotationXY * this.scale), (-rotationZ * this.scale), (-rotationYZ * this.scale - rotationXZ * this.scale)), new Vec3d((-rotationX * this.scale + rotationXY * this.scale), (rotationZ * this.scale), (-rotationYZ * this.scale + rotationXZ * this.scale)), new Vec3d((rotationX * this.scale + rotationXY * this.scale), (rotationZ * this.scale), (rotationYZ * this.scale + rotationXZ * this.scale)), new Vec3d((rotationX * this.scale - rotationXY * this.scale), (-rotationZ * this.scale), (rotationYZ * this.scale - rotationXZ * this.scale)) };
/*     */     
/* 192 */     int i = func_189214_a(partialTicks);
/* 193 */     int j = i >> 16 & 0xFFFF;
/* 194 */     int k = i & 0xFFFF;
/* 195 */     buffer.func_181662_b(x + (avec3d[0]).field_72450_a, y + (avec3d[0]).field_72448_b, z + (avec3d[0]).field_72449_c).func_187315_a(maxU, maxV).func_181666_a(this.field_70552_h, this.field_70553_i, this.field_70551_j, this.field_82339_as).func_187314_a(j, k).func_181675_d();
/* 196 */     buffer.func_181662_b(x + (avec3d[1]).field_72450_a, y + (avec3d[1]).field_72448_b, z + (avec3d[1]).field_72449_c).func_187315_a(maxU, minV).func_181666_a(this.field_70552_h, this.field_70553_i, this.field_70551_j, this.field_82339_as).func_187314_a(j, k).func_181675_d();
/* 197 */     buffer.func_181662_b(x + (avec3d[2]).field_72450_a, y + (avec3d[2]).field_72448_b, z + (avec3d[2]).field_72449_c).func_187315_a(minU, minV).func_181666_a(this.field_70552_h, this.field_70553_i, this.field_70551_j, this.field_82339_as).func_187314_a(j, k).func_181675_d();
/* 198 */     buffer.func_181662_b(x + (avec3d[3]).field_72450_a, y + (avec3d[3]).field_72448_b, z + (avec3d[3]).field_72449_c).func_187315_a(minU, maxV).func_181666_a(this.field_70552_h, this.field_70553_i, this.field_70551_j, this.field_82339_as).func_187314_a(j, k).func_181675_d();
/*     */   }
/*     */ 
/*     */ 
/* 202 */   static final IParticleRenderType PETAL = new ParticleRenderType();
/*     */ 
/*     */   static class ParticleRenderType implements IParticleRenderType {
/* 205 */     static final ResourceLocation LOCATION = new ResourceLocation("meshi", "textures/entitys/petal.png");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void func_217600_a(BufferBuilder buffer, TextureManager textureManager) {
/* 212 */       RenderHelper.func_74518_a();
/* 213 */       GlStateManager.disableBlend();
/* 214 */       GlStateManager.depthMask(true);
/* 215 */       this; textureManager.func_110577_a(LOCATION);
/* 216 */       buffer.func_181668_a(7, DefaultVertexFormats.field_181704_d);
/*     */     }
/*     */ 
/*     */ 
/*     */     public void func_217599_a(Tessellator tessellator) {
/* 221 */       tessellator.func_78381_a();
/*     */     }
/*     */ 
/*     */ 
/*     */     public String toString() {
/* 226 */       return "PETAL";
/*     */     }
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 18 ms
	
*/