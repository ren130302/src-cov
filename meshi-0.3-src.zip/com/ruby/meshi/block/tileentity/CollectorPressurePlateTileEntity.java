/*     */ package com.ruby.meshi.block.tileentity;
/*     */ 
/*     */ import com.ruby.meshi.block.CollectionAndDeliveryBase;
/*     */ import com.ruby.meshi.common.inventory.CollectorPressurePlateContainer;
/*     */ import com.ruby.meshi.init.HiganTileEntityType;
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.player.PlayerEntity;
/*     */ import net.minecraft.entity.player.PlayerInventory;
/*     */ import net.minecraft.inventory.ItemStackHelper;
/*     */ import net.minecraft.inventory.container.Container;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.CompoundNBT;
/*     */ import net.minecraft.network.NetworkManager;
/*     */ import net.minecraft.network.play.server.SUpdateTileEntityPacket;
/*     */ import net.minecraft.state.IProperty;
/*     */ import net.minecraft.tileentity.LockableTileEntity;
/*     */ import net.minecraft.util.NonNullList;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TranslationTextComponent;
/*     */ 
/*     */ public class CollectorPressurePlateTileEntity
/*     */   extends LockableTileEntity {
/*     */   public static final byte INV_SIZE = 10;
/*     */   private NonNullList<ItemStack> chestContents;
/*     */   
/*     */   public CollectorPressurePlateTileEntity() {
/*  27 */     super(HiganTileEntityType.COLLECTOR_PLATE);
/*  28 */     this.chestContents = NonNullList.func_191197_a(10, ItemStack.field_190927_a);
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean isForce() {
/*  33 */     return ((Boolean)func_195044_w().func_177229_b((IProperty)CollectionAndDeliveryBase.FORCE)).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_70296_d() {
/*  38 */     super.func_70296_d();
/*  39 */     func_145831_w().func_184138_a(func_174877_v(), func_195044_w(), func_195044_w(), 3);
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_94041_b(int index, ItemStack stack) {
/*  44 */     ItemStack copyStack = stack.func_77946_l();
/*  45 */     copyStack.func_190920_e(1);
/*  46 */     this.chestContents.set(index, copyStack);
/*  47 */     func_70296_d();
/*  48 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   public int func_70302_i_() {
/*  53 */     return 10;
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_191420_l() {
/*  58 */     for (ItemStack itemstack : this.chestContents) {
/*  59 */       if (!itemstack.func_190926_b()) {
/*  60 */         return false;
/*     */       }
/*     */     } 
/*     */     
/*  64 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   public ItemStack func_70301_a(int index) {
/*  69 */     return (ItemStack)this.chestContents.get(index);
/*     */   }
/*     */ 
/*     */ 
/*     */   public ItemStack func_70298_a(int index, int count) {
/*  74 */     return func_70304_b(index);
/*     */   }
/*     */ 
/*     */ 
/*     */   public ItemStack func_70304_b(int index) {
/*  79 */     ItemStack stack = ItemStackHelper.func_188383_a((List)this.chestContents, index);
/*  80 */     if (!stack.func_190926_b()) {
/*  81 */       func_70296_d();
/*     */     }
/*  83 */     return ItemStack.field_190927_a;
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_70299_a(int index, ItemStack stack) {
/*  88 */     this.chestContents.set(index, stack.func_77946_l());
/*  89 */     func_70296_d();
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_70300_a(PlayerEntity player) {
/*  94 */     if (this.field_145850_b.func_175625_s(this.field_174879_c) != this) {
/*  95 */       return false;
/*     */     }
/*  97 */     return (player.func_70092_e(this.field_174879_c.func_177958_n() + 0.5D, this.field_174879_c.func_177956_o() + 0.5D, this.field_174879_c.func_177952_p() + 0.5D) <= 64.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   public void func_174888_l() {
/* 103 */     this.chestContents.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */   protected ITextComponent func_213907_g() {
/* 108 */     return (ITextComponent)new TranslationTextComponent(String.join(".", new CharSequence[] { "container", "meshi", func_195044_w().func_177230_c().getRegistryName().func_110623_a() }), new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */   protected Container func_213906_a(int windowId, PlayerInventory inventory) {
/* 113 */     return new CollectorPressurePlateContainer(windowId, inventory, this);
/*     */   }
/*     */ 
/*     */   public ItemStack getDisplayItem() {
/* 117 */     return (ItemStack)this.chestContents.get(0);
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_145839_a(CompoundNBT compound) {
/* 122 */     super.func_145839_a(compound);
/* 123 */     readContents(compound);
/*     */   }
/*     */ 
/*     */   private void readContents(CompoundNBT compound) {
/* 127 */     this.chestContents = NonNullList.func_191197_a(func_70302_i_(), ItemStack.field_190927_a);
/* 128 */     ItemStackHelper.func_191283_b(compound, this.chestContents);
/*     */   }
/*     */ 
/*     */ 
/*     */   public CompoundNBT func_189515_b(CompoundNBT compound) {
/* 133 */     super.func_189515_b(compound);
/* 134 */     writeContents(compound);
/* 135 */     return compound;
/*     */   }
/*     */ 
/*     */   private CompoundNBT writeContents(CompoundNBT compound) {
/* 139 */     ItemStackHelper.func_191282_a(compound, this.chestContents);
/* 140 */     return compound;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleUpdateTag(CompoundNBT tag) {
/* 147 */     super.handleUpdateTag(tag);
/* 148 */     readContents(tag);
/*     */   }
/*     */ 
/*     */ 
/*     */   public CompoundNBT func_189517_E_() {
/* 153 */     CompoundNBT tag = super.func_189517_E_();
/* 154 */     writeContents(tag);
/* 155 */     return tag;
/*     */   }
/*     */ 
/*     */ 
/*     */   public void onDataPacket(NetworkManager net, SUpdateTileEntityPacket pkt) {
/* 160 */     readContents(pkt.func_148857_g());
/*     */   }
/*     */ 
/*     */ 
/*     */   public SUpdateTileEntityPacket func_189518_D_() {
/* 165 */     CompoundNBT var1 = new CompoundNBT();
/* 166 */     writeContents(var1);
/* 167 */     return new SUpdateTileEntityPacket(func_174877_v(), 0, var1);
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 11 ms
	
*/