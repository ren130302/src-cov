package com.ruby.meshi.common;

public class HiganTags {
}