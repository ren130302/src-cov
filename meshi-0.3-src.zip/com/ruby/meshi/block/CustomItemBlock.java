/*    */ package com.ruby.meshi.block;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.item.BlockItem;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.Items;
/*    */ 
/*    */ public interface CustomItemBlock {
/*  9 */   public static final Item EMPTY = Items.field_190931_a;
/*    */ 
/*    */   default Item.Properties getProperty(Item.Properties prop) {
/* 12 */     return prop;
/*    */   }
/*    */ 
/*    */   default Item getBlockItem(Block block, Item.Properties prop) {
/* 16 */     return (Item)new BlockItem(block, getProperty(prop));
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 1 ms
	
*/