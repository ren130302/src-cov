/*     */ package com.ruby.meshi.common.inventory;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.ruby.meshi.block.tileentity.MillstoneTileEntity;
/*     */ import com.ruby.meshi.client.gui.recipebook.HiganRecipeBookCategories;
/*     */ import com.ruby.meshi.common.inventory.slot.NonInsertSlot;
/*     */ import com.ruby.meshi.crafting.ServerRecipePlacerGrind;
/*     */ import com.ruby.meshi.init.HiganContainerType;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.util.RecipeBookCategories;
/*     */ import net.minecraft.entity.player.PlayerEntity;
/*     */ import net.minecraft.entity.player.PlayerInventory;
/*     */ import net.minecraft.entity.player.ServerPlayerEntity;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.IRecipeHelperPopulator;
/*     */ import net.minecraft.inventory.Inventory;
/*     */ import net.minecraft.inventory.container.ContainerType;
/*     */ import net.minecraft.inventory.container.RecipeBookContainer;
/*     */ import net.minecraft.inventory.container.Slot;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.crafting.IRecipe;
/*     */ import net.minecraft.item.crafting.RecipeItemHelper;
/*     */ import net.minecraft.util.IIntArray;
/*     */ import net.minecraft.util.IntArray;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class MillstoneContainer
/*     */   extends RecipeBookContainer<IInventory>
/*     */ {
/*     */   private IInventory inventory;
/*     */   private IntArray tracker;
/*     */   private MillstoneTileEntity tile;
/*     */   private World world;
/*     */   
/*     */   public MillstoneContainer(int windowId, PlayerInventory playerInventory) {
/*  36 */     this(HiganContainerType.MILLSTONE, windowId, playerInventory, (IInventory)new Inventory(3));
/*     */   }
/*     */ 
/*     */   public MillstoneContainer(int windowId, PlayerInventory playerInventory, MillstoneTileEntity inventory, IntArray progress) {
/*  40 */     this(HiganContainerType.MILLSTONE, windowId, playerInventory, (IInventory)inventory);
/*  41 */     this.tile = inventory;
/*     */   }
/*     */ 
/*     */   public MillstoneContainer(ContainerType<?> type, int id, PlayerInventory playerInventory, IInventory inventory) {
/*  45 */     super(type, id);
/*  46 */     this.inventory = inventory;
/*  47 */     inventory.func_174889_b(playerInventory.field_70458_d);
/*  48 */     this.tracker = new IntArray(2);
/*  49 */     func_216961_a((IIntArray)this.tracker);
/*  50 */     this.world = playerInventory.field_70458_d.field_70170_p;
/*  51 */     func_216959_a((IIntArray)this.tracker, 2);
/*     */     
/*  53 */     func_75146_a(new Slot(inventory, 0, 80, 9));
/*  54 */     func_75146_a(new NonInsertSlot(inventory, 1, 58, 57));
/*  55 */     func_75146_a(new NonInsertSlot(inventory, 2, 102, 57));
/*     */     
/*     */     int i;
/*  58 */     for (i = 0; i < 3; i++) {
/*  59 */       for (int j = 0; j < 9; j++) {
/*  60 */         func_75146_a(new Slot((IInventory)playerInventory, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
/*     */       }
/*     */     } 
/*     */     
/*  64 */     for (i = 0; i < 9; i++) {
/*  65 */       func_75146_a(new Slot((IInventory)playerInventory, i, 8 + i * 18, 142));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_75134_a(PlayerEntity playerIn) {
/*  71 */     super.func_75134_a(playerIn);
/*  72 */     this.inventory.func_174886_c(playerIn);
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_75145_c(PlayerEntity playerIn) {
/*  77 */     return this.inventory.func_70300_a(playerIn);
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_75142_b() {
/*  82 */     super.func_75142_b();
/*  83 */     if (this.tile != null) {
/*  84 */       this.tracker.func_221477_a(0, this.tile.getProgress());
/*  85 */       this.tracker.func_221477_a(1, this.tile.getGrindTime());
/*     */     } 
/*     */   }
/*     */ 
/*     */   public int getProgress() {
/*  90 */     return this.tracker.func_221476_a(0);
/*     */   }
/*     */ 
/*     */   public int getGrindtime() {
/*  94 */     return this.tracker.func_221476_a(1);
/*     */   }
/*     */ 
/*     */ 
/*     */   public ItemStack func_82846_b(PlayerEntity par1EntityPlayer, int par2) {
/*  99 */     ItemStack itemstack = ItemStack.field_190927_a;
/* 100 */     Slot slot = this.field_75151_b.get(par2);
/*     */     
/* 102 */     if (slot != null && slot.func_75216_d()) {
/* 103 */       ItemStack itemstack1 = slot.func_75211_c();
/* 104 */       itemstack = itemstack1.func_77946_l();
/*     */       
/* 106 */       if (par2 == 1 || par2 == 2) {
/* 107 */         if (!func_75135_a(itemstack1, 3, 39, true)) {
/* 108 */           return ItemStack.field_190927_a;
/*     */         }
/*     */         
/* 111 */         slot.func_75220_a(itemstack1, itemstack);
/* 112 */       } else if (par2 != 0) {
/* 113 */         if (par2 >= 3 && par2 < 30) {
/* 114 */           if (!func_75135_a(itemstack1, 30, 39, false)) {
/* 115 */             return ItemStack.field_190927_a;
/*     */           }
/* 117 */         } else if (par2 >= 30 && par2 < 39 && !func_75135_a(itemstack1, 3, 30, false)) {
/* 118 */           return ItemStack.field_190927_a;
/*     */         } 
/* 120 */       } else if (!func_75135_a(itemstack1, 3, 39, false)) {
/* 121 */         return ItemStack.field_190927_a;
/*     */       } 
/*     */       
/* 124 */       if (itemstack1.func_190916_E() == 0) {
/* 125 */         slot.func_75215_d(ItemStack.field_190927_a);
/*     */       } else {
/* 127 */         slot.func_75218_e();
/*     */       } 
/*     */       
/* 130 */       if (itemstack1.func_190916_E() == itemstack.func_190916_E()) {
/* 131 */         return ItemStack.field_190927_a;
/*     */       }
/*     */       
/* 134 */       slot.func_190901_a(par1EntityPlayer, itemstack1);
/*     */     } 
/*     */     
/* 137 */     return itemstack;
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_201771_a(RecipeItemHelper helper) {
/* 142 */     if (this.inventory instanceof IRecipeHelperPopulator) {
/* 143 */       ((IRecipeHelperPopulator)this.inventory).func_194018_a(helper);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_201768_e() {
/* 149 */     this.inventory.func_174888_l();
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_217056_a(boolean p_217056_1_, IRecipe<?> recipe, ServerPlayerEntity player) {
/* 154 */     (new ServerRecipePlacerGrind<>(this, recipe)).func_194327_a(player, recipe, p_217056_1_);
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_201769_a(IRecipe<? super IInventory> recipeIn) {
/* 159 */     return recipeIn.func_77569_a(this.inventory, this.world);
/*     */   }
/*     */ 
/*     */ 
/*     */   public int func_201767_f() {
/* 164 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   public int func_201770_g() {
/* 169 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   public int func_201772_h() {
/* 174 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   public int func_203721_h() {
/* 179 */     return 3;
/*     */   }
/*     */ 
/*     */ 
/*     */   public List<RecipeBookCategories> getRecipeBookCategories() {
/* 184 */     return Lists.newArrayList((Object[])new RecipeBookCategories[] { HiganRecipeBookCategories.GRIND });
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 12 ms
	
*/