/*    */ package com.ruby.meshi.item;
/*    */ 
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.PlayerEntity;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ItemMagnet
/*    */   extends Item
/*    */   implements Accessory
/*    */ {
/*    */   public ItemMagnet(Item.Properties properties) {
/* 16 */     super(properties);
/*    */   }
/*    */ 
/*    */ 
/*    */   public void func_77663_a(ItemStack stack, World world, Entity entity, int itemSlot, boolean isSelected) {
/* 21 */     if (!world.field_72995_K && (world.func_72912_H().func_82573_f() & 0x7L) == 0L && 
/* 22 */       entity instanceof PlayerEntity) {
/* 23 */       for (Entity e : world.func_175674_a(entity, entity.func_174813_aQ().func_72314_b(5.0D, 2.0D, 5.0D), e -> (e instanceof net.minecraft.entity.item.ItemEntity || e instanceof net.minecraft.entity.projectile.ThrowableEntity || e instanceof net.minecraft.entity.projectile.AbstractArrowEntity || e instanceof net.minecraft.entity.item.ExperienceOrbEntity))) {
/* 24 */         if (e.func_70089_S()) {
/* 25 */           e.func_70100_b_((PlayerEntity)entity);
/*    */         }
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   public void playerPostTick(World world, PlayerEntity player, ItemStack stack) {
/* 33 */     if (!world.field_72995_K && (world.func_72912_H().func_82573_f() & 0x7L) == 0L)
/* 34 */       for (Entity e : world.func_175674_a((Entity)player, player.func_174813_aQ().func_72314_b(5.0D, 2.0D, 5.0D), e -> (e instanceof net.minecraft.entity.item.ItemEntity || e instanceof net.minecraft.entity.projectile.ThrowableEntity || e instanceof net.minecraft.entity.projectile.AbstractArrowEntity || e instanceof net.minecraft.entity.item.ExperienceOrbEntity))) {
/* 35 */         if (e.func_70089_S())
/* 36 */           e.func_70100_b_(player); 
/*    */       }  
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 3 ms
	
*/