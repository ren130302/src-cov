/*    */ package com.ruby.meshi.client.renderer.animation;
/*    */ 
/*    */ import com.google.common.collect.Lists;
/*    */ import java.util.List;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.util.Direction;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnimationSet
/*    */ {
/*    */   public static List<EntityModelAnimation> createSwingHead(Direction direction, boolean hand) {
/* 14 */     List<EntityModelAnimation> list = Lists.newArrayList();
/* 15 */     EntityModelAnimation head = new SwingHead(direction);
/* 16 */     list.add(head);
/* 17 */     if (hand) {
/* 18 */       list.add((new ViewHand(direction)).setParent(head));
/*    */     }
/* 20 */     return list;
/*    */   }
/*    */ 
/*    */   public static List<EntityModelAnimation> createWatchHead(Direction direction, BlockPos pos, Entity entity, boolean hand) {
/* 24 */     List<EntityModelAnimation> list = Lists.newArrayList();
/* 25 */     EntityModelAnimation head = (new WatchEntity(direction, pos)).setTarget(entity);
/* 26 */     list.add(head);
/* 27 */     if (hand) {
/* 28 */       list.add((new ViewHand(direction)).setParent(head));
/*    */     }
/* 30 */     return list;
/*    */   }
/*    */ 
/*    */   public static List<EntityModelAnimation> createTail(Direction direction) {
/* 34 */     List<EntityModelAnimation> list = Lists.newArrayList();
/* 35 */     list.add(new SwingTail(direction));
/* 36 */     return list;
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 3 ms
	
*/