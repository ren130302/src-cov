/*     */ package com.ruby.meshi.crafting;
/*     */ 
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonSyntaxException;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.crafting.IRecipe;
/*     */ import net.minecraft.item.crafting.IRecipeSerializer;
/*     */ import net.minecraft.item.crafting.IRecipeType;
/*     */ import net.minecraft.item.crafting.Ingredient;
/*     */ import net.minecraft.item.crafting.ShapedRecipe;
/*     */ import net.minecraft.network.PacketBuffer;
/*     */ import net.minecraft.util.IItemProvider;
/*     */ import net.minecraft.util.JSONUtils;
/*     */ import net.minecraft.util.NonNullList;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.registry.Registry;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.registries.ForgeRegistryEntry;
/*     */ 
/*     */ public class GrindRecipe
/*     */   implements IRecipe<IInventory>, NonLockRecipe {
/*     */   static {
/*  25 */     final ResourceLocation key = HiganRecipeSerializer.GRIND.getRegistryName();
/*  26 */     TYPE = (IRecipeType<GrindRecipe>)Registry.func_218322_a(Registry.field_218367_H, key, new IRecipeType<GrindRecipe>()
/*     */         {
/*     */           public String toString() {
/*  29 */             return key.toString();
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GrindRecipe(ResourceLocation recipeId, String group, Ingredient ingredient, int reqcount, ItemStack result, ItemStack bonus, float weight, int time) {
/*  44 */     this.id = recipeId;
/*  45 */     this.group = group;
/*  46 */     this.ingredient = ingredient;
/*  47 */     this.reqcount = reqcount;
/*  48 */     this.result = result;
/*  49 */     this.bonus = bonus;
/*  50 */     this.bonuswegiht = weight;
/*  51 */     this.grindingTime = time;
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_77569_a(IInventory inv, World worldIn) {
/*  56 */     return this.ingredient.test(inv.func_70301_a(0));
/*     */   }
/*     */ 
/*     */ 
/*     */   public ItemStack func_77572_b(IInventory inv) {
/*  61 */     return this.result.func_77946_l();
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_194133_a(int width, int height) {
/*  66 */     return (width == 1 && height == 1);
/*     */   }
/*     */ 
/*     */ 
/*     */   public ItemStack func_77571_b() {
/*  71 */     return this.result.func_77946_l();
/*     */   }
/*     */ 
/*     */ 
/*     */   public ResourceLocation func_199560_c() {
/*  76 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */   public IRecipeSerializer<?> func_199559_b() {
/*  81 */     return HiganRecipeSerializer.GRIND;
/*     */   }
/*     */ 
/*     */ 
/*     */   public IRecipeType<?> func_222127_g() {
/*  86 */     return TYPE;
/*     */   }
/*     */ 
/*     */ 
/*     */   public String func_193358_e() {
/*  91 */     return this.group;
/*     */   }
/*     */ 
/*     */ 
/*     */   public NonNullList<Ingredient> func_192400_c() {
/*  96 */     return NonNullList.func_193580_a(Ingredient.field_193370_a, (Object[])new Ingredient[] { this.ingredient });
/*     */   }
/*     */ 
/*     */   public int getRequestCount() {
/* 100 */     return this.reqcount;
/*     */   }
/*     */ 
/*     */   public int getGrindingTime() {
/* 104 */     return this.grindingTime;
/*     */   }
/*     */ 
/*     */   public ItemStack getResult() {
/* 108 */     return this.result.func_77946_l();
/*     */   }
/*     */ 
/*     */   public ItemStack getBonus() {
/* 112 */     return this.bonus.func_77946_l();
/*     */   }
/*     */ 
/*     */   public float getBonusWeight() {
/* 116 */     return this.bonuswegiht;
/*     */   }
/*     */ 
/*     */   public static class Serializer
/*     */     extends ForgeRegistryEntry<IRecipeSerializer<?>> implements IRecipeSerializer<GrindRecipe> {
/*     */     public GrindRecipe read(ResourceLocation recipeId, JsonObject json) {
/*     */       ItemStack result;
/* 123 */       String s = JSONUtils.func_151219_a(json, "group", "");
/* 124 */       JsonElement jsonelement = JSONUtils.func_151202_d(json, "ingredient") ? (JsonElement)JSONUtils.func_151214_t(json, "ingredient") : (JsonElement)JSONUtils.func_152754_s(json, "ingredient");
/* 125 */       Ingredient ingredient = Ingredient.func_199802_a(jsonelement);
/* 126 */       if (!json.has("result")) {
/* 127 */         throw new JsonSyntaxException("Missing result, expected to find a string or object");
/*     */       }
/*     */       
/* 130 */       if (json.get("result").isJsonObject()) {
/* 131 */         result = ShapedRecipe.func_199798_a(JSONUtils.func_152754_s(json, "result"));
/*     */       } else {
/* 133 */         String s1 = JSONUtils.func_151200_h(json, "result");
/* 134 */         ResourceLocation resourcelocation = new ResourceLocation(s1);
/* 135 */         result = new ItemStack((IItemProvider)Registry.field_212630_s.func_218349_b(resourcelocation).orElseThrow(() -> new IllegalStateException("Item: " + s1 + " does not exist")));
/*     */       } 
/*     */ 
/*     */       
/* 139 */       int reqcount = JSONUtils.func_151208_a(json, "requestcount", 1);
/* 140 */       ItemStack bonus = ItemStack.field_190927_a;
/* 141 */       if (json.has("bonus")) {
/* 142 */         if (json.get("bonus").isJsonObject()) {
/* 143 */           bonus = ShapedRecipe.func_199798_a(JSONUtils.func_152754_s(json, "bonus"));
/*     */         } else {
/* 145 */           String s1 = JSONUtils.func_151200_h(json, "bonus");
/* 146 */           ResourceLocation resourcelocation = new ResourceLocation(s1);
/* 147 */           bonus = new ItemStack((IItemProvider)Registry.field_212630_s.func_218349_b(resourcelocation).orElseThrow(() -> new IllegalStateException("Item: " + s1 + " does not exist")));
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 152 */       float bonuswegiht = JSONUtils.func_151221_a(json, "bonusweight", 0.0F);
/* 153 */       int time = JSONUtils.func_151208_a(json, "grindingtime", 200);
/* 154 */       return new GrindRecipe(recipeId, s, ingredient, reqcount, result, bonus, bonuswegiht, time);
/*     */     }
/*     */ 
/*     */ 
/*     */     public GrindRecipe read(ResourceLocation recipeId, PacketBuffer buffer) {
/* 159 */       String group = buffer.func_150789_c(32767);
/* 160 */       Ingredient ingredient = Ingredient.func_199566_b(buffer);
/* 161 */       int req = buffer.func_150792_a();
/* 162 */       ItemStack result = buffer.func_150791_c();
/* 163 */       ItemStack bonus = buffer.func_150791_c();
/* 164 */       float wegiht = buffer.readFloat();
/* 165 */       int time = buffer.func_150792_a();
/* 166 */       return new GrindRecipe(recipeId, group, ingredient, req, result, bonus, wegiht, time);
/*     */     }
/*     */ 
/*     */ 
/*     */     public void write(PacketBuffer buffer, GrindRecipe recipe) {
/* 171 */       buffer.func_180714_a(recipe.group);
/* 172 */       recipe.ingredient.func_199564_a(buffer);
/* 173 */       buffer.func_150787_b(recipe.reqcount);
/* 174 */       buffer.func_150788_a(recipe.result);
/* 175 */       buffer.func_150788_a(recipe.bonus);
/* 176 */       buffer.writeFloat(recipe.bonuswegiht);
/* 177 */       buffer.func_150787_b(recipe.grindingTime);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   public String toString() {
/* 183 */     return this.result.toString() + this.id.toString();
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 11 ms
	
*/