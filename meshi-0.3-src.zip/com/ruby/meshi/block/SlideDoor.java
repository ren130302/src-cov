/*     */ package com.ruby.meshi.block;
/*     */ 
/*     */ import com.ruby.meshi.block.tileentity.SlideDoorTileEntity;
/*     */ import com.ruby.meshi.client.CreativeTab;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockRenderType;
/*     */ import net.minecraft.block.BlockState;
/*     */ import net.minecraft.block.DoorBlock;
/*     */ import net.minecraft.entity.EntityType;
/*     */ import net.minecraft.entity.player.PlayerEntity;
/*     */ import net.minecraft.item.BlockItemUseContext;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.TallBlockItem;
/*     */ import net.minecraft.state.BooleanProperty;
/*     */ import net.minecraft.state.IProperty;
/*     */ import net.minecraft.state.StateContainer;
/*     */ import net.minecraft.state.properties.DoorHingeSide;
/*     */ import net.minecraft.state.properties.DoubleBlockHalf;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.BlockRenderLayer;
/*     */ import net.minecraft.util.Direction;
/*     */ import net.minecraft.util.Hand;
/*     */ import net.minecraft.util.Mirror;
/*     */ import net.minecraft.util.Rotation;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.BlockRayTraceResult;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.shapes.ISelectionContext;
/*     */ import net.minecraft.util.math.shapes.VoxelShape;
/*     */ import net.minecraft.util.math.shapes.VoxelShapes;
/*     */ import net.minecraft.world.IBlockReader;
/*     */ import net.minecraft.world.IWorld;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class SlideDoor
/*     */   extends DoorBlock implements CustomItemBlock {
/*  37 */   public static final BooleanProperty MIRROR = BooleanProperty.func_177716_a("mirror");
/*  38 */   public static final BooleanProperty MOVED = BooleanProperty.func_177716_a("move");
/*     */ 
/*  40 */   protected static final VoxelShape SOUTH_AABB = Block.func_208617_a(0.0D, 0.0D, 7.0D, 16.0D, 16.0D, 8.0D);
/*  41 */   protected static final VoxelShape NORTH_AABB = Block.func_208617_a(0.0D, 0.0D, 8.0D, 16.0D, 16.0D, 9.0D);
/*  42 */   protected static final VoxelShape WEST_AABB = Block.func_208617_a(8.0D, 0.0D, 0.0D, 9.0D, 16.0D, 16.0D);
/*  43 */   protected static final VoxelShape EAST_AABB = Block.func_208617_a(7.0D, 0.0D, 0.0D, 8.0D, 16.0D, 16.0D);
/*     */ 
/*     */   public SlideDoor(Block.Properties properties) {
/*  46 */     super(properties);
/*  47 */     func_180632_j((BlockState)((BlockState)func_176223_P().func_206870_a((IProperty)MIRROR, Boolean.valueOf(false))).func_206870_a((IProperty)MOVED, Boolean.valueOf(false)));
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean hasTileEntity(BlockState state) {
/*  52 */     return (((Boolean)state.func_177229_b((IProperty)field_176519_b)).booleanValue() || ((Boolean)state.func_177229_b((IProperty)MOVED)).booleanValue());
/*     */   }
/*     */ 
/*     */ 
/*     */   public TileEntity createTileEntity(BlockState state, IBlockReader world) {
/*  57 */     if (hasTileEntity(state)) {
/*  58 */       return new SlideDoorTileEntity();
/*     */     }
/*  60 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   public BlockRenderType func_149645_b(BlockState state) {
/*  65 */     return (((Boolean)state.func_177229_b((IProperty)field_176519_b)).booleanValue() || ((Boolean)state.func_177229_b((IProperty)MOVED)).booleanValue()) ? BlockRenderType.INVISIBLE : super.func_149645_b(state);
/*     */   }
/*     */ 
/*     */ 
/*     */   public VoxelShape func_220053_a(BlockState state, IBlockReader worldIn, BlockPos pos, ISelectionContext context) {
/*  70 */     Direction direction = (Direction)state.func_177229_b((IProperty)field_176520_a);
/*  71 */     switch (direction)
/*     */     
/*     */     { default:
/*  74 */         return EAST_AABB;
/*     */       case SOUTH:
/*  76 */         return SOUTH_AABB;
/*     */       case WEST:
/*  78 */         return WEST_AABB;
/*     */       case NORTH:
/*  80 */         break; }  return NORTH_AABB;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   public VoxelShape func_220071_b(BlockState state, IBlockReader worldIn, BlockPos pos, ISelectionContext context) {
/*  86 */     return ((Boolean)state.func_177229_b((IProperty)field_176519_b)).booleanValue() ? VoxelShapes.func_197880_a() : state.func_196954_c(worldIn, pos);
/*     */   }
/*     */ 
/*     */ 
/*     */   public BlockRenderLayer func_180664_k() {
/*  91 */     return BlockRenderLayer.SOLID;
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_220051_a(BlockState state, World worldIn, BlockPos pos, PlayerEntity player, Hand handIn, BlockRayTraceResult hit) {
/*  96 */     state = (BlockState)state.func_177231_a((IProperty)field_176519_b);
/*  97 */     worldIn.func_180501_a(pos, state, 10);
/*  98 */     onMove(state, worldIn, pos);
/*  99 */     func_196426_b(worldIn, pos, ((Boolean)state.func_177229_b((IProperty)field_176519_b)).booleanValue());
/* 100 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_176512_a(World worldIn, BlockPos pos, boolean open) {
/* 105 */     BlockState blockstate = worldIn.func_180495_p(pos);
/* 106 */     if (blockstate.func_177230_c() == this && ((Boolean)blockstate.func_177229_b((IProperty)field_176519_b)).booleanValue() != open) {
/* 107 */       worldIn.func_180501_a(pos, (BlockState)blockstate.func_206870_a((IProperty)field_176519_b, Boolean.valueOf(open)), 10);
/* 108 */       onMove(blockstate, worldIn, pos);
/* 109 */       func_196426_b(worldIn, pos, open);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_220069_a(BlockState state, World worldIn, BlockPos pos, Block blockIn, BlockPos fromPos, boolean isMoving) {
/* 115 */     boolean flag = (worldIn.func_175640_z(pos) || worldIn.func_175640_z(pos.func_177972_a((state.func_177229_b((IProperty)field_176523_O) == DoubleBlockHalf.LOWER) ? Direction.UP : Direction.DOWN)));
/* 116 */     if (blockIn != this && flag != ((Boolean)state.func_177229_b((IProperty)field_176522_N)).booleanValue()) {
/* 117 */       if (flag != ((Boolean)state.func_177229_b((IProperty)field_176519_b)).booleanValue()) {
/* 118 */         onMove(state, worldIn, pos);
/* 119 */         func_196426_b(worldIn, pos, flag);
/*     */       } 
/* 121 */       worldIn.func_180501_a(pos, (BlockState)((BlockState)state.func_206870_a((IProperty)field_176522_N, Boolean.valueOf(flag))).func_206870_a((IProperty)field_176519_b, Boolean.valueOf(flag)), 2);
/*     */     } 
/*     */   }
/*     */ 
/*     */   void onMove(BlockState state, World worldIn, BlockPos pos) {
/* 126 */     boolean isOpen = ((Boolean)state.func_177229_b((IProperty)field_176519_b)).booleanValue();
/* 127 */     if (isOpen) {
/* 128 */       worldIn.func_175690_a(pos, createTileEntity(state, (IBlockReader)worldIn));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   public BlockState func_196271_a(BlockState stateIn, Direction facing, BlockState facingState, IWorld worldIn, BlockPos currentPos, BlockPos facingPos) {
/* 134 */     return super.func_196271_a(stateIn, facing, facingState, worldIn, currentPos, facingPos);
/*     */   }
/*     */ 
/*     */ 
/*     */   public BlockState func_196258_a(BlockItemUseContext context) {
/* 139 */     BlockPos blockpos = context.func_195995_a();
/* 140 */     if (blockpos.func_177956_o() < 255 && context.func_195991_k().func_180495_p(blockpos.func_177984_a()).func_196953_a(context)) {
/* 141 */       World world = context.func_195991_k();
/* 142 */       boolean flag = (world.func_175640_z(blockpos) || world.func_175640_z(blockpos.func_177984_a()));
/* 143 */       Vec3d vec = context.func_221532_j();
/* 144 */       return (BlockState)((BlockState)((BlockState)((BlockState)((BlockState)((BlockState)func_176223_P().func_206870_a((IProperty)field_176520_a, (Comparable)context.func_195992_f())).func_206870_a((IProperty)field_176521_M, (Comparable)func_208073_b(context))).func_206870_a((IProperty)field_176522_N, Boolean.valueOf(flag))).func_206870_a((IProperty)field_176519_b, Boolean.valueOf(flag))).func_206870_a((IProperty)field_176523_O, (Comparable)DoubleBlockHalf.LOWER)).func_206870_a((IProperty)MIRROR, Boolean.valueOf(isMirrorTextuer(context)));
/*     */     } 
/* 146 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   DoorHingeSide func_208073_b(BlockItemUseContext context) {
/* 151 */     BlockPos blockpos = context.func_195995_a();
/* 152 */     Direction direction = context.func_195992_f();
/* 153 */     int j = direction.func_82601_c();
/* 154 */     int k = direction.func_82599_e();
/* 155 */     Vec3d vec3d = context.func_221532_j();
/* 156 */     double d0 = vec3d.field_72450_a - blockpos.func_177958_n();
/* 157 */     double d1 = vec3d.field_72449_c - blockpos.func_177952_p();
/* 158 */     return ((j >= 0 || d1 >= 0.5D) && (j <= 0 || d1 <= 0.5D) && (k >= 0 || d0 <= 0.5D) && (k <= 0 || d0 >= 0.5D)) ? DoorHingeSide.RIGHT : DoorHingeSide.LEFT;
/*     */   }
/*     */ 
/*     */   boolean isMirrorTextuer(BlockItemUseContext context) {
/* 162 */     BlockPos blockpos = context.func_195995_a();
/* 163 */     World world = context.func_195991_k();
/* 164 */     Direction placerFacing = context.func_195992_f();
/*     */     
/* 166 */     if (context.func_195998_g()) {
/* 167 */       return false;
/*     */     }
/* 169 */     for (Direction dir : Direction.Plane.HORIZONTAL) {
/* 170 */       BlockState state = world.func_180495_p(blockpos.func_177971_a(dir.func_176730_m()));
/*     */       
/* 172 */       if (state.func_177230_c() instanceof SlideDoor) {
/* 173 */         Direction facing = (Direction)state.func_177229_b((IProperty)field_176520_a);
/* 174 */         boolean isMirror = ((Boolean)state.func_177229_b((IProperty)MIRROR)).booleanValue();
/* 175 */         if (facing == placerFacing.func_176734_d() && !isMirror) {
/* 176 */           return true;
/*     */         }
/* 178 */         if (facing == placerFacing && isMirror) {
/* 179 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 183 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void func_196243_a(BlockState state, World worldIn, BlockPos pos, BlockState newState, boolean isMoving) {
/* 192 */     if (state.func_177230_c() != newState.func_177230_c()) {
/* 193 */       super.func_196243_a(state, worldIn, pos, newState, isMoving);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   public BlockState func_185499_a(BlockState state, Rotation rot) {
/* 199 */     if (((Boolean)state.func_177229_b((IProperty)field_176519_b)).booleanValue()) {
/* 200 */       return state;
/*     */     }
/* 202 */     return super.func_185499_a(state, rot);
/*     */   }
/*     */ 
/*     */ 
/*     */   public BlockState func_185471_a(BlockState state, Mirror mirrorIn) {
/* 207 */     if (((Boolean)state.func_177229_b((IProperty)field_176519_b)).booleanValue()) {
/* 208 */       return state;
/*     */     }
/* 210 */     return super.func_185471_a(state, mirrorIn);
/*     */   }
/*     */ 
/*     */ 
/*     */   protected void func_206840_a(StateContainer.Builder<Block, BlockState> builder) {
/* 215 */     super.func_206840_a(builder);
/* 216 */     builder.func_206894_a(new IProperty[] { (IProperty)MIRROR, (IProperty)MOVED });
/*     */   }
/*     */ 
/*     */ 
/*     */   public Item getBlockItem(Block block, Item.Properties prop) {
/* 221 */     return (Item)new TallBlockItem((Block)this, getProperty(prop).func_200916_a(CreativeTab.ITEM_GROUP));
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_200123_i(BlockState state, IBlockReader reader, BlockPos pos) {
/* 226 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_220060_c(BlockState state, IBlockReader worldIn, BlockPos pos) {
/* 231 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_220081_d(BlockState state, IBlockReader worldIn, BlockPos pos) {
/* 236 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_220067_a(BlockState state, IBlockReader worldIn, BlockPos pos, EntityType<?> type) {
/* 241 */     return false;
/*     */   }
/*     */ 
/*     */   public static class LayerCutout extends SlideDoor {
/*     */     public LayerCutout(Block.Properties properties) {
/* 246 */       super(properties);
/*     */     }
/*     */ 
/*     */ 
/*     */     public BlockRenderLayer func_180664_k() {
/* 251 */       return BlockRenderLayer.CUTOUT;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class LayerTranslucent extends SlideDoor {
/*     */     public LayerTranslucent(Block.Properties properties) {
/* 257 */       super(properties);
/*     */     }
/*     */ 
/*     */ 
/*     */     public BlockRenderLayer func_180664_k() {
/* 262 */       return BlockRenderLayer.TRANSLUCENT;
/*     */     }
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 18 ms
	
*/