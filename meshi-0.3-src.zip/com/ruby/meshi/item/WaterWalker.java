/*    */ package com.ruby.meshi.item;
/*    */ 
/*    */ import net.minecraft.block.BlockState;
/*    */ import net.minecraft.entity.player.PlayerEntity;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.tags.FluidTags;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class WaterWalker
/*    */   extends Item implements Accessory {
/*    */   public WaterWalker(Item.Properties properties) {
/* 14 */     super(properties);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   public void playerPostTick(World world, PlayerEntity player, ItemStack stack) {
/* 20 */     BlockState underState = world.func_180495_p(new BlockPos(player.field_70165_t, Math.ceil(player.field_70163_u + (player.func_213322_ci()).field_72448_b) - 0.0625D, player.field_70161_v));
/* 21 */     if (!player.func_70093_af() && world.func_175623_d(new BlockPos(player.field_70165_t, Math.floor(player.field_70163_u), player.field_70161_v)) && underState.func_204520_s().func_206884_a(FluidTags.field_206959_a)) {
/* 22 */       player.func_213293_j((player.func_213322_ci()).field_72450_a, 0.0D, (player.func_213322_ci()).field_72449_c);
/* 23 */       player.field_70122_E = true;
/*    */     } 
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 3 ms
	
*/