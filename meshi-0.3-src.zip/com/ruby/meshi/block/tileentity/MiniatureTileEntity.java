/*     */ package com.ruby.meshi.block.tileentity;
/*     */ 
/*     */ import com.ruby.meshi.block.Miniature;
/*     */ import com.ruby.meshi.init.HiganTileEntityType;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockState;
/*     */ import net.minecraft.block.Blocks;
/*     */ import net.minecraft.client.renderer.BufferBuilder;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.PlayerEntity;
/*     */ import net.minecraft.fluid.Fluid;
/*     */ import net.minecraft.fluid.Fluids;
/*     */ import net.minecraft.fluid.IFluidState;
/*     */ import net.minecraft.item.crafting.RecipeManager;
/*     */ import net.minecraft.nbt.CompoundNBT;
/*     */ import net.minecraft.nbt.INBT;
/*     */ import net.minecraft.nbt.ListNBT;
/*     */ import net.minecraft.nbt.NBTUtil;
/*     */ import net.minecraft.network.NetworkManager;
/*     */ import net.minecraft.network.play.server.SUpdateTileEntityPacket;
/*     */ import net.minecraft.scoreboard.Scoreboard;
/*     */ import net.minecraft.state.IProperty;
/*     */ import net.minecraft.tags.NetworkTagManager;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.Direction;
/*     */ import net.minecraft.util.Rotation;
/*     */ import net.minecraft.util.SoundCategory;
/*     */ import net.minecraft.util.SoundEvent;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.ChunkPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.shapes.VoxelShape;
/*     */ import net.minecraft.world.IEnviromentBlockReader;
/*     */ import net.minecraft.world.ITickList;
/*     */ import net.minecraft.world.IWorld;
/*     */ import net.minecraft.world.LightType;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.biome.Biome;
/*     */ import net.minecraft.world.chunk.AbstractChunkProvider;
/*     */ import net.minecraft.world.chunk.Chunk;
/*     */ import net.minecraft.world.dimension.Dimension;
/*     */ import net.minecraft.world.dimension.DimensionType;
/*     */ import net.minecraft.world.gen.ChunkGenerator;
/*     */ import net.minecraft.world.storage.MapData;
/*     */ 
/*     */ public class MiniatureTileEntity
/*     */   extends TileEntity
/*     */ {
/*  53 */   public static final BlockState EMPTY = Blocks.field_150350_a.func_176223_P();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  65 */   private int innerSize = 8;
/*     */ 
/*  67 */   private final MiniWorld inner = new MiniWorld();
/*     */ 
/*     */   public MiniatureTileEntity() {
/*  70 */     super(HiganTileEntityType.MINIATUE);
/*     */   }
/*     */ 
/*     */ 
/*     */   public void setSize(int size) {
/*  75 */     this.innerSize = size;
/*  76 */     this.inner.setSize(size);
/*     */   }
/*     */ 
/*     */   public int getSize() {
/*  80 */     return this.innerSize;
/*     */   }
/*     */ 
/*     */   public boolean setInnerState(BlockPos pos, BlockState state) {
/*  84 */     boolean isSet = this.inner.func_175656_a(pos, state);
/*  85 */     if (isSet) {
/*  86 */       func_145831_w().func_175656_a(func_174877_v(), (BlockState)func_195044_w().func_206870_a((IProperty)Miniature.ENABLED, Boolean.valueOf(!isInnerEmpty())));
/*  87 */       func_70296_d();
/*     */     } 
/*  89 */     return isSet;
/*     */   }
/*     */ 
/*     */   public boolean isInnerEmpty() {
/*  93 */     return this.inner.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BlockState getInnerState(BlockPos pos) {
/* 100 */     return this.inner.func_180495_p(pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IFluidState getInnerFluidState(BlockPos pos) {
/* 107 */     return this.inner.func_204610_c(pos);
/*     */   }
/*     */ 
/*     */   public World getInnerWorld() {
/* 111 */     return this.inner;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BlockState getInnerState(int x, int y, int z) {
/* 118 */     return this.inner.getInnerBlockState(x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_70296_d() {
/* 123 */     super.func_70296_d();
/* 124 */     removeCache();
/*     */   }
/*     */ 
/*     */   public void removeCache() {
/* 128 */     this.shapeCache = null;
/* 129 */     this.renderSolidCache = null;
/* 130 */     this.renderCache = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_145839_a(CompoundNBT compound) {
/* 135 */     super.func_145839_a(compound);
/* 136 */     readData(compound);
/*     */   }
/*     */ 
/*     */ 
/*     */   public CompoundNBT func_189515_b(CompoundNBT compound) {
/* 141 */     CompoundNBT nbt = super.func_189515_b(compound);
/* 142 */     writeData(nbt);
/* 143 */     return nbt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   public void readData(CompoundNBT nbt) {
/* 149 */     if (nbt.func_74764_b("ntrs")) {
/* 150 */       this.isNoTexResize = nbt.func_74767_n("ntrs");
/*     */     }
/*     */ 
/*     */     
/* 154 */     if (nbt.func_74764_b("size")) {
/* 155 */       this.innerSize = nbt.func_74762_e("size");
/* 156 */       this.inner.setSize(this.innerSize);
/*     */     } 
/* 158 */     this.inner.loadState(nbt);
/* 159 */     removeCache();
/*     */   }
/*     */ 
/*     */   public CompoundNBT writeData(CompoundNBT nbt) {
/* 163 */     this.inner.saveState(nbt);
/* 164 */     nbt.func_74757_a("ntrs", this.isNoTexResize);
/* 165 */     nbt.func_74768_a("size", this.innerSize);
/* 166 */     return nbt;
/*     */   }
/*     */ 
/*     */ 
/*     */   public void handleUpdateTag(CompoundNBT tag) {
/* 171 */     super.handleUpdateTag(tag);
/* 172 */     readData(tag);
/*     */   }
/*     */ 
/*     */ 
/*     */   public CompoundNBT func_189517_E_() {
/* 177 */     CompoundNBT tag = super.func_189517_E_();
/* 178 */     writeData(tag);
/* 179 */     return tag;
/*     */   }
/*     */ 
/*     */ 
/*     */   public void onDataPacket(NetworkManager net, SUpdateTileEntityPacket pkt) {
/* 184 */     readData(pkt.func_148857_g());
/*     */   }
/*     */ 
/*     */ 
/*     */   public SUpdateTileEntityPacket func_189518_D_() {
/* 189 */     CompoundNBT var1 = new CompoundNBT();
/* 190 */     writeData(var1);
/* 191 */     return new SUpdateTileEntityPacket(func_174877_v(), 5, var1);
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_145834_a(World worldIn) {
/* 196 */     super.func_145834_a(worldIn);
/* 197 */     this.inner.isRemote = worldIn.func_201670_d();
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_189667_a(Rotation rotationIn) {
/* 202 */     if (rotationIn == Rotation.CLOCKWISE_90) {
/* 203 */       this.inner.rotateInnerState(false);
/* 204 */     } else if (rotationIn == Rotation.COUNTERCLOCKWISE_90) {
/* 205 */       this.inner.rotateInnerState(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */   public boolean isInInnerRange(int x, int y, int z) {
/* 210 */     return this.inner.hasBlockRange(x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */   public AxisAlignedBB getRenderBoundingBox() {
/* 215 */     return (this.shapeCache != null && !this.shapeCache.func_197766_b()) ? this.shapeCache.func_197752_a().func_186670_a(this.field_174879_c) : super.getRenderBoundingBox();
/*     */   }
/*     */ 
/*     */   public boolean isNoTexResize() {
/* 219 */     return this.isNoTexResize;
/*     */   }
/*     */ 
/*     */   public void setNoTexResize(boolean isNTRS) {
/* 223 */     this.isNoTexResize = isNTRS;
/*     */   }
/*     */ 
/*     */   private class MiniWorld extends World implements IEnviromentBlockReader {
/* 227 */     private BlockState[][][] container = new BlockState[getSize()][getSize()][getSize()];
/*     */ 
/*     */ 
/*     */     public MiniWorld() {
/* 231 */       super(null, new MiniatureTileEntity.DummyDT(MiniatureTileEntity.this), (a, b) -> null, null, false);
/* 232 */       clearContainer();
/*     */     }
/*     */ 
/*     */     void setSize(int size) {
/* 236 */       if (size != this.container.length) {
/* 237 */         this.container = new BlockState[size][size][size];
/* 238 */         clearContainer();
/*     */       } 
/*     */     }
/*     */ 
/*     */     int getSize() {
/* 243 */       return MiniatureTileEntity.this.getSize();
/*     */     }
/*     */ 
/*     */     void clearContainer() {
/* 247 */       for (int i = 0; i < this.container.length; i++) {
/* 248 */         for (int j = 0; j < (this.container[i]).length; j++) {
/* 249 */           for (int k = 0; k < (this.container[i][j]).length; k++) {
/* 250 */             this.container[i][j][k] = MiniatureTileEntity.EMPTY;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void rotateInnerState(boolean isCCW) {
/* 260 */       this.container = rotateClockwise(this.container, isCCW);
/* 261 */       for (int i = 0; i < getSize(); i++) {
/* 262 */         for (int j = 0; j < getSize(); j++) {
/* 263 */           for (int k = 0; k < getSize(); k++) {
/* 264 */             if (this.container[i][j][k] != MiniatureTileEntity.EMPTY) {
/* 265 */               BlockState newState = this.container[i][j][k].func_185907_a(isCCW ? Rotation.COUNTERCLOCKWISE_90 : Rotation.CLOCKWISE_90);
/* 266 */               if (!newState.hasTileEntity()) {
/* 267 */                 this.container[i][j][k] = newState;
/*     */               }
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 273 */       MiniatureTileEntity.this.func_70296_d();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     BlockState[][][] rotateClockwise(BlockState[][][] data, boolean isCCW) {
/* 280 */       int rows = getSize();
/* 281 */       int cols = getSize();
/* 282 */       BlockState[][][] t = new BlockState[getSize()][getSize()][getSize()];
/* 283 */       for (int y = 0; y < getSize(); y++) {
/* 284 */         for (int i = 0; i < rows; i++) {
/* 285 */           for (int j = 0; j < cols; j++) {
/* 286 */             if (!isCCW) {
/* 287 */               t[rows - i - 1][y][j] = data[j][y][i];
/*     */             } else {
/* 289 */               t[j][y][rows - i - 1] = data[i][y][j];
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 294 */       return t;
/*     */     }
/*     */ 
/*     */     public boolean isEmpty() {
/* 298 */       for (int i = 0; i < getSize(); i++) {
/* 299 */         for (int j = 0; j < getSize(); j++) {
/* 300 */           for (int k = 0; k < getSize(); k++) {
/* 301 */             if (this.container[i][j][k] != MiniatureTileEntity.EMPTY) {
/* 302 */               return false;
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/* 307 */       return true;
/*     */     }
/*     */ 
/*     */     public void loadState(CompoundNBT nbt) {
/* 311 */       if (this.container.length != getSize()) {
/* 312 */         setSize(getSize());
/*     */       }
/* 314 */       clearContainer();
/* 315 */       ListNBT nbtList = (ListNBT)nbt.func_74781_a("state");
/* 316 */       for (INBT contents : nbtList) {
/* 317 */         CompoundNBT c = (CompoundNBT)contents;
/* 318 */         BlockPos pos = NBTUtil.func_186861_c(c);
/* 319 */         BlockState state = NBTUtil.func_190008_d(c.func_74775_l("state"));
/* 320 */         if (hasBlockRange(pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p())) {
/* 321 */           this.container[pos.func_177958_n()][pos.func_177956_o()][pos.func_177952_p()] = state;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     public void saveState(CompoundNBT nbt) {
/* 327 */       ListNBT nbtList = new ListNBT();
/* 328 */       for (int i = 0; i < getSize(); i++) {
/* 329 */         for (int j = 0; j < getSize(); j++) {
/* 330 */           for (int k = 0; k < getSize(); k++) {
/* 331 */             if (hasBlockRange(i, j, k) && this.container[i][j][k] != MiniatureTileEntity.EMPTY) {
/* 332 */               CompoundNBT posNBT = NBTUtil.func_186859_a(new BlockPos(i, j, k));
/* 333 */               CompoundNBT stateNBT = NBTUtil.func_190009_a(this.container[i][j][k]);
/* 334 */               posNBT.func_218657_a("state", (INBT)stateNBT);
/* 335 */               nbtList.add(posNBT);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 340 */       nbt.func_218657_a("state", (INBT)nbtList);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     @Deprecated
/*     */     public TileEntity func_175625_s(BlockPos pos) {
/* 349 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     public boolean func_175656_a(BlockPos pos, BlockState state) {
/* 354 */       if (!hasBlockRange(pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p())) {
/* 355 */         Direction outFace = getOutFace(pos);
/* 356 */         BlockPos outerOffsetPos = getThisBlockPosition().func_177972_a(outFace);
/* 357 */         BlockState outerState = getOuterBlockState(outerOffsetPos);
/* 358 */         if (outerState.func_177230_c() instanceof Miniature) {
/* 359 */           TileEntity te = getOuterWorld().func_175625_s(outerOffsetPos);
/* 360 */           if (te != null && te instanceof MiniatureTileEntity && (
/* 361 */             (MiniatureTileEntity)te).getSize() == getSize()) {
/* 362 */             boolean isUpdate = ((MiniatureTileEntity)te).setInnerState(pos.func_177967_a(outFace, -getSize()), state);
/* 363 */             if (isUpdate) {
/* 364 */               getOuterWorld().func_184138_a(outerOffsetPos, outerState, outerState, 2);
/*     */             }
/* 366 */             return isUpdate;
/*     */           } 
/*     */         } 
/*     */         
/* 370 */         return false;
/*     */       } 
/* 372 */       if (state.hasTileEntity()) {
/* 373 */         return false;
/*     */       }
/* 375 */       this.container[pos.func_177958_n()][pos.func_177956_o()][pos.func_177952_p()] = state;
/* 376 */       MiniatureTileEntity.this.func_70296_d();
/* 377 */       state.func_196946_a((IWorld)this, pos, 10);
/* 378 */       return true;
/*     */     }
/*     */ 
/*     */     @Nullable
/*     */     Direction getOutFace(BlockPos pos) {
/* 383 */       return Direction.func_176737_a(fixPos(pos.func_177958_n()), fixPos(pos.func_177956_o()), fixPos(pos.func_177952_p()));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     BlockPos getThisBlockPosition() {
/* 390 */       return MiniatureTileEntity.this.func_174877_v();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     BlockState getOuterBlockState(BlockPos outerPos) {
/* 397 */       return getOuterWorld().func_180495_p(outerPos);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     IFluidState getOuterFluidState(BlockPos outerPos) {
/* 404 */       return getOuterWorld().func_204610_c(outerPos);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     World getOuterWorld() {
/* 411 */       return MiniatureTileEntity.this.func_145831_w();
/*     */     }
/*     */ 
/*     */ 
/*     */     public boolean func_180501_a(BlockPos pos, BlockState newState, int flags) {
/* 416 */       return func_175656_a(pos, newState);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public BlockState func_180495_p(BlockPos pos) {
/* 428 */       if (!hasBlockRange(pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p())) {
/* 429 */         Direction outFace = getOutFace(pos);
/* 430 */         BlockPos outerOffsetPos = getThisBlockPosition().func_177972_a(outFace);
/* 431 */         BlockState outerState = getOuterBlockState(outerOffsetPos);
/* 432 */         if (outerState.func_177230_c() instanceof Miniature) {
/* 433 */           TileEntity te = getOuterWorld().func_175625_s(outerOffsetPos);
/* 434 */           if (te != null && te instanceof MiniatureTileEntity) {
/* 435 */             if (((MiniatureTileEntity)te).getSize() == getSize()) {
/* 436 */               return ((MiniatureTileEntity)te).getInnerState(pos.func_177967_a(outFace, -getSize()));
/*     */             }
/* 438 */             return MiniatureTileEntity.EMPTY;
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 443 */         return getOuterBlockState(getThisBlockPosition().func_177982_a(fixPos(pos.func_177958_n()), fixPos(pos.func_177956_o()), fixPos(pos.func_177952_p())));
/*     */       } 
/*     */       
/* 446 */       return this.container[pos.func_177958_n()][pos.func_177956_o()][pos.func_177952_p()];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public BlockState getInnerBlockState(int x, int y, int z) {
/* 460 */       if (hasBlockRange(x, y, z)) {
/* 461 */         return this.container[x][y][z];
/*     */       }
/* 463 */       return MiniatureTileEntity.EMPTY;
/*     */     }
/*     */ 
/*     */     boolean hasBlockRange(int x, int y, int z) {
/* 467 */       return (x >= 0 && y >= 0 && z >= 0 && x < this.container.length && y < (this.container[x]).length && z < (this.container[x][y]).length);
/*     */     }
/*     */ 
/*     */     private int fixPos(int pos) {
/* 471 */       return (pos < 0) ? -1 : ((pos >= getSize()) ? 1 : 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public IFluidState func_204610_c(BlockPos pos) {
/* 479 */       if (!hasBlockRange(pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p())) {
/* 480 */         Direction outFace = getOutFace(pos);
/* 481 */         BlockPos outerOffsetPos = getThisBlockPosition().func_177972_a(outFace);
/* 482 */         BlockState outerState = getOuterBlockState(outerOffsetPos);
/* 483 */         if (outerState.func_177230_c() instanceof Miniature) {
/* 484 */           TileEntity te = getOuterWorld().func_175625_s(outerOffsetPos);
/* 485 */           if (te != null && te instanceof MiniatureTileEntity) {
/* 486 */             if (((MiniatureTileEntity)te).getSize() == getSize()) {
/* 487 */               return ((MiniatureTileEntity)te).getInnerFluidState(pos.func_177967_a(outFace, -getSize()));
/*     */             }
/* 489 */             return Fluids.field_204541_a.func_207188_f();
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 494 */         return getOuterFluidState(getThisBlockPosition().func_177982_a(fixPos(pos.func_177958_n()), fixPos(pos.func_177956_o()), fixPos(pos.func_177952_p())));
/*     */       } 
/*     */       
/* 497 */       return this.container[pos.func_177958_n()][pos.func_177956_o()][pos.func_177952_p()].func_204520_s();
/*     */     }
/*     */ 
/*     */ 
/*     */     public Biome func_180494_b(BlockPos pos) {
/* 502 */       return getOuterWorld().func_180494_b(MiniatureTileEntity.this.func_174877_v());
/*     */     }
/*     */ 
/*     */ 
/*     */     public int func_175642_b(LightType type, BlockPos pos) {
/* 507 */       return getOuterWorld().func_175642_b(type, MiniatureTileEntity.this.func_174877_v());
/*     */     }
/*     */ 
/*     */ 
/*     */     public ITickList<Block> func_205220_G_() {
/* 512 */       return getOuterWorld().func_205220_G_();
/*     */     }
/*     */ 
/*     */ 
/*     */     public ITickList<Fluid> func_205219_F_() {
/* 517 */       return getOuterWorld().func_205219_F_();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public List<? extends PlayerEntity> func_217369_A() {
/* 526 */       return getOuterWorld().func_217369_A();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Entity func_73045_a(int id) {
/* 563 */       return getOuterWorld().func_73045_a(id);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int func_201669_a(BlockPos pos, int amount) {
/* 571 */       return getOuterWorld().func_201669_a(pos, amount);
/*     */     }
/*     */ 
/*     */ 
/*     */     public MapData func_217406_a(String p_217406_1_) {
/* 576 */       return getOuterWorld().func_217406_a(p_217406_1_);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int func_217395_y() {
/* 585 */       return getOuterWorld().func_217395_y();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Scoreboard func_96441_U() {
/* 594 */       return getOuterWorld().func_96441_U();
/*     */     }
/*     */ 
/*     */ 
/*     */     public RecipeManager func_199532_z() {
/* 599 */       return getOuterWorld().func_199532_z();
/*     */     }
/*     */ 
/*     */ 
/*     */     public NetworkTagManager func_205772_D() {
/* 604 */       return getOuterWorld().func_205772_D();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean func_195585_a(@Nullable Entity entityIn, VoxelShape shape) {
/* 612 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */     public boolean func_201670_d() {
/* 617 */       return this.isRemote;
/*     */     }
/*     */ 
/*     */ 
/*     */     public AbstractChunkProvider func_72863_F() {
/* 622 */       return getOuterWorld().func_72863_F();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class DummyDT
/*     */     extends DimensionType
/*     */   {
/*     */     protected DummyDT() {
/* 630 */       super(0, null, null, null, false);
/*     */     }
/*     */ 
/*     */ 
/*     */     public Dimension func_218270_a(World worldIn) {
/* 635 */       return new DummyDim();
/*     */     }
/*     */ 
/*     */     private class DummyDim
/*     */       extends Dimension {
/*     */       public DummyDim() {
/* 641 */         super(null, null);
/*     */       }
/*     */ 
/*     */ 
/*     */       public ChunkGenerator<?> func_186060_c() {
/* 646 */         return null;
/*     */       }
/*     */ 
/*     */ 
/*     */       public BlockPos func_206920_a(ChunkPos chunkPosIn, boolean checkValid) {
/* 651 */         return null;
/*     */       }
/*     */ 
/*     */ 
/*     */       public BlockPos func_206921_a(int posX, int posZ, boolean checkValid) {
/* 656 */         return null;
/*     */       }
/*     */ 
/*     */ 
/*     */       public float func_76563_a(long worldTime, float partialTicks) {
/* 661 */         return 0.0F;
/*     */       }
/*     */ 
/*     */ 
/*     */       public boolean func_76569_d() {
/* 666 */         return true;
/*     */       }
/*     */ 
/*     */ 
/*     */       public Vec3d func_76562_b(float celestialAngle, float partialTicks) {
/* 671 */         return null;
/*     */       }
/*     */ 
/*     */ 
/*     */       public boolean func_76567_e() {
/* 676 */         return false;
/*     */       }
/*     */ 
/*     */ 
/*     */       public boolean func_76568_b(int x, int z) {
/* 681 */         return false;
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 25 ms
	
*/