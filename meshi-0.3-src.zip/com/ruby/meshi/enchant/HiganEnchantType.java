/*    */ package com.ruby.meshi.enchant;
/*    */ 
/*    */ import net.minecraft.enchantment.EnchantmentType;
/*    */ import net.minecraft.item.Item;
/*    */ 
/*    */ public class HiganEnchantType {
/*    */   static {
/*  8 */     BRACELET = EnchantmentType.create("bracelet", item -> item instanceof com.ruby.meshi.item.NinjaBracelet);
/*    */   }
/*    */   
/*    */   public static final EnchantmentType BRACELET;
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 1 ms
	
*/