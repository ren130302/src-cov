/*    */ package com.ruby.meshi.item;
/*    */ import com.ruby.meshi.block.SakuraBlocks;
/*    */ import net.minecraft.block.BlockState;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ import net.minecraft.entity.player.PlayerEntity;
/*    */ import net.minecraft.item.HoeItem;
/*    */ import net.minecraft.item.IItemTier;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemUseContext;
/*    */ import net.minecraft.util.ActionResultType;
/*    */ import net.minecraft.util.Direction;
/*    */ import net.minecraft.util.SoundCategory;
/*    */ import net.minecraft.util.SoundEvents;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.event.ForgeEventFactory;
/*    */ 
/*    */ public class PaddyFieldHoe extends HoeItem {
/*    */   public PaddyFieldHoe(IItemTier tier, float attackSpeedIn, Item.Properties builder) {
/* 20 */     super(tier, attackSpeedIn, builder);
/*    */   }
/*    */ 
/*    */ 
/*    */   public ActionResultType func_195939_a(ItemUseContext context) {
/* 25 */     World world = context.func_195991_k();
/* 26 */     BlockPos blockpos = context.func_195995_a();
/* 27 */     int hook = ForgeEventFactory.onHoeUse(context);
/* 28 */     if (hook != 0)
/* 29 */       return (hook > 0) ? ActionResultType.SUCCESS : ActionResultType.FAIL; 
/* 30 */     if (context.func_196000_l() != Direction.DOWN && world.func_175623_d(blockpos.func_177984_a())) {
/* 31 */       BlockState blockstate = (BlockState)field_195973_b.get(world.func_180495_p(blockpos).func_177230_c());
/* 32 */       if (blockstate != null) {
/* 33 */         PlayerEntity playerentity = context.func_195999_j();
/* 34 */         world.func_184133_a(playerentity, blockpos, SoundEvents.field_187693_cj, SoundCategory.BLOCKS, 1.0F, 1.0F);
/* 35 */         if (!world.field_72995_K) {
/* 36 */           world.func_175656_a(blockpos, SakuraBlocks.PADDY_FIELD.func_176223_P());
/* 37 */           if (playerentity != null) {
/* 38 */             context.func_195996_i().func_222118_a(1, (LivingEntity)playerentity, p_220043_1_ -> p_220043_1_.func_213334_d(context.func_221531_n()));
/*    */           }
/*    */         } 
/*    */ 
/*    */ 
/*    */         
/* 44 */         return ActionResultType.SUCCESS;
/*    */       } 
/*    */     } 
/*    */     
/* 48 */     return ActionResultType.PASS;
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 6 ms
	
*/