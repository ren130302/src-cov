/*     */ package com.ruby.meshi.item;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.ruby.meshi.block.tileentity.ManekiNekoTileEntity;
/*     */ import java.util.LinkedList;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.player.ClientPlayerEntity;
/*     */ import net.minecraft.client.world.ClientWorld;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.LivingEntity;
/*     */ import net.minecraft.entity.player.PlayerEntity;
/*     */ import net.minecraft.entity.projectile.AbstractArrowEntity;
/*     */ import net.minecraft.entity.projectile.ThrowableEntity;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.ItemUseContext;
/*     */ import net.minecraft.util.ActionResult;
/*     */ import net.minecraft.util.ActionResultType;
/*     */ import net.minecraft.util.Direction;
/*     */ import net.minecraft.util.Hand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.RayTraceContext;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.api.distmarker.Dist;
/*     */ import net.minecraftforge.api.distmarker.OnlyIn;
/*     */ import net.minecraftforge.client.event.InputEvent;
/*     */ import net.minecraftforge.client.event.RenderGameOverlayEvent;
/*     */ import net.minecraftforge.event.TickEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingDamageEvent;
/*     */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*     */ import net.minecraftforge.fml.common.Mod;
/*     */ import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
/*     */ 
/*     */ @EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE, value = {Dist.CLIENT})
/*     */ public class BiomeLenz
/*     */   extends Item implements Accessory {
/*     */   private static Vec3d vec;
/*  39 */   private static DPSBukket damageBukket = new DPSBukket();
/*     */ 
/*     */   public BiomeLenz(Item.Properties properties) {
/*  42 */     super(properties);
/*     */   }
/*     */ 
/*     */ 
/*     */   public ActionResultType func_195939_a(ItemUseContext context) {
/*  47 */     return super.func_195939_a(context);
/*     */   }
/*     */ 
/*     */ 
/*     */   public ActionResult<ItemStack> func_77659_a(World worldIn, PlayerEntity playerIn, Hand handIn) {
/*  52 */     return super.func_77659_a(worldIn, playerIn, handIn);
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_77663_a(ItemStack stack, World worldIn, Entity entityIn, int itemSlot, boolean isSelected) {
/*  57 */     super.func_77663_a(stack, worldIn, entityIn, itemSlot, isSelected);
/*     */   }
/*     */ 
/*     */   @OnlyIn(Dist.CLIENT)
/*     */   @SubscribeEvent
/*     */   public static void renderText(RenderGameOverlayEvent.Text event) {
/*  63 */     ClientPlayerEntity clientPlayerEntity = (Minecraft.func_71410_x()).field_71439_g;
/*  64 */     if (clientPlayerEntity != null) {
/*  65 */       World world = ((PlayerEntity)clientPlayerEntity).field_70170_p;
/*  66 */       if (0 < ((PlayerEntity)clientPlayerEntity).field_71071_by.func_213901_a(HiganItems.BIOME_LENZ)) {
/*  67 */         int hour = (int)((world.func_72912_H().func_76073_f() + 6000L) % 24000L / 1000L);
/*  68 */         int minute = (int)((world.func_72912_H().func_76073_f() + 6000L) % 600L / 10L);
/*  69 */         event.getLeft().add("Time: " + String.format("%02d:%02d", new Object[] { Integer.valueOf(hour), Integer.valueOf(minute) }) + (world.func_72912_H().func_76059_o() ? " Rain" : "") + (world.func_72912_H().func_76061_m() ? " Thunder" : ""));
/*  70 */         event.getLeft().add("NPos: " + getFormatedPos(clientPlayerEntity.func_180425_c()) + "(" + Direction.func_176733_a((clientPlayerEntity.func_189653_aC()).field_189983_j) + ")");
/*  71 */         event.getLeft().add("SPos: " + getFormatedPos(clientPlayerEntity.getBedLocation(((PlayerEntity)clientPlayerEntity).field_71093_bK)));
/*  72 */         if (vec != null) {
/*  73 */           Vec3d subVec = roundDown(func_219968_a(world, (PlayerEntity)clientPlayerEntity, RayTraceContext.FluidMode.NONE).func_216347_e()).func_178788_d(vec);
/*  74 */           event.getLeft().add("RCPos: " + getFormatedPos(new BlockPos(subVec)));
/*     */         } 
/*  76 */         event.getLeft().add("Biome: " + ((PlayerEntity)clientPlayerEntity).field_70170_p.func_180494_b(clientPlayerEntity.func_180425_c()).func_205403_k().func_150254_d());
/*  77 */         event.getLeft().add("DPM: " + String.format("%.1f", new Object[] { Double.valueOf(damageBukket.getDPM()) }) + "(" + String.format("%.1f", new Object[] { Double.valueOf(damageBukket.getDPS()) }) + ")");
/*  78 */         if (ManekiNekoTileEntity.isEntityDeny(clientPlayerEntity.func_180425_c())) {
/*  79 */           event.getLeft().add("No mob spawn area");
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   private static Vec3d roundDown(Vec3d vec) {
/*  86 */     return new Vec3d((int)vec.func_82615_a(), (int)vec.func_82617_b(), (int)vec.func_82616_c());
/*     */   }
/*     */ 
/*     */   @OnlyIn(Dist.CLIENT)
/*     */   @SubscribeEvent
/*     */   public static void rightClick(InputEvent.MouseInputEvent event) {
/*  92 */     if (event.getButton() == 1) {
/*  93 */       ClientPlayerEntity clientPlayerEntity = (Minecraft.func_71410_x()).field_71439_g;
/*  94 */       if (clientPlayerEntity != null) {
/*  95 */         World world = ((PlayerEntity)clientPlayerEntity).field_70170_p;
/*  96 */         if (0 < ((PlayerEntity)clientPlayerEntity).field_71071_by.func_213901_a(HiganItems.BIOME_LENZ)) {
/*  97 */           vec = roundDown(func_219968_a(world, (PlayerEntity)clientPlayerEntity, RayTraceContext.FluidMode.NONE).func_216347_e());
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   private static String getFormatedPos(BlockPos pos) {
/* 104 */     if (pos == null) {
/* 105 */       return "";
/*     */     }
/* 107 */     return pos.func_177958_n() + ", " + pos.func_177956_o() + ", " + pos.func_177952_p();
/*     */   }
/*     */ 
/*     */   @OnlyIn(Dist.CLIENT)
/*     */   @SubscribeEvent
/*     */   public static void onLivingDamage(LivingDamageEvent event) {
/*     */     LivingEntity livingEntity;
/* 114 */     Entity attacker = event.getSource().func_76364_f();
/* 115 */     if (attacker instanceof AbstractArrowEntity) {
/* 116 */       attacker = ((AbstractArrowEntity)attacker).func_212360_k();
/*     */     }
/* 118 */     if (attacker instanceof ThrowableEntity) {
/* 119 */       livingEntity = ((ThrowableEntity)attacker).func_85052_h();
/*     */     }
/* 121 */     if (livingEntity instanceof PlayerEntity && 
/* 122 */       livingEntity.func_110124_au() == (Minecraft.func_71410_x()).field_71439_g.func_110124_au()) {
/* 123 */       damageBukket.sum(event.getAmount());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   @OnlyIn(Dist.CLIENT)
/*     */   @SubscribeEvent
/*     */   public static void onTick(TickEvent.ClientTickEvent event) {
/* 131 */     if (event.phase == TickEvent.Phase.END) {
/* 132 */       ClientWorld clientWorld = (Minecraft.func_71410_x()).field_71441_e;
/* 133 */       if (clientWorld != null && clientWorld.func_72912_H().func_82573_f() % 20L == 0L)
/* 134 */         damageBukket.nextBukket(); 
/*     */     } 
/*     */   }
/*     */ 
/*     */   private static class DPSBukket
/*     */   {
/* 140 */     private LinkedList<Double> bukket = Lists.newLinkedList();
/* 141 */     private int maxSize = 60;
/*     */ 
/*     */     public void nextBukket() {
/* 144 */       if (this.bukket.size() >= this.maxSize) {
/* 145 */         this.bukket.remove(0);
/*     */       }
/* 147 */       this.bukket.add(Double.valueOf(0.0D));
/*     */     }
/*     */ 
/*     */     public void sum(double e) {
/* 151 */       int index = this.bukket.size() - 1;
/* 152 */       this.bukket.set(index, Double.valueOf(((Double)this.bukket.get(index)).floatValue() + e));
/*     */     }
/*     */ 
/*     */     public double getDPM() {
/* 156 */       return this.bukket.stream().mapToDouble(x -> x.doubleValue()).sum() / 60.0D;
/*     */     }
/*     */ 
/*     */     public double getDPS() {
/* 160 */       if (this.bukket.isEmpty()) {
/* 161 */         nextBukket();
/*     */       }
/* 163 */       return ((Double)this.bukket.getLast()).doubleValue();
/*     */     }
/*     */     
/*     */     private DPSBukket() {}
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 15 ms
	
*/