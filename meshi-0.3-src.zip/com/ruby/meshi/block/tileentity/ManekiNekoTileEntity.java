/*    */ package com.ruby.meshi.block.tileentity;
/*    */ 
/*    */ import com.ruby.meshi.init.HiganTileEntityType;
/*    */ import java.util.WeakHashMap;
/*    */ import java.util.function.Predicate;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraftforge.event.entity.living.LivingSpawnEvent;
/*    */ import net.minecraftforge.eventbus.api.Event;
/*    */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*    */ import net.minecraftforge.fml.common.Mod;
/*    */ import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
/*    */ 
/*    */ 
/*    */ @EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
/*    */ public class ManekiNekoTileEntity
/*    */   extends TileEntity
/*    */ {
/* 19 */   static final WeakHashMap<TileEntity, Predicate<BlockPos>> map = new WeakHashMap<>();
/* 20 */   int range = 4;
/*    */ 
/*    */   public ManekiNekoTileEntity() {
/* 23 */     super(HiganTileEntityType.MANEKINEKO);
/*    */   }
/*    */ 
/*    */   public static boolean isEntityDeny(BlockPos pos) {
/* 27 */     return map.values().stream().anyMatch(p -> p.test(pos));
/*    */   }
/*    */ 
/*    */ 
/*    */   public void onLoad() {
/* 32 */     super.onLoad();
/* 33 */     map.put(this, pos -> (Math.abs(func_174877_v().func_177958_n() - pos.func_177958_n() >> 4) <= this.range && Math.abs(func_174877_v().func_177952_p() - pos.func_177952_p() >> 4) <= this.range));
/*    */   }
/*    */ 
/*    */ 
/*    */   public void onChunkUnloaded() {
/* 38 */     super.onChunkUnloaded();
/* 39 */     map.remove(this);
/*    */   }
/*    */ 
/*    */ 
/*    */   public void func_145843_s() {
/* 44 */     super.func_145843_s();
/* 45 */     map.remove(this);
/*    */   }
/*    */ 
/*    */   @SubscribeEvent
/*    */   public static void entitySpawn(LivingSpawnEvent.CheckSpawn event) {
/* 50 */     if (!event.isSpawner() && 
/* 51 */       event.getEntity() instanceof net.minecraft.entity.monster.IMob) {
/* 52 */       BlockPos entityPos = event.getEntity().func_180425_c();
/* 53 */       if (isEntityDeny(entityPos))
/* 54 */         event.setResult(Event.Result.DENY); 
/*    */     } 
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 5 ms
	
*/