/*    */ package com.ruby.meshi.block;
/*    */ 
/*    */ import com.ruby.meshi.block.tileentity.CollectorPressurePlateTileEntity;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import java.util.stream.Collectors;
/*    */ import java.util.stream.Stream;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.BlockState;
/*    */ import net.minecraft.entity.player.PlayerEntity;
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.state.IProperty;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class DeliveryPressurePlate extends CollectionAndDeliveryBase {
/*    */   public DeliveryPressurePlate(Block.Properties properties, int horizon, int vertical) {
/* 20 */     super(properties, horizon, vertical);
/*    */   }
/*    */ 
/*    */ 
/*    */   public void onPressedSwitch(BlockState state, World worldIn, BlockPos pos, PlayerEntity playerIn) {
/* 25 */     CollectorPressurePlateTileEntity tile = (CollectorPressurePlateTileEntity)worldIn.func_175625_s(pos);
/*    */     
/* 27 */     boolean isForce = ((Boolean)state.func_177229_b((IProperty)FORCE)).booleanValue();
/*    */ 
/*    */ 
/*    */     
/* 31 */     List<Item> collectorFilter = (List<Item>)getSlotList((IInventory)tile).stream().filter(stack -> !stack.func_190926_b()).map(ItemStack::func_77973_b).collect(Collectors.toList());
/* 32 */     if (!isForce || !collectorFilter.isEmpty()) {
/* 33 */       Set<IInventory> inventorySet = getSurroundingIInventory(worldIn, pos, this.horizonSize, this.verticalSize);
/* 34 */       if (isForce) {
/*    */         
/* 36 */         List<CollectionAndDeliveryBase.InventoryEntry> playerEmptyEntry = createInventoryEntrys((IInventory)playerIn.field_71071_by, (List<ItemStack>)playerIn.field_71071_by.field_70462_a, stack -> stack.func_190926_b(), (id, stack) -> true);
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 41 */         if (!playerEmptyEntry.isEmpty())
/*    */         {
/* 43 */           collectorFilter.stream()
/* 44 */             .filter(item -> (collectorFilter.stream().filter(()).count() > playerIn.field_71071_by.field_70462_a.stream().filter(()).count()))
/* 45 */             .forEach(item -> {
/*    */                 CollectionAndDeliveryBase.InventoryEntry invEntry = inventorySet.stream().flatMap(()).findFirst().orElse(null);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */                 
/*    */                 if (invEntry != null && !playerEmptyEntry.isEmpty()) {
/*    */                   searchAndInsert(invEntry, playerEmptyEntry.remove(0), true);
/*    */                 }
/*    */               });
/*    */         }
/*    */       } 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 64 */       List<CollectionAndDeliveryBase.InventoryEntry> playerEntryList = createInventoryEntrys((IInventory)playerIn.field_71071_by, (List<ItemStack>)playerIn.field_71071_by.field_70462_a, stack -> 
/*    */           
/* 66 */           (!stack.func_190926_b() && (collectorFilter.isEmpty() ? stack.func_77985_e() : collectorFilter.contains(stack.func_77973_b()))), (id, stack) -> (stack.func_190916_E() < playerIn.field_71071_by.func_70297_j_()));
/*    */ 
/*    */ 
/*    */       
/* 70 */       if (!playerEntryList.isEmpty()) {
/*    */ 
/*    */ 
/*    */         
/* 74 */         Set<Item> matchedFilter = (Set<Item>)playerEntryList.stream().map(CollectionAndDeliveryBase.InventoryEntry::getItem).collect(Collectors.toSet());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 82 */         List<CollectionAndDeliveryBase.InventoryEntry> chestEntrySet = (List<CollectionAndDeliveryBase.InventoryEntry>)inventorySet.stream().flatMap(inv -> createInventoryEntrys(inv, getSlotList(inv), (), ()).stream().sorted()).collect(Collectors.toList());
/* 83 */         if (!chestEntrySet.isEmpty())
/*    */         {
/* 85 */           playerEntryList.forEach(playerEntry -> chestEntrySet.stream().filter(()).forEach(()));
/*    */         }
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 12 ms
	
*/