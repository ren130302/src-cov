// Warning: No line numbers available in class file
/*  */ package com.ruby.meshi.block;
/*  */ 
/*  */ import java.lang.annotation.ElementType;
/*  */ import java.lang.annotation.Retention;
/*  */ import java.lang.annotation.RetentionPolicy;
/*  */ import java.lang.annotation.Target;
/*  */ 
/*  */ @Retention(RetentionPolicy.RUNTIME)
/*  */ @Target({ElementType.TYPE})
/*  */ public @interface HideCreateTab {}

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 1 ms
	
*/