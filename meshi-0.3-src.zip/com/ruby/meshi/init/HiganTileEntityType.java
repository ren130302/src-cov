/*    */ package com.ruby.meshi.init;
/*    */ 
/*    */ import com.ruby.meshi.block.JPChest;
/*    */ import com.ruby.meshi.block.ManekiNeko;
/*    */ import com.ruby.meshi.block.SakuraBlocks;
/*    */ import com.ruby.meshi.block.SlideDoor;
/*    */ import java.util.function.Supplier;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.tileentity.TileEntityType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HiganTileEntityType
/*    */ {
/* 27 */   public static final TileEntityType<?> WALL_SHELF = create("wall_shelf", com.ruby.meshi.block.tileentity.WallShelfTileEntity::new, new Block[] { SakuraBlocks.WALL_SHELF });
/* 28 */   public static final TileEntityType<?> COLLECTOR_PLATE = create("collector_pressure_plate", com.ruby.meshi.block.tileentity.CollectorPressurePlateTileEntity::new, new Block[] { SakuraBlocks.COLLECTOR_PLATE, SakuraBlocks.DELIVERY_PLATE });
/* 29 */   public static final TileEntityType<?> BAMBOO_POT = create("bamboo_pot", com.ruby.meshi.block.tileentity.BambooPotTileEntity::new, new Block[] { SakuraBlocks.BAMBOO_POT });
/* 30 */   public static final TileEntityType<?> MILLSTONE = create("millstone", com.ruby.meshi.block.tileentity.MillstoneTileEntity::new, new Block[] { SakuraBlocks.MILLSTONE });
/* 31 */   public static final TileEntityType<?> HEARTH = create("hearth", com.ruby.meshi.block.tileentity.HearthTileEntity::new, new Block[] { SakuraBlocks.HEARTH });
/* 32 */   public static final TileEntityType<?> CARDBOARD = create("cardboard", com.ruby.meshi.block.tileentity.CardboardTileEntity::new, new Block[] { SakuraBlocks.CARDBOARD });
/* 33 */   public static final TileEntityType<?> SLIDEDOOR = create("slidedoor", com.ruby.meshi.block.tileentity.SlideDoorTileEntity::new, getIsInstanceBlocks(SlideDoor.class));
/* 34 */   public static final TileEntityType<?> MINIATUE = create("miniature", com.ruby.meshi.block.tileentity.MiniatureTileEntity::new, new Block[] { SakuraBlocks.MINIATURE });
/* 35 */   public static final TileEntityType<?> JPCHEST = create("jpchest", com.ruby.meshi.block.tileentity.ContainerTileEntity::new, getIsInstanceBlocks(JPChest.class));
/* 36 */   public static final TileEntityType<?> MANEKINEKO = create("manekineko", com.ruby.meshi.block.tileentity.ManekiNekoTileEntity::new, getIsInstanceBlocks(ManekiNeko.class));
/*    */ 
/*    */   private static TileEntityType<? extends TileEntity> create(String key, Supplier<? extends TileEntity> tile, Block... block) {
/* 39 */     return (TileEntityType<? extends TileEntity>)TileEntityType.Builder.func_223042_a(tile, block).func_206865_a(null).setRegistryName("meshi", key);
/*    */   }
/*    */ 
/*    */   private static Block[] getIsInstanceBlocks(Class<?> clazz) {
/* 43 */     return (Block[])RegisterEvents.getFields(SakuraBlocks.class).filter(clazz::isInstance).toArray(x$0 -> new Block[x$0]);
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 6 ms
	
*/