/*     */ package com.ruby.meshi.common.inventory;
/*     */ 
/*     */ import com.ruby.meshi.block.tileentity.CollectorPressurePlateTileEntity;
/*     */ import com.ruby.meshi.init.HiganContainerType;
/*     */ import net.minecraft.entity.player.PlayerEntity;
/*     */ import net.minecraft.entity.player.PlayerInventory;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.Inventory;
/*     */ import net.minecraft.inventory.container.ClickType;
/*     */ import net.minecraft.inventory.container.Container;
/*     */ import net.minecraft.inventory.container.ContainerType;
/*     */ import net.minecraft.inventory.container.Slot;
/*     */ import net.minecraft.item.ItemStack;
/*     */ 
/*     */ public class CollectorPressurePlateContainer
/*     */   extends Container
/*     */ {
/*     */   private IInventory inventory;
/*     */   
/*     */   public CollectorPressurePlateContainer(int windowId, PlayerInventory playerInventory) {
/*  21 */     this(HiganContainerType.COLLECTOR_PLATE, windowId, playerInventory, (IInventory)new Inventory(10));
/*     */   }
/*     */ 
/*     */   public CollectorPressurePlateContainer(int windowId, PlayerInventory playerInventory, CollectorPressurePlateTileEntity inventory) {
/*  25 */     this(HiganContainerType.COLLECTOR_PLATE, windowId, playerInventory, (IInventory)inventory);
/*     */   }
/*     */ 
/*     */   protected CollectorPressurePlateContainer(ContainerType<?> type, int id, PlayerInventory playerInventory, IInventory inventory) {
/*  29 */     super(type, id);
/*  30 */     this.inventory = inventory;
/*     */     
/*  32 */     inventory.func_174889_b(playerInventory.field_70458_d);
/*     */ 
/*     */ 
/*     */     
/*  36 */     for (int chestRow = 0; chestRow < 2; chestRow++) {
/*  37 */       for (int chestCol = 0; chestCol < 5; chestCol++) {
/*  38 */         func_75146_a(new Slot(inventory, chestCol + chestRow * 5, 44 + chestCol * 18, 33 + chestRow * 18));
/*     */       }
/*     */     } 
/*     */     int i;
/*  42 */     for (i = 0; i < 3; i++) {
/*  43 */       for (int j = 0; j < 9; j++) {
/*  44 */         func_75146_a(new Slot((IInventory)playerInventory, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
/*     */       }
/*     */     } 
/*     */     
/*  48 */     for (i = 0; i < 9; i++) {
/*  49 */       func_75146_a(new Slot((IInventory)playerInventory, i, 8 + i * 18, 142));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   public ItemStack func_184996_a(int slotId, int dragType, ClickType clickTypeIn, PlayerEntity player) {
/*  55 */     if (clickTypeIn == ClickType.QUICK_MOVE || clickTypeIn == ClickType.QUICK_CRAFT) {
/*  56 */       return ItemStack.field_190927_a;
/*     */     }
/*  58 */     if (0 <= slotId && slotId < 10) {
/*  59 */       PlayerInventory playerinventory = player.field_71071_by;
/*  60 */       ItemStack stack = playerinventory.func_70445_o();
/*  61 */       if (dragType == 0 && 
/*  62 */         !stack.func_190926_b()) {
/*  63 */         ItemStack copy = stack.func_77946_l();
/*  64 */         copy.func_190920_e(1);
/*  65 */         func_75139_a(slotId).func_75215_d(copy);
/*     */       } 
/*     */       
/*  68 */       if (dragType == 1) {
/*  69 */         func_75139_a(slotId).func_75215_d(ItemStack.field_190927_a);
/*     */       }
/*  71 */       return ItemStack.field_190927_a;
/*     */     } 
/*  73 */     return super.func_184996_a(slotId, dragType, clickTypeIn, player);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   public ItemStack func_82846_b(PlayerEntity playerIn, int index) {
/*  79 */     ItemStack itemstack = ItemStack.field_190927_a;
/*  80 */     Slot slot = this.field_75151_b.get(index);
/*     */     
/*  82 */     if (slot != null && slot.func_75216_d()) {
/*  83 */       ItemStack itemstack1 = slot.func_75211_c();
/*  84 */       itemstack = itemstack1.func_77946_l();
/*     */       
/*  86 */       if (index < 10) {
/*  87 */         if (!func_75135_a(itemstack1, 10, this.field_75151_b.size(), true)) {
/*  88 */           return ItemStack.field_190927_a;
/*     */         }
/*  90 */       } else if (!func_75135_a(itemstack1, 0, 10, false)) {
/*  91 */         return ItemStack.field_190927_a;
/*     */       } 
/*     */       
/*  94 */       if (itemstack1.func_190926_b()) {
/*  95 */         slot.func_75215_d(ItemStack.field_190927_a);
/*     */       } else {
/*  97 */         slot.func_75218_e();
/*     */       } 
/*     */     } 
/*     */     
/* 101 */     return itemstack;
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_75134_a(PlayerEntity playerIn) {
/* 106 */     super.func_75134_a(playerIn);
/* 107 */     this.inventory.func_174886_c(playerIn);
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_75145_c(PlayerEntity playerIn) {
/* 112 */     return this.inventory.func_70300_a(playerIn);
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 7 ms
	
*/