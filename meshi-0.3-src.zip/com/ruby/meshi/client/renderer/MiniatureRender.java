/*     */ package com.ruby.meshi.client.renderer;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.mojang.blaze3d.platform.GlStateManager;
/*     */ import com.ruby.meshi.block.tileentity.MiniatureTileEntity;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import java.util.function.BiConsumer;
/*     */ import javax.vecmath.Matrix4f;
/*     */ import net.minecraft.block.BlockRenderType;
/*     */ import net.minecraft.block.BlockState;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.renderer.BlockRendererDispatcher;
/*     */ import net.minecraft.client.renderer.BufferBuilder;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.model.BakedQuad;
/*     */ import net.minecraft.client.renderer.model.IBakedModel;
/*     */ import net.minecraft.client.renderer.model.ItemCameraTransforms;
/*     */ import net.minecraft.client.renderer.model.ItemOverrideList;
/*     */ import net.minecraft.client.renderer.texture.AtlasTexture;
/*     */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*     */ import net.minecraft.client.renderer.tileentity.TileEntityRenderer;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.client.renderer.vertex.VertexFormat;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.BlockRenderLayer;
/*     */ import net.minecraft.util.Direction;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.IEnviromentBlockReader;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.client.model.data.IModelData;
/*     */ import net.minecraftforge.client.model.pipeline.LightUtil;
/*     */ import org.apache.commons.lang3.tuple.Pair;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MiniatureRender
/*     */   extends TileEntityRenderer<MiniatureTileEntity>
/*     */ {
/*     */   protected static BlockRendererDispatcher blockRenderer;
/*  45 */   Random rand = new Random();
/*  46 */   BB wrapBB = new BB();
/*     */ 
/*     */ 
/*     */   public void render(MiniatureTileEntity te, double x, double y, double z, float partialTicks, int destroyStage) {
/*  50 */     if (blockRenderer == null) {
/*  51 */       blockRenderer = Minecraft.func_71410_x().func_175602_ab();
/*     */     }
/*  53 */     Tessellator tessellator = Tessellator.func_178181_a();
/*  54 */     this.wrapBB.buffer = tessellator.func_178180_c();
/*  55 */     this.wrapBB.offsetSize = 1.0F / te.getSize();
/*  56 */     func_147499_a(AtlasTexture.field_110575_b);
/*  57 */     RenderHelper.func_74518_a();
/*  58 */     if (Minecraft.func_71379_u()) {
/*  59 */       GlStateManager.shadeModel(7425);
/*     */     } else {
/*  61 */       GlStateManager.shadeModel(7424);
/*     */     } 
/*     */     
/*  64 */     GlStateManager.enableCull();
/*     */     
/*  66 */     GL11.glPushMatrix();
/*  67 */     GlStateManager.disableBlend();
/*  68 */     this.wrapBB.func_181668_a(7, DefaultVertexFormats.field_176600_a);
/*     */     
/*  70 */     if (te.renderSolidCache != null) {
/*  71 */       te.renderSolidCache.rewind();
/*  72 */       this.wrapBB.func_178993_a(te.renderSolidState);
/*  73 */       this.wrapBB.putBulkData(te.renderSolidCache);
/*     */     } else {
/*  75 */       renderMiniatureBlocks(te, this.wrapBB, true, (b, s) -> {
/*     */             te.renderSolidCache = b;
/*     */             
/*     */             te.renderSolidState = s;
/*     */           });
/*     */     } 
/*  81 */     GL11.glTranslated(x, y, z);
/*     */     
/*  83 */     this.wrapBB.func_178969_c(0.0D, 0.0D, 0.0D);
/*  84 */     tessellator.func_78381_a();
/*  85 */     GL11.glPopMatrix();
/*     */ 
/*     */     
/*  88 */     GL11.glPushMatrix();
/*  89 */     GlStateManager.enableBlend();
/*  90 */     GlStateManager.blendFunc(770, 771);
/*  91 */     this.wrapBB.func_181668_a(7, DefaultVertexFormats.field_176600_a);
/*     */     
/*  93 */     if (te.renderCache != null) {
/*  94 */       te.renderCache.rewind();
/*  95 */       this.wrapBB.func_178993_a(te.renderState);
/*  96 */       this.wrapBB.putBulkData(te.renderCache);
/*     */     } else {
/*  98 */       renderMiniatureBlocks(te, this.wrapBB, false, (b, s) -> {
/*     */             te.renderCache = b;
/*     */             
/*     */             te.renderState = s;
/*     */           });
/*     */     } 
/* 104 */     GL11.glTranslated(x, y, z);
/*     */ 
/*     */     
/* 107 */     this.wrapBB.func_181674_a((float)-x, (float)-y, (float)-z);
/* 108 */     this.wrapBB.func_178969_c(0.0D, 0.0D, 0.0D);
/* 109 */     tessellator.func_78381_a();
/* 110 */     GL11.glPopMatrix();
/*     */     
/* 112 */     RenderHelper.func_74519_b();
/*     */   }
/*     */ 
/*     */ 
/*     */   public void renderMiniatureBlocks(MiniatureTileEntity te, BufferBuilder buffer, boolean isSolid, BiConsumer<ByteBuffer, BufferBuilder.State> container) {
/* 117 */     BlockPos worldPos = te.func_174877_v();
/* 118 */     World world = te.getInnerWorld();
/* 119 */     BlockPos.MutableBlockPos mpos = new BlockPos.MutableBlockPos();
/*     */ 
/*     */     
/* 122 */     for (int i = 0; i < te.getSize(); i++) {
/* 123 */       for (int j = 0; j < te.getSize(); j++) {
/* 124 */         for (int k = 0; k < te.getSize(); k++) {
/* 125 */           mpos.func_181079_c(i, j, k);
/* 126 */           BlockState innerState = te.getInnerState(i, j, k);
/* 127 */           if (innerState != MiniatureTileEntity.EMPTY) {
/* 128 */             this.wrapBB.innerPos = (BlockPos)mpos;
/* 129 */             IBakedModel model = blockRenderer.func_175023_a().func_178125_b(innerState);
/* 130 */             if (te.isNoTexResize()) {
/* 131 */               model = new BakeWraper(model, mpos.func_185334_h(), te.getSize());
/*     */             }
/* 133 */             float offsetSize = 1.0F / te.getSize();
/* 134 */             this.wrapBB.func_178969_c((mpos.func_177958_n() * offsetSize), (mpos.func_177956_o() * offsetSize), (mpos.func_177952_p() * offsetSize));
/* 135 */             if (isSolid) {
/* 136 */               if (innerState.func_185901_i() != BlockRenderType.INVISIBLE && hasPriority(innerState.func_177230_c().func_180664_k())) {
/* 137 */                 blockRenderer.func_175019_b().renderModel((IEnviromentBlockReader)world, model, innerState, (BlockPos)mpos, this.wrapBB, true, this.rand, 42L, model.getModelData((IEnviromentBlockReader)world, worldPos, innerState, null));
/*     */               }
/*     */             } else {
/* 140 */               if (innerState.func_185901_i() != BlockRenderType.INVISIBLE && !hasPriority(innerState.func_177230_c().func_180664_k())) {
/* 141 */                 blockRenderer.func_175019_b().renderModel((IEnviromentBlockReader)world, model, innerState, (BlockPos)mpos, this.wrapBB, true, this.rand, 42L, model.getModelData((IEnviromentBlockReader)world, worldPos, innerState, null));
/*     */               }
/* 143 */               if (!innerState.func_204520_s().func_206888_e()) {
/* 144 */                 blockRenderer.func_215331_a((BlockPos)mpos, (IEnviromentBlockReader)world, this.wrapBB, innerState.func_204520_s());
/*     */               }
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 151 */     this.wrapBB.func_178966_f().flip();
/* 152 */     container.accept(ByteBuffer.allocate(this.wrapBB.func_178966_f().limit()).put(this.wrapBB.func_178966_f()), this.wrapBB.func_181672_a());
/* 153 */     this.wrapBB.func_178966_f().rewind();
/*     */   }
/*     */ 
/*     */   class BakeWraper
/*     */     implements IBakedModel {
/*     */     IBakedModel model;
/*     */     BlockPos pos;
/*     */     int size;
/*     */     
/*     */     public BakeWraper(IBakedModel model, BlockPos pos, int size) {
/* 163 */       this.model = model;
/* 164 */       this.pos = pos;
/* 165 */       this.size = size;
/*     */     }
/*     */ 
/*     */     BakeWraper setSize(int size) {
/* 169 */       this.size = size;
/* 170 */       return this;
/*     */     }
/*     */ 
/*     */     BakeWraper setPos(BlockPos pos) {
/* 174 */       this.pos = pos;
/* 175 */       return this;
/*     */     }
/*     */ 
/*     */     BakeWraper setModel(IBakedModel model) {
/* 179 */       this.model = model;
/* 180 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */     public List<BakedQuad> func_200117_a(BlockState state, Direction side, Random rand) {
/* 185 */       return this.model.func_200117_a(state, side, rand);
/*     */     }
/*     */ 
/*     */ 
/*     */     public boolean func_177555_b() {
/* 190 */       return this.model.func_177555_b();
/*     */     }
/*     */ 
/*     */ 
/*     */     public boolean func_177556_c() {
/* 195 */       return this.model.func_177556_c();
/*     */     }
/*     */ 
/*     */ 
/*     */     public boolean func_188618_c() {
/* 200 */       return this.model.func_188618_c();
/*     */     }
/*     */ 
/*     */ 
/*     */     public TextureAtlasSprite func_177554_e() {
/* 205 */       return this.model.func_177554_e();
/*     */     }
/*     */ 
/*     */ 
/*     */     public ItemCameraTransforms func_177552_f() {
/* 210 */       return this.model.func_177552_f();
/*     */     }
/*     */ 
/*     */ 
/*     */     public ItemOverrideList func_188617_f() {
/* 215 */       return this.model.func_188617_f();
/*     */     }
/*     */ 
/*     */ 
/*     */     public IBakedModel getBakedModel() {
/* 220 */       return this.model.getBakedModel();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     public List<BakedQuad> getQuads(BlockState state, Direction side, Random rand, IModelData extraData) {
/* 226 */       List<BakedQuad> quads = this.model.getQuads(state, side, rand, extraData);
/* 227 */       List<BakedQuad> transQuads = Lists.newArrayList();
/* 228 */       for (BakedQuad quad : quads) {
/* 229 */         int[] data = Arrays.copyOf(quad.func_178209_a(), (quad.func_178209_a()).length);
/* 230 */         float[] v = new float[4];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 240 */         float uOffset = (quad.func_187508_a().func_94212_f() - quad.func_187508_a().func_94209_e()) / this.size;
/* 241 */         float vOffset = (quad.func_187508_a().func_94210_h() - quad.func_187508_a().func_94206_g()) / this.size;
/* 242 */         float[][] uv = new float[4][4];
/* 243 */         int[] posUV = get2DOffset(quad.func_178210_d());
/*     */         
/* 245 */         uv[0][0] = quad.func_187508_a().func_94209_e() + posUV[0] * uOffset;
/* 246 */         uv[0][1] = quad.func_187508_a().func_94206_g() + posUV[1] * vOffset;
/*     */         
/* 248 */         uv[1][0] = quad.func_187508_a().func_94209_e() + posUV[0] * uOffset;
/* 249 */         uv[1][1] = quad.func_187508_a().func_94210_h() - (this.size - 1 - posUV[1]) * vOffset;
/*     */         
/* 251 */         uv[2][0] = quad.func_187508_a().func_94212_f() - (this.size - 1 - posUV[0]) * uOffset;
/* 252 */         uv[2][1] = quad.func_187508_a().func_94210_h() - (this.size - 1 - posUV[1]) * vOffset;
/*     */         
/* 254 */         uv[3][0] = quad.func_187508_a().func_94212_f() - (this.size - 1 - posUV[0]) * uOffset;
/* 255 */         uv[3][1] = quad.func_187508_a().func_94206_g() + posUV[1] * vOffset;
/*     */         
/* 257 */         for (int i = 0; i < v.length; i++) {
/* 258 */           v = uv[i];
/* 259 */           LightUtil.pack(v, data, quad.getFormat(), i, 2);
/*     */         } 
/*     */         
/* 262 */         TextureAtlasSprite ap = quad.func_187508_a();
/* 263 */         transQuads.add(new BakedQuad(data, quad.func_178211_c(), quad.func_178210_d(), quad.func_187508_a(), quad.shouldApplyDiffuseLighting(), quad.getFormat()));
/*     */       } 
/* 265 */       return transQuads;
/*     */     }
/*     */ 
/*     */     int[] get2DOffset(Direction dir) {
/* 269 */       int[] uv = new int[2];
/* 270 */       switch (dir) {
/*     */         case DOWN:
/* 272 */           return new int[] { this.pos.func_177958_n(), this.size - 1 - this.pos.func_177952_p() };
/*     */         case EAST:
/* 274 */           return new int[] { this.size - 1 - this.pos.func_177952_p(), this.size - 1 - this.pos.func_177956_o() };
/*     */         case NORTH:
/* 276 */           return new int[] { this.size - 1 - this.pos.func_177958_n(), this.size - 1 - this.pos.func_177956_o() };
/*     */         case SOUTH:
/* 278 */           return new int[] { this.pos.func_177958_n(), this.size - 1 - this.pos.func_177956_o() };
/*     */         case UP:
/* 280 */           return new int[] { this.pos.func_177958_n(), this.pos.func_177952_p() };
/*     */         case WEST:
/* 282 */           return new int[] { this.pos.func_177952_p(), this.size - 1 - this.pos.func_177956_o() };
/*     */       } 
/*     */ 
/*     */       
/* 286 */       return uv;
/*     */     }
/*     */ 
/*     */ 
/*     */     public boolean isAmbientOcclusion(BlockState state) {
/* 291 */       return this.model.isAmbientOcclusion(state);
/*     */     }
/*     */ 
/*     */ 
/*     */     public Pair<? extends IBakedModel, Matrix4f> handlePerspective(ItemCameraTransforms.TransformType cameraTransformType) {
/* 296 */       return this.model.handlePerspective(cameraTransformType);
/*     */     }
/*     */ 
/*     */ 
/*     */     public IModelData getModelData(IEnviromentBlockReader world, BlockPos pos, BlockState state, IModelData tileData) {
/* 301 */       return this.model.getModelData(world, pos, state, tileData);
/*     */     }
/*     */ 
/*     */ 
/*     */     public TextureAtlasSprite getParticleTexture(IModelData data) {
/* 306 */       return this.model.getParticleTexture(data);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   boolean hasPriority(BlockRenderLayer layer) {
/* 312 */     return (layer == BlockRenderLayer.SOLID || layer == BlockRenderLayer.CUTOUT);
/*     */   }
/*     */ 
/*     */   class BB extends BufferBuilder {
/*     */     BufferBuilder buffer;
/*     */     BlockPos innerPos;
/*     */     float offsetSize;
/*     */     
/*     */     public BB() {
/* 321 */       super(0);
/*     */     }
/*     */ 
/*     */ 
/*     */     public int hashCode() {
/* 326 */       return this.buffer.hashCode();
/*     */     }
/*     */ 
/*     */ 
/*     */     public void func_181674_a(float cameraX, float cameraY, float cameraZ) {
/* 331 */       this.buffer.func_181674_a(cameraX, cameraY, cameraZ);
/*     */     }
/*     */ 
/*     */ 
/*     */     public boolean equals(Object obj) {
/* 336 */       return this.buffer.equals(obj);
/*     */     }
/*     */ 
/*     */ 
/*     */     public BufferBuilder.State func_181672_a() {
/* 341 */       return this.buffer.func_181672_a();
/*     */     }
/*     */ 
/*     */ 
/*     */     public void func_178993_a(BufferBuilder.State state) {
/* 346 */       this.buffer.func_178993_a(state);
/*     */     }
/*     */ 
/*     */ 
/*     */     public void func_178965_a() {
/* 351 */       this.buffer.func_178965_a();
/*     */     }
/*     */ 
/*     */ 
/*     */     public void func_181668_a(int glMode, VertexFormat format) {
/* 356 */       this.buffer.func_181668_a(glMode, format);
/*     */     }
/*     */ 
/*     */ 
/*     */     public BufferBuilder func_187315_a(double u, double v) {
/* 361 */       return this.buffer.func_187315_a(u, v);
/*     */     }
/*     */ 
/*     */ 
/*     */     public BufferBuilder func_187314_a(int skyLight, int blockLight) {
/* 366 */       return this.buffer.func_187314_a(skyLight, blockLight);
/*     */     }
/*     */ 
/*     */ 
/*     */     public void func_178962_a(int vertex0, int vertex1, int vertex2, int vertex3) {
/* 371 */       this.buffer.func_178962_a(vertex0, vertex1, vertex2, vertex3);
/*     */     }
/*     */ 
/*     */ 
/*     */     public void func_178987_a(double x, double y, double z) {
/* 376 */       this.buffer.func_178987_a(x - this.innerPos.func_177958_n(), y - this.innerPos.func_177956_o(), z - this.innerPos.func_177952_p());
/*     */     }
/*     */ 
/*     */ 
/*     */     public String toString() {
/* 381 */       return this.buffer.toString();
/*     */     }
/*     */ 
/*     */ 
/*     */     public int func_78909_a(int vertexIndex) {
/* 386 */       return this.buffer.func_78909_a(vertexIndex);
/*     */     }
/*     */ 
/*     */ 
/*     */     public void func_178978_a(float red, float green, float blue, int vertexIndex) {
/* 391 */       this.buffer.func_178978_a(red, green, blue, vertexIndex);
/*     */     }
/*     */ 
/*     */ 
/*     */     public void func_178994_b(float red, float green, float blue, int vertexIndex) {
/* 396 */       this.buffer.func_178994_b(red, green, blue, vertexIndex);
/*     */     }
/*     */ 
/*     */ 
/*     */     public void func_178972_a(int index, int red, int green, int blue) {
/* 401 */       this.buffer.func_178972_a(index, red, green, blue);
/*     */     }
/*     */ 
/*     */ 
/*     */     public void func_78914_f() {
/* 406 */       this.buffer.func_78914_f();
/*     */     }
/*     */ 
/*     */ 
/*     */     public BufferBuilder func_181666_a(float red, float green, float blue, float alpha) {
/* 411 */       return this.buffer.func_181666_a(red, green, blue, alpha);
/*     */     }
/*     */ 
/*     */ 
/*     */     public BufferBuilder func_181669_b(int red, int green, int blue, int alpha) {
/* 416 */       return this.buffer.func_181669_b(red, green, blue, alpha);
/*     */     }
/*     */ 
/*     */ 
/*     */     public void func_178981_a(int[] vertexData) {
/* 421 */       this.buffer.func_178981_a(scale(vertexData, this.offsetSize));
/*     */     }
/*     */ 
/*     */ 
/*     */     public void func_181675_d() {
/* 426 */       this.buffer.func_181675_d();
/*     */     }
/*     */ 
/*     */ 
/*     */     public BufferBuilder func_181662_b(double x, double y, double z) {
/* 431 */       double renderX = (x - this.innerPos.func_177958_n()) * this.offsetSize;
/* 432 */       double renderY = (y - this.innerPos.func_177956_o()) * this.offsetSize;
/* 433 */       double renderZ = (z - this.innerPos.func_177952_p()) * this.offsetSize;
/* 434 */       return this.buffer.func_181662_b(renderX, renderY, renderZ);
/*     */     }
/*     */ 
/*     */ 
/*     */     public void func_178975_e(float x, float y, float z) {
/* 439 */       this.buffer.func_178975_e(x, y, z);
/*     */     }
/*     */ 
/*     */ 
/*     */     public BufferBuilder func_181663_c(float x, float y, float z) {
/* 444 */       return this.buffer.func_181663_c(x, y, z);
/*     */     }
/*     */ 
/*     */ 
/*     */     public void func_178969_c(double x, double y, double z) {
/* 449 */       this.buffer.func_178969_c(x, y, z);
/*     */     }
/*     */ 
/*     */ 
/*     */     public void func_178977_d() {
/* 454 */       this.buffer.func_178977_d();
/*     */     }
/*     */ 
/*     */ 
/*     */     public ByteBuffer func_178966_f() {
/* 459 */       return this.buffer.func_178966_f();
/*     */     }
/*     */ 
/*     */ 
/*     */     public VertexFormat func_178973_g() {
/* 464 */       return this.buffer.func_178973_g();
/*     */     }
/*     */ 
/*     */ 
/*     */     public int func_178989_h() {
/* 469 */       return this.buffer.func_178989_h();
/*     */     }
/*     */ 
/*     */ 
/*     */     public int func_178979_i() {
/* 474 */       return this.buffer.func_178979_i();
/*     */     }
/*     */ 
/*     */ 
/*     */     public void func_178968_d(int argb) {
/* 479 */       this.buffer.func_178968_d(argb);
/*     */     }
/*     */ 
/*     */ 
/*     */     public void func_178990_f(float red, float green, float blue) {
/* 484 */       this.buffer.func_178990_f(red, green, blue);
/*     */     }
/*     */ 
/*     */ 
/*     */     public void putColorRGBA(int index, int red, int green, int blue, int alpha) {
/* 489 */       this.buffer.putColorRGBA(index, red, green, blue, alpha);
/*     */     }
/*     */ 
/*     */ 
/*     */     public boolean isColorDisabled() {
/* 494 */       return this.buffer.isColorDisabled();
/*     */     }
/*     */ 
/*     */ 
/*     */     public void putBulkData(ByteBuffer buffer) {
/* 499 */       this.buffer.putBulkData(buffer);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private int[] scale(int[] v, float s) {
/* 511 */       v[0] = transform(v[0], s);
/* 512 */       v[7] = transform(v[7], s);
/* 513 */       v[14] = transform(v[14], s);
/* 514 */       v[21] = transform(v[21], s);
/*     */       
/* 516 */       v[1] = transform(v[1], s);
/* 517 */       v[8] = transform(v[8], s);
/* 518 */       v[15] = transform(v[15], s);
/* 519 */       v[22] = transform(v[22], s);
/*     */       
/* 521 */       v[2] = transform(v[2], s);
/* 522 */       v[9] = transform(v[9], s);
/* 523 */       v[16] = transform(v[16], s);
/* 524 */       v[23] = transform(v[23], s);
/*     */       
/* 526 */       return v;
/*     */     }
/*     */ 
/*     */     private int transform(int i, float s) {
/* 530 */       float f = Float.intBitsToFloat(i);
/* 531 */       f *= s;
/* 532 */       return Float.floatToRawIntBits(f);
/*     */     }
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 33 ms
	
*/