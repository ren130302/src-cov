/*    */ package com.ruby.meshi.crafting;
/*    */ 
/*    */ import net.minecraft.item.crafting.IRecipeSerializer;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HiganRecipeSerializer
/*    */ {
/* 11 */   public static final IRecipeSerializer<?> GRIND = register("grind", new GrindRecipe.Serializer());
/* 12 */   public static final IRecipeSerializer<?> HEARTH = register("hearth", new HearthRecipe.Serializer());
/* 13 */   public static final IRecipeSerializer<?> HEARTH_SHAPELESS = register("hearth_shapeless", new HearthShapelessRecipe.Serializer());
/*    */ 
/*    */   private static <T extends net.minecraft.item.crafting.IRecipe<?>> IRecipeSerializer<?> register(String key, IRecipeSerializer<T> serializer) {
/* 16 */     return (IRecipeSerializer)serializer.setRegistryName(new ResourceLocation("meshi", key));
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 2 ms
	
*/