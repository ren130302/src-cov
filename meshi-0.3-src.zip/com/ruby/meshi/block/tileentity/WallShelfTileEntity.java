/*     */ package com.ruby.meshi.block.tileentity;
/*     */ 
/*     */ import com.ruby.meshi.init.HiganTileEntityType;
/*     */ import net.minecraft.entity.player.PlayerInventory;
/*     */ import net.minecraft.inventory.ItemStackHelper;
/*     */ import net.minecraft.inventory.container.Container;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.CompoundNBT;
/*     */ import net.minecraft.network.NetworkManager;
/*     */ import net.minecraft.network.play.server.SUpdateTileEntityPacket;
/*     */ import net.minecraft.tileentity.LockableLootTileEntity;
/*     */ import net.minecraft.util.NonNullList;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TranslationTextComponent;
/*     */ 
/*     */ 
/*     */ public class WallShelfTileEntity
/*     */   extends LockableLootTileEntity
/*     */ {
/*     */   public static final byte RIGHT = 0;
/*     */   public static final byte LEFT = 1;
/*     */   public static final byte CENTER = 0;
/*     */   private NonNullList<ItemStack> chestContents;
/*     */   private boolean isDouble;
/*     */   private static final byte TABLE_SIZE = 2;
/*     */   
/*     */   public WallShelfTileEntity() {
/*  28 */     super(HiganTileEntityType.WALL_SHELF);
/*  29 */     this.chestContents = NonNullList.func_191197_a(2, ItemStack.field_190927_a);
/*  30 */     this.isDouble = true;
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_70296_d() {
/*  35 */     super.func_70296_d();
/*     */   }
/*     */ 
/*     */ 
/*     */   public ItemStack func_70304_b(int index) {
/*  40 */     return super.func_70304_b(index);
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_70299_a(int index, ItemStack stack) {
/*  45 */     super.func_70299_a(index, stack);
/*     */   }
/*     */ 
/*     */ 
/*     */   public int func_70302_i_() {
/*  50 */     return func_190576_q().size();
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_191420_l() {
/*  55 */     for (ItemStack itemstack : this.chestContents) {
/*  56 */       if (!itemstack.func_190926_b()) {
/*  57 */         return false;
/*     */       }
/*     */     } 
/*     */     
/*  61 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   protected NonNullList<ItemStack> func_190576_q() {
/*  66 */     return this.chestContents;
/*     */   }
/*     */ 
/*     */ 
/*     */   protected void func_199721_a(NonNullList<ItemStack> itemsIn) {
/*  71 */     this.chestContents = NonNullList.func_191197_a(2, ItemStack.field_190927_a);
/*     */     
/*  73 */     for (int i = 0; i < itemsIn.size(); i++) {
/*  74 */       if (i < this.chestContents.size()) {
/*  75 */         func_190576_q().set(i, itemsIn.get(i));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   protected ITextComponent func_213907_g() {
/*  82 */     return (ITextComponent)new TranslationTextComponent(String.join(".", new CharSequence[] { "container", "meshi", func_195044_w().func_177230_c().getRegistryName().func_110623_a() }), new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */   protected Container func_213906_a(int p_213906_1_, PlayerInventory p_213906_2_) {
/*  87 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_145839_a(CompoundNBT compound) {
/*  92 */     super.func_145839_a(compound);
/*  93 */     readAddtionalData(compound);
/*     */   }
/*     */ 
/*     */   void readAddtionalData(CompoundNBT compound) {
/*  97 */     this.chestContents = NonNullList.func_191197_a(func_70302_i_(), ItemStack.field_190927_a);
/*  98 */     if (!func_184283_b(compound)) {
/*  99 */       ItemStackHelper.func_191283_b(compound, this.chestContents);
/*     */     }
/* 101 */     if (compound.func_74764_b("isDouble")) {
/* 102 */       this.isDouble = compound.func_74767_n("isDouble");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   public CompoundNBT func_189515_b(CompoundNBT compound) {
/* 108 */     super.func_189515_b(compound);
/* 109 */     writeAdditionalData(compound);
/* 110 */     return compound;
/*     */   }
/*     */ 
/*     */   CompoundNBT writeAdditionalData(CompoundNBT compound) {
/* 114 */     if (!func_184282_c(compound)) {
/* 115 */       ItemStackHelper.func_191282_a(compound, this.chestContents);
/*     */     }
/* 117 */     compound.func_74757_a("isDouble", this.isDouble);
/* 118 */     return compound;
/*     */   }
/*     */ 
/*     */   public void setSingleMode() {
/* 122 */     this.isDouble = false;
/*     */   }
/*     */ 
/*     */   public boolean isDouble() {
/* 126 */     return this.isDouble;
/*     */   }
/*     */ 
/*     */   public boolean hasItem(byte side) {
/* 130 */     return !((ItemStack)this.chestContents.get(side)).func_190926_b();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleUpdateTag(CompoundNBT tag) {
/* 136 */     super.handleUpdateTag(tag);
/* 137 */     readAddtionalData(tag);
/*     */   }
/*     */ 
/*     */ 
/*     */   public CompoundNBT func_189517_E_() {
/* 142 */     CompoundNBT tag = super.func_189517_E_();
/* 143 */     writeAdditionalData(tag);
/* 144 */     return tag;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onDataPacket(NetworkManager net, SUpdateTileEntityPacket pkt) {
/* 150 */     readAddtionalData(pkt.func_148857_g());
/*     */   }
/*     */ 
/*     */ 
/*     */   public SUpdateTileEntityPacket func_189518_D_() {
/* 155 */     CompoundNBT var1 = new CompoundNBT();
/* 156 */     writeAdditionalData(var1);
/* 157 */     return new SUpdateTileEntityPacket(func_174877_v(), 5, var1);
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 8 ms
	
*/