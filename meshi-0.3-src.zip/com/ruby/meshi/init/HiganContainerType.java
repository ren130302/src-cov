/*    */ package com.ruby.meshi.init;
/*    */ 
/*    */ import com.ruby.meshi.common.inventory.CollectorPressurePlateContainer;
/*    */ import com.ruby.meshi.common.inventory.ExtendInventoryContainer;
/*    */ import com.ruby.meshi.common.inventory.FukuroContainer;
/*    */ import com.ruby.meshi.common.inventory.HearthContainer;
/*    */ import com.ruby.meshi.common.inventory.MillstoneContainer;
/*    */ import net.minecraft.client.gui.ScreenManager;
/*    */ import net.minecraft.entity.player.PlayerInventory;
/*    */ import net.minecraft.inventory.container.Container;
/*    */ import net.minecraft.inventory.container.ContainerType;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ import net.minecraftforge.fml.network.IContainerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HiganContainerType
/*    */ {
/* 24 */   public static final ContainerType<CollectorPressurePlateContainer> COLLECTOR_PLATE = create("collector_pressure_plate", CollectorPressurePlateContainer::new);
/* 25 */   public static final ContainerType<MillstoneContainer> MILLSTONE = create("millstone", MillstoneContainer::new);
/* 26 */   public static final ContainerType<HearthContainer> HEARTH = create("hearth", HearthContainer::new);
/* 27 */   public static final ContainerType<FukuroContainer> FUKURO = create("fukuro", FukuroContainer::new);
/* 28 */   public static final ContainerType<ExtendInventoryContainer> EXTEND_INVENTORY = create("extend_inventory", ExtendInventoryContainer::new);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private static <T extends Container> ContainerType<T> create(String key, IFactory<T> factory) {
/* 38 */     IContainerFactory<T> fact = (windowId, inv, data) -> factory.create(windowId, inv);
/* 39 */     return (ContainerType<T>)(new ContainerType((ContainerType.IFactory)fact)).setRegistryName("meshi", key);
/*    */   }
/*    */ 
/*    */ 
/*    */   public static void registerScreenFactories() {
/* 44 */     ScreenManager.func_216911_a(COLLECTOR_PLATE, com.ruby.meshi.client.inventory.CollectorPressurePlateScreen::new);
/* 45 */     ScreenManager.func_216911_a(MILLSTONE, com.ruby.meshi.client.inventory.MillstoneScreen::new);
/* 46 */     ScreenManager.func_216911_a(HEARTH, com.ruby.meshi.client.inventory.HearthScreen::new);
/* 47 */     ScreenManager.func_216911_a(FUKURO, com.ruby.meshi.client.inventory.FukuroScreen::new);
/* 48 */     ScreenManager.func_216911_a(EXTEND_INVENTORY, com.ruby.meshi.client.inventory.ExtendInventoryScreen::new);
/*    */   }
/*    */   
/*    */   public static interface IFactory<T extends Container> {
/*    */     T create(int param1Int, PlayerInventory param1PlayerInventory);
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 4 ms
	
*/