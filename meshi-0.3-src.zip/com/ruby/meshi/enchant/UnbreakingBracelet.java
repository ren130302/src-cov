/*    */ package com.ruby.meshi.enchant;
/*    */ 
/*    */ import net.minecraft.enchantment.Enchantment;
/*    */ import net.minecraft.enchantment.EnchantmentType;
/*    */ import net.minecraft.enchantment.Enchantments;
/*    */ import net.minecraft.inventory.EquipmentSlotType;
/*    */ import net.minecraft.util.text.ITextComponent;
/*    */ 
/*    */ public class UnbreakingBracelet
/*    */   extends Enchantment {
/*    */   protected UnbreakingBracelet(Enchantment.Rarity rarityIn, EnchantmentType typeIn, EquipmentSlotType... slots) {
/* 12 */     super(rarityIn, typeIn, slots);
/*    */   }
/*    */ 
/*    */ 
/*    */   public int func_77321_a(int enchantmentLevel) {
/* 17 */     return 5 + (enchantmentLevel - 1) * 40;
/*    */   }
/*    */ 
/*    */ 
/*    */   public int func_223551_b(int enchantmentLevel) {
/* 22 */     return super.func_77321_a(enchantmentLevel) + (func_77325_b() - enchantmentLevel + 1) * 15;
/*    */   }
/*    */ 
/*    */ 
/*    */   public int func_77325_b() {
/* 27 */     return 3;
/*    */   }
/*    */ 
/*    */ 
/*    */   public boolean isAllowedOnBooks() {
/* 32 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   public ITextComponent func_200305_d(int level) {
/* 37 */     return Enchantments.field_185307_s.func_200305_d(level);
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 1 ms
	
*/