package com.ruby.meshi.init;

import com.ruby.meshi.init.SakuraConfig.Client;
import java.util.function.Function;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.common.ForgeConfigSpec.Builder;
import org.apache.commons.lang3.tuple.Pair;

public class SakuraConfig {
   public static final ForgeConfigSpec clientSpec;
   public static final Client CLIENT;

   static {
      Pair<Client, ForgeConfigSpec> specPair = (new Builder()).configure(Client::new);
      clientSpec = (ForgeConfigSpec)specPair.getRight();
      CLIENT = (Client)specPair.getLeft();
   }
}