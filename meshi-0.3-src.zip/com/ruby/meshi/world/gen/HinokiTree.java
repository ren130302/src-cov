/*    */ package com.ruby.meshi.world.gen;
/*    */ 
/*    */ import java.util.Random;
/*    */ import net.minecraft.block.trees.Tree;
/*    */ import net.minecraft.world.gen.feature.AbstractTreeFeature;
/*    */ import net.minecraft.world.gen.feature.NoFeatureConfig;
/*    */ 
/*    */ 
/*    */ public class HinokiTree
/*    */   extends Tree
/*    */ {
/*    */   protected AbstractTreeFeature<NoFeatureConfig> func_196936_b(Random random) {
/* 13 */     return new HinokiTreeFeature(NoFeatureConfig::func_214639_a, true);
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 1 ms
	
*/