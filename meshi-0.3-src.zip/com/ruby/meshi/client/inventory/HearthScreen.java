/*     */ package com.ruby.meshi.client.inventory;
/*     */ import com.ruby.meshi.common.inventory.HearthContainer;
/*     */ import net.minecraft.client.gui.IGuiEventListener;
/*     */ import net.minecraft.client.gui.recipebook.IRecipeShownListener;
/*     */ import net.minecraft.client.gui.recipebook.RecipeBookGui;
/*     */ import net.minecraft.client.gui.screen.inventory.ContainerScreen;
/*     */ import net.minecraft.client.gui.widget.Widget;
/*     */ import net.minecraft.client.gui.widget.button.Button;
/*     */ import net.minecraft.client.gui.widget.button.ImageButton;
/*     */ import net.minecraft.entity.player.PlayerInventory;
/*     */ import net.minecraft.inventory.container.ClickType;
/*     */ import net.minecraft.inventory.container.Container;
/*     */ import net.minecraft.inventory.container.Slot;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ 
/*     */ public class HearthScreen extends ContainerScreen<HearthContainer> implements IRecipeShownListener {
/*  18 */   private static final ResourceLocation BOOK_BUTTON = new ResourceLocation("textures/gui/recipe_button.png");
/*  19 */   private static final ResourceLocation TEXTURE = new ResourceLocation("meshi", "textures/guis/hearth.png");
/*     */ 
/*     */ 
/*     */ 
/*     */   public HearthScreen(HearthContainer screenContainer, PlayerInventory inv, ITextComponent titleIn) {
/*  24 */     super((Container)screenContainer, inv, titleIn);
/*  25 */     this.book = new RecipeBookGui();
/*     */   }
/*     */ 
/*     */ 
/*     */   public void init() {
/*  30 */     super.init();
/*  31 */     this.widthTooNarrow = (this.width < 379);
/*  32 */     this.book.func_201520_a(this.width, this.height, this.minecraft, this.widthTooNarrow, (RecipeBookContainer)this.field_147002_h);
/*  33 */     this.field_147003_i = this.book.func_193011_a(this.widthTooNarrow, this.width, this.field_146999_f);
/*  34 */     this.children.add(this.book);
/*  35 */     func_212928_a((IGuiEventListener)this.book);
/*     */     
/*  37 */     addButton((Widget)new ImageButton(this.field_147003_i + 5, this.height / 2 - 49, 20, 18, 0, 0, 19, BOOK_BUTTON, button -> {
/*     */             this.book.func_201518_a(this.widthTooNarrow);
/*     */             this.book.func_191866_a();
/*     */             this.field_147003_i = this.book.func_193011_a(this.widthTooNarrow, this.width, this.field_146999_f);
/*     */             ((ImageButton)button).func_191746_c(this.field_147003_i + 5, this.height / 2 - 49);
/*     */           }));
/*     */   }
/*     */ 
/*     */ 
/*     */   public void render(int mouseX, int mouseY, float partialTicks) {
/*  47 */     renderBackground();
/*  48 */     if (this.book.func_191878_b() && this.widthTooNarrow) {
/*  49 */       func_146976_a(partialTicks, mouseX, mouseY);
/*  50 */       this.book.render(mouseX, mouseY, partialTicks);
/*     */     } else {
/*  52 */       this.book.render(mouseX, mouseY, partialTicks);
/*  53 */       super.render(mouseX, mouseY, partialTicks);
/*  54 */       this.book.func_191864_a(this.field_147003_i, this.field_147009_r, true, partialTicks);
/*     */     } 
/*     */     
/*  57 */     func_191948_b(mouseX, mouseY);
/*  58 */     this.book.func_191876_c(this.field_147003_i, this.field_147009_r, mouseX, mouseY);
/*  59 */     func_212932_b((IGuiEventListener)this.book);
/*     */   }
/*     */ 
/*     */ 
/*     */   protected void func_146979_b(int mouseX, int mouseY) {
/*  64 */     this.font.func_211126_b(this.title.func_150254_d(), 8.0F, 6.0F, 4210752);
/*     */     
/*  66 */     this.font.func_211126_b(this.field_213127_e.func_145748_c_().func_150254_d(), 8.0F, (this.field_147000_g - 96 + 2), 4210752);
/*     */   }
/*     */ 
/*     */ 
/*     */   protected void func_146976_a(float partialTicks, int mouseX, int mouseY) {
/*  71 */     GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  72 */     this.minecraft.func_110434_K().func_110577_a(TEXTURE);
/*  73 */     int k = this.field_147003_i;
/*  74 */     int l = this.field_147009_r;
/*  75 */     blit(k, l, 0, 0, this.field_146999_f, this.field_147000_g);
/*  76 */     blit(k + 90, l + 35, 176, 0, 23 - (int)(23.0F * progress()), 16);
/*     */   }
/*     */ 
/*     */   private float progress() {
/*  80 */     int total = ((HearthContainer)func_212873_a_()).getCooktime();
/*  81 */     int now = ((HearthContainer)func_212873_a_()).getProgress();
/*  82 */     if (total == 0 || now < 0) {
/*  83 */       return 1.0F;
/*     */     }
/*  85 */     return ((HearthContainer)func_212873_a_()).getProgress() / ((HearthContainer)func_212873_a_()).getCooktime();
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean mouseClicked(double p_mouseClicked_1_, double p_mouseClicked_3_, int p_mouseClicked_5_) {
/*  90 */     if (this.book.mouseClicked(p_mouseClicked_1_, p_mouseClicked_3_, p_mouseClicked_5_)) {
/*  91 */       return true;
/*     */     }
/*  93 */     return (this.widthTooNarrow && this.book.func_191878_b()) ? true : super.mouseClicked(p_mouseClicked_1_, p_mouseClicked_3_, p_mouseClicked_5_);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void func_184098_a(Slot slotIn, int slotId, int mouseButton, ClickType type) {
/*  99 */     super.func_184098_a(slotIn, slotId, mouseButton, type);
/* 100 */     this.book.func_191874_a(slotIn);
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean keyPressed(int p_keyPressed_1_, int p_keyPressed_2_, int p_keyPressed_3_) {
/* 105 */     return this.book.keyPressed(p_keyPressed_1_, p_keyPressed_2_, p_keyPressed_3_) ? false : super.keyPressed(p_keyPressed_1_, p_keyPressed_2_, p_keyPressed_3_);
/*     */   }
/*     */ 
/*     */ 
/*     */   protected boolean func_195361_a(double p_195361_1_, double p_195361_3_, int p_195361_5_, int p_195361_6_, int p_195361_7_) {
/* 110 */     boolean lvt_8_1_ = (p_195361_1_ < p_195361_5_ || p_195361_3_ < p_195361_6_ || p_195361_1_ >= (p_195361_5_ + this.field_146999_f) || p_195361_3_ >= (p_195361_6_ + this.field_147000_g));
/* 111 */     return (this.book.func_195604_a(p_195361_1_, p_195361_3_, this.field_147003_i, this.field_147009_r, this.field_146999_f, this.field_147000_g, p_195361_7_) && lvt_8_1_);
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean charTyped(char p_charTyped_1_, int p_charTyped_2_) {
/* 116 */     return this.book.charTyped(p_charTyped_1_, p_charTyped_2_) ? true : super.charTyped(p_charTyped_1_, p_charTyped_2_);
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_192043_J_() {
/* 121 */     this.book.func_193948_e();
/*     */   }
/*     */ 
/*     */ 
/*     */   public RecipeBookGui func_194310_f() {
/* 126 */     return this.book;
/*     */   }
/*     */ 
/*     */ 
/*     */   public void removed() {
/* 131 */     this.book.func_191871_c();
/* 132 */     super.removed();
/*     */   }
/*     */ 
/*     */ 
/*     */   public void tick() {
/* 137 */     super.tick();
/* 138 */     this.book.func_193957_d();
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 15 ms
	
*/