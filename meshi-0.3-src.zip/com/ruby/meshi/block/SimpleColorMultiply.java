// Warning: No line numbers available in class file
/*  */ package com.ruby.meshi.block;
/*  */ 
/*  */ import net.minecraft.item.DyeColor;
/*  */ 
/*  */ public interface SimpleColorMultiply<T> {
/*  */   int getColorCode();
/*  */   
/*  */   T setColorCode(DyeColor paramDyeColor);
/*  */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 0 ms
	
*/