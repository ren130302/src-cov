/*     */ package com.ruby.meshi.block.tileentity;
/*     */ 
/*     */ import com.ruby.meshi.block.Hearth;
/*     */ import com.ruby.meshi.common.inventory.HearthContainer;
/*     */ import com.ruby.meshi.crafting.CookingTimerRecipe;
/*     */ import com.ruby.meshi.crafting.HearthRecipe;
/*     */ import com.ruby.meshi.crafting.HearthShapelessRecipe;
/*     */ import com.ruby.meshi.init.HiganTileEntityType;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.Random;
/*     */ import java.util.concurrent.ThreadLocalRandom;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.IntStream;
/*     */ import java.util.stream.Stream;
/*     */ import net.minecraft.block.BlockState;
/*     */ import net.minecraft.enchantment.Enchantment;
/*     */ import net.minecraft.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.enchantment.Enchantments;
/*     */ import net.minecraft.entity.player.PlayerEntity;
/*     */ import net.minecraft.entity.player.PlayerInventory;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.IRecipeHelperPopulator;
/*     */ import net.minecraft.inventory.ItemStackHelper;
/*     */ import net.minecraft.inventory.container.Container;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.TieredItem;
/*     */ import net.minecraft.item.crafting.AbstractCookingRecipe;
/*     */ import net.minecraft.item.crafting.FurnaceRecipe;
/*     */ import net.minecraft.item.crafting.IRecipe;
/*     */ import net.minecraft.item.crafting.IRecipeType;
/*     */ import net.minecraft.item.crafting.RecipeItemHelper;
/*     */ import net.minecraft.nbt.CompoundNBT;
/*     */ import net.minecraft.nbt.INBT;
/*     */ import net.minecraft.nbt.ListNBT;
/*     */ import net.minecraft.network.NetworkManager;
/*     */ import net.minecraft.network.play.server.SUpdateTileEntityPacket;
/*     */ import net.minecraft.particles.BasicParticleType;
/*     */ import net.minecraft.particles.IParticleData;
/*     */ import net.minecraft.particles.ParticleTypes;
/*     */ import net.minecraft.state.IProperty;
/*     */ import net.minecraft.tileentity.ITickableTileEntity;
/*     */ import net.minecraft.tileentity.LockableTileEntity;
/*     */ import net.minecraft.util.IntArray;
/*     */ import net.minecraft.util.NonNullList;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TranslationTextComponent;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.server.ServerWorld;
/*     */ 
/*     */ public class HearthTileEntity
/*     */   extends LockableTileEntity
/*     */   implements ITickableTileEntity, IRecipeHelperPopulator
/*     */ {
/*     */   private NonNullList<ItemStack> contents;
/*     */   public static final int INV_SIZE = 10;
/*  60 */   public static final int[] INPUT_SLOT = IntStream.range(1, 10).toArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  69 */   private static FurnaceInventory furnaceInv = new FurnaceInventory();
/*  70 */   public static final ThreadLocalRandom rand = ThreadLocalRandom.current();
/*     */ 
/*     */   public HearthTileEntity() {
/*  73 */     super(HiganTileEntityType.HEARTH);
/*  74 */     this.contents = NonNullList.func_191197_a(func_70302_i_(), ItemStack.field_190927_a);
/*  75 */     this.next_roll = (float)Math.random();
/*  76 */     reset();
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_73660_a() {
/*  81 */     int magnification = 1;
/*  82 */     if (!(func_145831_w()).field_72995_K) {
/*  83 */       if (this.progress <= 0) {
/*  84 */         if (canCooking()) {
/*  85 */           this.progress = getCookTime();
/*  86 */           func_70296_d();
/*     */         } 
/*     */       } else {
/*  89 */         this.progress -= magnification;
/*  90 */         if (this.progress <= 0) {
/*  91 */           cookItem();
/*  92 */           reset();
/*  93 */           func_70296_d();
/*     */         } 
/*     */       } 
/*     */     } else {
/*  97 */       this.now_roll = this.next_roll;
/*  98 */       if (this.next_roll >= 6.283185307179586D) {
/*  99 */         this.next_roll = this.now_roll = 0.017453292F;
/*     */       }
/* 101 */       this.next_roll += 0.017453292F;
/*     */     } 
/*     */   }
/*     */ 
/*     */   private void cookItem() {
/* 106 */     if (!isInputEmpty()) {
/* 107 */       Optional<? extends IRecipe<? extends IInventory>> recipe = (Optional)getRecipe();
/* 108 */       if (recipe.isPresent()) {
/* 109 */         ItemStack output = ((IRecipe)recipe.get()).func_77571_b().func_77946_l();
/*     */         
/* 111 */         if (hasEnchantRecipe(((IRecipe)recipe.get()).func_199560_c())) {
/* 112 */           output = enchantReBuild((ItemStack)this.contents.get(2), (ItemStack)this.contents.get(8));
/*     */         }
/*     */ 
/*     */         
/* 116 */         boolean crit = false;
/* 117 */         if (output.func_190916_E() > 1) {
/* 118 */           crit = rand.nextBoolean();
/*     */         }
/* 120 */         else if (output.func_77976_d() > 1) {
/* 121 */           crit = (rand.nextFloat() < 0.2F);
/*     */         } 
/*     */         
/* 124 */         BasicParticleType basicParticleType = ParticleTypes.field_197613_f;
/* 125 */         if (crit) {
/* 126 */           int count = output.func_190916_E();
/* 127 */           if (count < output.func_77976_d()) {
/* 128 */             output.func_190920_e(count + 1);
/*     */           }
/* 130 */           basicParticleType = ParticleTypes.field_197632_y;
/*     */         } 
/* 132 */         double d0 = 0.25D;
/* 133 */         double d1 = rand.nextGaussian() * 0.02D;
/* 134 */         double d2 = 0.25D;
/* 135 */         ((ServerWorld)func_145831_w()).func_195598_a((IParticleData)basicParticleType, this.field_174879_c.func_177958_n() + 0.5D, this.field_174879_c.func_177956_o() + 0.75D, this.field_174879_c.func_177952_p() + 0.5D, 8, d0, d1, d2, 0.0D);
/*     */         
/* 137 */         insertInventorySlotContents(0, output);
/*     */         
/* 139 */         Arrays.stream(INPUT_SLOT).forEach(i -> func_70298_a(i, 1));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   public static boolean hasEnchantRecipe(ResourceLocation resourceLocation) {
/* 145 */     return resourceLocation.toString().matches("meshi:hearth/enchant_.*");
/*     */   }
/*     */ 
/*     */   private void reset() {
/* 149 */     this.progress = -1;
/*     */   }
/*     */ 
/*     */   private void setParts(ItemStack stack) {
/* 153 */     func_145831_w().func_175656_a(this.field_174879_c, (BlockState)func_195044_w().func_206870_a((IProperty)Hearth.TYPE, Hearth.HearthStateType.getType(stack)));
/*     */   }
/*     */ 
/*     */   private void removeParts() {
/* 157 */     func_145831_w().func_175656_a(this.field_174879_c, (BlockState)func_195044_w().func_206870_a((IProperty)Hearth.TYPE, Hearth.HearthStateType.NONE));
/*     */   }
/*     */ 
/*     */   public void insertInventorySlotContents(int index, ItemStack insertStack) {
/* 161 */     if (insertStack == null || insertStack.func_190926_b()) {
/*     */       return;
/*     */     }
/* 164 */     if (isSlotEmpty(index)) {
/* 165 */       func_70299_a(index, insertStack);
/* 166 */     } else if (func_70301_a(index).func_77969_a(insertStack)) {
/* 167 */       ItemStack stack = (ItemStack)this.contents.get(index);
/* 168 */       stack.func_190920_e(stack.func_190916_E() + insertStack.func_190916_E());
/* 169 */       if (stack.func_190916_E() > func_70297_j_()) {
/* 170 */         stack.func_190920_e(func_70297_j_());
/*     */       }
/* 172 */       func_70296_d();
/*     */     } 
/*     */   }
/*     */ 
/*     */   private boolean canCooking() {
/* 177 */     if (isInputEmpty()) {
/* 178 */       return false;
/*     */     }
/* 180 */     return isExistenceRacipe(getRecipe());
/*     */   }
/*     */ 
/*     */ 
/*     */   private boolean isExistenceRacipe(Optional<? extends IRecipe<?>> optional) {
/* 185 */     if (optional.isPresent()) {
/* 186 */       ItemStack output = ((IRecipe)optional.get()).func_77571_b();
/* 187 */       return hasInsert(0, output);
/*     */     } 
/* 189 */     return false;
/*     */   }
/*     */ 
/*     */   public Optional<? extends IRecipe<?>> getRecipe() {
/* 193 */     Optional<? extends IRecipe<?>> recipe = (Optional)getSmeltingRecipe();
/* 194 */     if (isExistenceRacipe(recipe)) {
/* 195 */       return recipe;
/*     */     }
/* 197 */     recipe = getRecipe((IRecipeType)HearthShapelessRecipe.TYPE, this, func_145831_w());
/* 198 */     if (isExistenceRacipe(recipe)) {
/* 199 */       return recipe;
/*     */     }
/* 201 */     return (Optional)getRecipe(HearthRecipe.TYPE, this, func_145831_w());
/*     */   }
/*     */ 
/*     */   public int getCookTime() {
/* 205 */     return ((Integer)getRecipe().filter(r -> r instanceof CookingTimerRecipe).map(r -> Integer.valueOf(((CookingTimerRecipe)r).getCookTime())).orElse(Integer.valueOf(getSmeltingTime()))).intValue();
/*     */   }
/*     */ 
/*     */   private boolean hasInsert(int slot, ItemStack stack) {
/* 209 */     if (isSlotEmpty(slot)) {
/* 210 */       return true;
/*     */     }
/* 212 */     if (stack == null || stack.func_190926_b() || !func_70301_a(slot).func_77969_a(stack)) {
/* 213 */       return false;
/*     */     }
/* 215 */     int outResult = func_70301_a(slot).func_190916_E() + stack.func_190916_E();
/* 216 */     return (outResult <= func_70297_j_() && outResult <= stack.func_77976_d());
/*     */   }
/*     */ 
/*     */   private boolean isInputEmpty() {
/* 220 */     return Arrays.stream(INPUT_SLOT).allMatch(this::isSlotEmpty);
/*     */   }
/*     */ 
/*     */   private boolean isSlotEmpty(int slot) {
/* 224 */     return ((ItemStack)this.contents.get(slot)).func_190926_b();
/*     */   }
/*     */ 
/*     */   public Optional<? extends FurnaceRecipe> getSmeltingRecipe() {
/* 228 */     return getRecipe(IRecipeType.field_222150_b, furnaceInv.setDummyStack(getInputStream()), func_145831_w());
/*     */   }
/*     */ 
/*     */   public int getSmeltingTime() {
/* 232 */     return ((Integer)getSmeltingRecipe().<Integer>map(AbstractCookingRecipe::func_222137_e).orElse(Integer.valueOf(200))).intValue() * 4;
/*     */   }
/*     */ 
/*     */   public <T extends IRecipe<U>, U extends IInventory> Optional<T> getRecipe(IRecipeType<T> type, U inv, World world) {
/* 236 */     return func_145831_w().func_199532_z().func_215371_a(type, (IInventory)inv, world);
/*     */   }
/*     */ 
/*     */ 
/*     */   public int func_70302_i_() {
/* 241 */     return 10;
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_191420_l() {
/* 246 */     return this.contents.stream().allMatch(ItemStack::func_190926_b);
/*     */   }
/*     */ 
/*     */ 
/*     */   public ItemStack func_70301_a(int index) {
/* 251 */     return (ItemStack)this.contents.get(index);
/*     */   }
/*     */ 
/*     */ 
/*     */   public ItemStack func_70298_a(int index, int count) {
/* 256 */     ItemStack itemstack = ItemStackHelper.func_188382_a((List)this.contents, index, count);
/* 257 */     if (!itemstack.func_190926_b()) {
/* 258 */       func_70296_d();
/*     */     }
/* 260 */     if (isInputSlotNum(index) && 
/* 261 */       !canCooking()) {
/* 262 */       reset();
/*     */     }
/*     */ 
/*     */     
/* 266 */     return itemstack;
/*     */   }
/*     */ 
/*     */ 
/*     */   public ItemStack func_70304_b(int index) {
/* 271 */     return ItemStackHelper.func_188383_a((List)this.contents, index);
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_70299_a(int index, ItemStack stack) {
/* 276 */     if (isInputSlotNum(index) && 
/* 277 */       !func_70301_a(index).func_77969_a(stack)) {
/* 278 */       reset();
/*     */     }
/*     */     
/* 281 */     this.contents.set(index, stack);
/* 282 */     if (stack.func_190916_E() > func_70297_j_()) {
/* 283 */       stack.func_190920_e(func_70297_j_());
/*     */     }
/*     */     
/* 286 */     if (canCooking()) {
/* 287 */       setParts(((IRecipe)getRecipe().get()).func_77571_b());
/* 288 */     } else if (func_70301_a(0).func_190926_b() && 
/* 289 */       func_195044_w().func_177229_b((IProperty)Hearth.TYPE) != Hearth.HearthStateType.NONE) {
/* 290 */       removeParts();
/*     */     } 
/*     */ 
/*     */     
/* 294 */     func_70296_d();
/*     */   }
/*     */ 
/*     */   public boolean isInputSlotNum(int slot) {
/* 298 */     return (slot >= INPUT_SLOT[0] && slot <= INPUT_SLOT[INPUT_SLOT.length - 1]);
/*     */   }
/*     */ 
/*     */ 
/*     */   public boolean func_70300_a(PlayerEntity player) {
/* 303 */     if (this.field_145850_b.func_175625_s(this.field_174879_c) != this) {
/* 304 */       return false;
/*     */     }
/* 306 */     return (player.func_70092_e(this.field_174879_c.func_177958_n() + 0.5D, this.field_174879_c.func_177956_o() + 0.5D, this.field_174879_c.func_177952_p() + 0.5D) <= 64.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   public void func_174888_l() {
/* 312 */     this.contents.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */   protected ITextComponent func_213907_g() {
/* 317 */     return (ITextComponent)new TranslationTextComponent(String.join(".", new CharSequence[] { "container", "meshi", func_195044_w().func_177230_c().getRegistryName().func_110623_a() }), new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */   protected Container func_213906_a(int id, PlayerInventory player) {
/* 322 */     IntArray intArray = new IntArray(2);
/* 323 */     intArray.func_221477_a(0, this.progress);
/* 324 */     intArray.func_221477_a(1, getCookTime());
/* 325 */     return (Container)new HearthContainer(id, player, this, intArray);
/*     */   }
/*     */ 
/*     */ 
/*     */   public void handleUpdateTag(CompoundNBT tag) {
/* 330 */     super.handleUpdateTag(tag);
/* 331 */     readData(tag);
/*     */   }
/*     */ 
/*     */ 
/*     */   public CompoundNBT func_189517_E_() {
/* 336 */     CompoundNBT tag = super.func_189517_E_();
/* 337 */     writeData(tag);
/* 338 */     return tag;
/*     */   }
/*     */ 
/*     */ 
/*     */   public void onDataPacket(NetworkManager net, SUpdateTileEntityPacket pkt) {
/* 343 */     readData(pkt.func_148857_g());
/*     */   }
/*     */ 
/*     */ 
/*     */   public SUpdateTileEntityPacket func_189518_D_() {
/* 348 */     CompoundNBT var1 = new CompoundNBT();
/* 349 */     writeData(var1);
/* 350 */     return new SUpdateTileEntityPacket(func_174877_v(), 5, var1);
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_145839_a(CompoundNBT compound) {
/* 355 */     super.func_145839_a(compound);
/* 356 */     this.contents = NonNullList.func_191197_a(func_70302_i_(), ItemStack.field_190927_a);
/* 357 */     readData(compound);
/*     */   }
/*     */ 
/*     */ 
/*     */   public CompoundNBT func_189515_b(CompoundNBT compound) {
/* 362 */     super.func_189515_b(compound);
/* 363 */     return writeData(compound);
/*     */   }
/*     */ 
/*     */   public void readData(CompoundNBT compound) {
/* 367 */     ItemStackHelper.func_191283_b(compound, this.contents);
/* 368 */     this.progress = compound.func_74762_e("progress");
/*     */   }
/*     */ 
/*     */   public CompoundNBT writeData(CompoundNBT compound) {
/* 372 */     ItemStackHelper.func_191282_a(compound, this.contents);
/* 373 */     compound.func_74768_a("progress", this.progress);
/* 374 */     return compound;
/*     */   }
/*     */ 
/*     */   public int getProgress() {
/* 378 */     return this.progress;
/*     */   }
/*     */ 
/*     */   private static class FurnaceInventory
/*     */     implements IInventory {
/* 383 */     private ItemStack stack = ItemStack.field_190927_a;
/*     */ 
/*     */     public IInventory setDummyStack(Stream<ItemStack> stream) {
/* 386 */       List<ItemStack> list = (List<ItemStack>)stream.filter(is -> !is.func_190926_b()).collect(Collectors.toList());
/* 387 */       if (list.size() == 1) {
/* 388 */         this.stack = list.get(0);
/*     */       } else {
/* 390 */         this.stack = ItemStack.field_190927_a;
/*     */       } 
/* 392 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */     public ItemStack func_70301_a(int index) {
/* 397 */       return this.stack;
/*     */     }
/*     */ 
/*     */ 
/*     */     public int func_70302_i_() {
/* 402 */       return 3;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean func_191420_l() {
/* 411 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     public ItemStack func_70298_a(int index, int count) {
/* 416 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     public ItemStack func_70304_b(int index) {
/* 421 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean func_70300_a(PlayerEntity player) {
/* 434 */       return true;
/*     */     }
/*     */     
/*     */     private FurnaceInventory() {} }
/*     */ 
/*     */   public void func_194018_a(RecipeItemHelper helper) {
/* 440 */     getInputStream().forEach(helper::func_195932_a);
/*     */   }
/*     */ 
/*     */   private Stream<ItemStack> getInputStream() {
/* 444 */     return Arrays.stream(INPUT_SLOT).mapToObj(this.contents::get);
/*     */   }
/*     */ 
/*     */ 
/*     */   private ItemStack enchantReBuild(ItemStack base, ItemStack parts) {
/* 449 */     String KEY_ENCHANTMENTS = "Enchantments";
/* 450 */     Random rand = func_145831_w().func_201674_k();
/* 451 */     ItemStack stack = base.func_77946_l();
/*     */     
/* 453 */     stack.func_196085_b(0);
/*     */     
/* 455 */     ItemStack baseCopy = base.func_77946_l();
/* 456 */     ItemStack partsCopy = parts.func_77946_l();
/* 457 */     ListNBT baseEnc = base.func_77986_q();
/* 458 */     ListNBT partsEnc = parts.func_77986_q();
/*     */ 
/*     */     
/* 461 */     int baseTier = getEncCount(base);
/* 462 */     int partsTier = getEncCount(parts);
/*     */     
/* 464 */     partsCopy.func_196082_o().func_218657_a(KEY_ENCHANTMENTS, (INBT)subListNBT(partsEnc, 0, partsTier));
/* 465 */     Map<Enchantment, Integer> baseEncMap = EnchantmentHelper.func_82781_a(baseCopy);
/* 466 */     Map<Enchantment, Integer> partsEncMap = EnchantmentHelper.func_82781_a(partsCopy);
/*     */     
/* 468 */     if (partsEnc.isEmpty())
/* 469 */       return stack; 
/* 470 */     if (baseEnc.isEmpty()) {
/* 471 */       EnchantmentHelper.func_82782_a(partsEncMap, stack);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 477 */       int materialTier = Math.max(0, Math.min(baseTier, partsTier) - 1);
/* 478 */       for (Map.Entry<Enchantment, Integer> entry : partsEncMap.entrySet()) {
/* 479 */         int maxLV = ((Enchantment)entry.getKey()).func_77325_b();
/* 480 */         baseEncMap.merge(entry.getKey(), entry.getValue(), (b, p) -> Integer.valueOf((maxLV > 1) ? Math.min(maxLV + materialTier, calcMergeLv(b.intValue(), p.intValue())) : 1));
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 491 */       if (isCurse(rand, baseEncMap)) {
/* 492 */         baseEncMap.put(Enchantments.field_190940_C, Integer.valueOf(1));
/*     */       }
/*     */       
/* 495 */       EnchantmentHelper.func_82782_a(baseEncMap, stack);
/*     */     } 
/*     */     
/* 498 */     return stack;
/*     */   }
/*     */ 
/*     */   private boolean isCurse(Random rand, Map<Enchantment, Integer> enchantMap) {
/* 502 */     int curse = -5;
/*     */     
/* 504 */     for (Map.Entry<Enchantment, Integer> entry : enchantMap.entrySet()) {
/* 505 */       int maxLV = ((Enchantment)entry.getKey()).func_77325_b();
/* 506 */       curse = (int)(curse + Math.pow(Math.max(0, ((Integer)entry.getValue()).intValue() - maxLV), 2.0D) * 5.0D);
/*     */     } 
/*     */     
/* 509 */     if (curse <= 0 || rand.nextFloat() > 0.97F) {
/* 510 */       return false;
/*     */     }
/* 512 */     return (rand.nextInt(100) < curse);
/*     */   }
/*     */ 
/*     */   private int calcMergeLv(int i1, int i2) {
/* 516 */     if (i1 == i2) {
/* 517 */       return i1 + 1;
/*     */     }
/* 519 */     return (int)Math.ceil((i1 + i2) / 2.0D);
/*     */   }
/*     */ 
/*     */   private int getEncCount(ItemStack stack) {
/* 523 */     if (stack.func_77973_b() instanceof TieredItem) {
/* 524 */       return Math.max(1, ((TieredItem)stack.func_77973_b()).func_200891_e().func_200925_d());
/*     */     }
/* 526 */     return 1;
/*     */   }
/*     */ 
/*     */   private ListNBT subListNBT(ListNBT org, int from, int to) {
/* 530 */     ListNBT list = new ListNBT();
/* 531 */     to = Math.min(to, org.size());
/* 532 */     for (int i = from; i < to; i++) {
/* 533 */       list.add(org.func_150305_b(i));
/*     */     }
/* 535 */     return list;
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 35 ms
	
*/