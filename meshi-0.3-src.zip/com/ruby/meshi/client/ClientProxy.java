/*    */ package com.ruby.meshi.client;
/*    */ import com.ruby.meshi.block.Indlight;
/*    */ import com.ruby.meshi.block.SakuraBlocks;
/*    */ import com.ruby.meshi.block.tileentity.BambooPotTileEntity;
/*    */ import com.ruby.meshi.block.tileentity.CardboardTileEntity;
/*    */ import com.ruby.meshi.block.tileentity.CollectorPressurePlateTileEntity;
/*    */ import com.ruby.meshi.block.tileentity.HearthTileEntity;
/*    */ import com.ruby.meshi.block.tileentity.MillstoneTileEntity;
/*    */ import com.ruby.meshi.block.tileentity.MiniatureTileEntity;
/*    */ import com.ruby.meshi.block.tileentity.SlideDoorTileEntity;
/*    */ import com.ruby.meshi.block.tileentity.WallShelfTileEntity;
/*    */ import com.ruby.meshi.client.renderer.BambooPotRender;
/*    */ import com.ruby.meshi.client.renderer.CardboardRender;
/*    */ import com.ruby.meshi.client.renderer.CollectorPressurePlateItemRender;
/*    */ import com.ruby.meshi.client.renderer.HearthRender;
/*    */ import com.ruby.meshi.client.renderer.MillstoneRender;
/*    */ import com.ruby.meshi.client.renderer.MiniatureRender;
/*    */ import com.ruby.meshi.client.renderer.SlideDoorRender;
/*    */ import com.ruby.meshi.client.renderer.WallShelfItemRender;
/*    */ import com.ruby.meshi.entity.ScarecrowEntity;
/*    */ import com.ruby.meshi.entity.ShurikenEntity;
/*    */ import java.util.stream.Stream;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.BlockState;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntityRenderer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.IItemProvider;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.IEnviromentBlockReader;
/*    */ import net.minecraftforge.api.distmarker.Dist;
/*    */ import net.minecraftforge.client.event.ColorHandlerEvent;
/*    */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*    */ import net.minecraftforge.fml.client.registry.ClientRegistry;
/*    */ import net.minecraftforge.fml.client.registry.IRenderFactory;
/*    */ import net.minecraftforge.fml.client.registry.RenderingRegistry;
/*    */ import net.minecraftforge.fml.common.Mod;
/*    */ import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
/*    */ 
/*    */ @EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
/*    */ public class ClientProxy {
/*    */   @SubscribeEvent
/*    */   public static void colorEvent(ColorHandlerEvent.Block e) {
/* 43 */     e.getBlockColors().func_186722_a((s, r, p, l) -> ((Indlight)s.func_177230_c()).getColorCode(), SakuraBlocks.INDLIGHT);
/*    */   }
/*    */ 
/*    */ 
/*    */   @SubscribeEvent
/*    */   public static void colorEvent(ColorHandlerEvent.Item e) {
/* 49 */     Stream.<Block>of(SakuraBlocks.INDLIGHT).forEach(l -> e.getItemColors().func_199877_a((), new IItemProvider[] { (IItemProvider)l }));
/*    */   }
/*    */ 
/*    */ 
/*    */   public static void renderRegister() {
/* 54 */     ClientRegistry.bindTileEntitySpecialRenderer(WallShelfTileEntity.class, new WallShelfItemRender());
/* 55 */     ClientRegistry.bindTileEntitySpecialRenderer(CollectorPressurePlateTileEntity.class, new CollectorPressurePlateItemRender());
/* 56 */     ClientRegistry.bindTileEntitySpecialRenderer(BambooPotTileEntity.class, new BambooPotRender());
/* 57 */     ClientRegistry.bindTileEntitySpecialRenderer(MillstoneTileEntity.class, new MillstoneRender());
/* 58 */     ClientRegistry.bindTileEntitySpecialRenderer(HearthTileEntity.class, new HearthRender());
/* 59 */     ClientRegistry.bindTileEntitySpecialRenderer(CardboardTileEntity.class, new CardboardRender());
/* 60 */     ClientRegistry.bindTileEntitySpecialRenderer(SlideDoorTileEntity.class, (TileEntityRenderer)new SlideDoorRender());
/* 61 */     ClientRegistry.bindTileEntitySpecialRenderer(MiniatureTileEntity.class, new MiniatureRender());
/* 62 */     RenderingRegistry.registerEntityRenderingHandler(ShurikenEntity.class, com.ruby.meshi.client.renderer.ShurikenRender::new);
/* 63 */     RenderingRegistry.registerEntityRenderingHandler(ScarecrowEntity.class, com.ruby.meshi.client.renderer.ScarecrowRender::new);
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 18 ms
	
*/