/*    */ package com.ruby.meshi.world.gen;
/*    */ 
/*    */ import com.mojang.datafixers.Dynamic;
/*    */ import java.util.Random;
/*    */ import java.util.Set;
/*    */ import java.util.function.Function;
/*    */ import net.minecraft.block.BlockState;
/*    */ import net.minecraft.block.Blocks;
/*    */ import net.minecraft.block.SaplingBlock;
/*    */ import net.minecraft.state.IProperty;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.util.math.MutableBoundingBox;
/*    */ import net.minecraft.world.IWorld;
/*    */ import net.minecraft.world.gen.IWorldGenerationReader;
/*    */ import net.minecraft.world.gen.feature.AbstractTreeFeature;
/*    */ import net.minecraft.world.gen.feature.NoFeatureConfig;
/*    */ 
/*    */ public class HiganTreeFeature
/*    */   extends AbstractTreeFeature<NoFeatureConfig>
/*    */ {
/*    */   private final SaplingBlock sapling;
/*    */   
/*    */   public HiganTreeFeature(Function<Dynamic<?>, ? extends NoFeatureConfig> config, SaplingBlock sapling) {
/* 24 */     super(config, false);
/* 25 */     this.sapling = sapling;
/*    */   }
/*    */ 
/*    */ 
/*    */   protected boolean func_208519_a(Set<BlockPos> changedBlocks, IWorldGenerationReader worldIn, Random rand, BlockPos pos, MutableBoundingBox p_208519_5_) {
/* 30 */     return generateSapling((IWorld)worldIn, rand, pos);
/*    */   }
/*    */ 
/*    */   private boolean generateSapling(IWorld world, Random rand, BlockPos pos) {
/* 34 */     if (world.func_175623_d(pos)) {
/* 35 */       BlockState block = world.func_180495_p(pos.func_177977_b());
/* 36 */       if (block.func_177230_c() == Blocks.field_196658_i || block.func_177230_c() == Blocks.field_150346_d) {
/* 37 */         this.sapling.func_176478_d(world, pos, (BlockState)this.sapling.func_176223_P().func_177231_a((IProperty)SaplingBlock.field_176479_b), rand);
/* 38 */         return true;
/*    */       } 
/*    */     } 
/* 41 */     return false;
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 3 ms
	
*/