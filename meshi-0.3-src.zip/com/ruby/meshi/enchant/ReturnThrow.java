/*    */ package com.ruby.meshi.enchant;
/*    */ 
/*    */ import net.minecraft.enchantment.Enchantment;
/*    */ import net.minecraft.enchantment.EnchantmentType;
/*    */ import net.minecraft.inventory.EquipmentSlotType;
/*    */ import net.minecraft.util.text.ITextComponent;
/*    */ import net.minecraft.util.text.TextFormatting;
/*    */ import net.minecraft.util.text.TranslationTextComponent;
/*    */ 
/*    */ public class ReturnThrow
/*    */   extends Enchantment {
/*    */   protected ReturnThrow(Enchantment.Rarity rarityIn, EnchantmentType typeIn, EquipmentSlotType... slots) {
/* 13 */     super(rarityIn, typeIn, slots);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   public int func_77321_a(int enchantmentLevel) {
/* 19 */     return enchantmentLevel * 20 - 10;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   public int func_223551_b(int enchantmentLevel) {
/* 25 */     return func_77321_a(enchantmentLevel) + 10;
/*    */   }
/*    */ 
/*    */ 
/*    */   public boolean isAllowedOnBooks() {
/* 30 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   public int func_77325_b() {
/* 35 */     return 5;
/*    */   }
/*    */ 
/*    */ 
/*    */   public ITextComponent func_200305_d(int level) {
/* 40 */     TranslationTextComponent translationTextComponent = new TranslationTextComponent(func_77320_a(), new Object[0]);
/* 41 */     if (func_190936_d()) {
/* 42 */       translationTextComponent.func_211708_a(TextFormatting.RED);
/*    */     } else {
/* 44 */       translationTextComponent.func_211708_a(TextFormatting.GRAY);
/*    */     } 
/*    */     
/* 47 */     return (ITextComponent)translationTextComponent;
/*    */   }
/*    */ 
/*    */ 
/*    */   public boolean func_77326_a(Enchantment ench) {
/* 52 */     return (ench instanceof InfinityThrow) ? false : super.func_77326_a(ench);
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 2 ms
	
*/