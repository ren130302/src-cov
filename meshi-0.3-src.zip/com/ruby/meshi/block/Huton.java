/*    */ package com.ruby.meshi.block;
/*    */ 
/*    */ import net.minecraft.block.BedBlock;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.BlockRenderType;
/*    */ import net.minecraft.block.BlockState;
/*    */ import net.minecraft.item.DyeColor;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.util.math.shapes.ISelectionContext;
/*    */ import net.minecraft.util.math.shapes.VoxelShape;
/*    */ import net.minecraft.world.IBlockReader;
/*    */ 
/*    */ public class Huton extends BedBlock {
/* 14 */   public static final VoxelShape SHAPE = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 4.0D, 16.0D);
/*    */ 
/*    */   public Huton(Block.Properties properties) {
/* 17 */     super(DyeColor.WHITE, properties);
/*    */   }
/*    */ 
/*    */ 
/*    */   public VoxelShape func_220053_a(BlockState state, IBlockReader worldIn, BlockPos pos, ISelectionContext context) {
/* 22 */     return SHAPE;
/*    */   }
/*    */ 
/*    */ 
/*    */   public boolean hasTileEntity(BlockState state) {
/* 27 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   public BlockRenderType func_149645_b(BlockState state) {
/* 32 */     return BlockRenderType.MODEL;
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 1 ms
	
*/