/*    */  package com.ruby.meshi.item;
/*    */  
/*    */  import java.util.List;
/*    */  import javax.annotation.Nullable;
/*    */  import net.minecraft.client.util.ITooltipFlag;
/*    */  import net.minecraft.item.Food;
/*    */  import net.minecraft.item.Item;
/*    */  import net.minecraft.item.ItemStack;
/*    */  import net.minecraft.util.text.ITextComponent;
/*    */  import net.minecraft.util.text.TextFormatting;
/*    */  import net.minecraft.util.text.TranslationTextComponent;
/*    */  import net.minecraft.world.World;
/*    */  import net.minecraftforge.api.distmarker.Dist;
/*    */  import net.minecraftforge.api.distmarker.OnlyIn;
/*    */  
/*    */  
/*    */  public class Meshi
/*    */    extends Item
/*    */  {
/*    */    public Meshi(Item.Properties properties) {
/* 21 */      super(properties);
/*    */    }
/*    */ 
/*    */ 
/*    */    @OnlyIn(Dist.CLIENT)
/*    */    public void func_77624_a(ItemStack stack, @Nullable World worldIn, List<ITextComponent> tooltip, ITooltipFlag flagIn) {
/* 27 */      String key = "desc.meshi." + getRegistryName().func_110623_a();
/* 28 */      TranslationTextComponent text = new TranslationTextComponent(key, new Object[0]);
/* 29 */      text.func_211708_a(TextFormatting.GOLD);
/* 30 */      if (!text.getString().equals(key))
/* 31 */        tooltip.add(text); 
/*    */    }
/*    */    
/*    */    static class Builder extends Food.Builder {}
/*    */  }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 4 ms
	
*/