/*     */ package com.ruby.meshi.client.renderer;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.GlStateManager;
/*     */ import com.ruby.meshi.block.Cardboard;
/*     */ import com.ruby.meshi.block.tileentity.CardboardTileEntity;
/*     */ import com.ruby.meshi.client.renderer.animation.EntityModelAnimation;
/*     */ import net.minecraft.client.renderer.entity.model.CatModel;
/*     */ import net.minecraft.client.renderer.tileentity.TileEntityRenderer;
/*     */ import net.minecraft.entity.passive.CatEntity;
/*     */ import net.minecraft.state.IProperty;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.Direction;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ 
/*     */ public class CardboardRender extends TileEntityRenderer<CardboardTileEntity> {
/*  16 */   private static final WrapCatModel CAT_RENDER = new WrapCatModel(0.0F);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void render(CardboardTileEntity tileEntityIn, double x, double y, double z, float partialTicks, int destroyStage) {
/*  22 */     if (!tileEntityIn.hasCatNBT()) {
/*     */       return;
/*     */     }
/*  25 */     float scale = 0.0625F;
/*  26 */     Direction direction = (Direction)tileEntityIn.func_195044_w().func_177229_b((IProperty)Cardboard.field_185512_D);
/*  27 */     func_147499_a(getCatTexture(tileEntityIn));
/*  28 */     tileEntityIn.getAnimations().forEach(a -> {
/*     */           renderHead(a, tileEntityIn, x, y, z, partialTicks, 0.0625F, direction);
/*     */           renderFrontLeg(a, tileEntityIn, x, y, z, partialTicks, 0.0625F, direction);
/*     */           renderTail(a, tileEntityIn, x, y, z, partialTicks, 0.0625F, direction);
/*     */         });
/*     */   }
/*     */ 
/*     */   private void renderTail(EntityModelAnimation animation, CardboardTileEntity tileEntityIn, double x, double y, double z, float partialTicks, float scale, Direction direction) {
/*  36 */     if (animation.shouldRenderPart(EntityModelAnimation.RenderPart.TAIL)) {
/*  37 */       GlStateManager.pushMatrix();
/*  38 */       animation.translatef((i, j, k) -> GlStateManager.translatef((float)x + 0.5F + i.floatValue() + getDirOffset(direction, 0.1F, Direction.Axis.X), (float)y + 0.11F + j.floatValue() + getDirOffset(direction, 0.2F, Direction.Axis.Y), (float)z + 0.5F + k.floatValue() + getDirOffset(direction, 0.1F, Direction.Axis.Z)), partialTicks);
/*     */ 
/*     */ 
/*     */       
/*  42 */       animation.scalef((i, j, k) -> GlStateManager.scalef(0.8F + i.floatValue(), 0.8F + j.floatValue(), 0.8F + k.floatValue()), partialTicks);
/*  43 */       animation.rotateZ(a -> GlStateManager.rotatef(a.floatValue(), 0.0F, 0.0F, 1.0F), partialTicks);
/*  44 */       animation.rotateY(a -> GlStateManager.rotatef(getPartRotate(direction) + a.floatValue(), 0.0F, 1.0F, 0.0F), partialTicks);
/*  45 */       animation.rotateX(a -> GlStateManager.rotatef(a.floatValue(), 1.0F, 0.0F, 0.0F), partialTicks);
/*  46 */       GlStateManager.rotatef(90.0F, 1.0F, 0.0F, 0.0F);
/*  47 */       CAT_RENDER.renderTail(scale);
/*  48 */       GlStateManager.popMatrix();
/*     */     } 
/*     */   }
/*     */ 
/*     */   private void renderHead(EntityModelAnimation animation, CardboardTileEntity tileEntityIn, double x, double y, double z, float partialTicks, float scale, Direction direction) {
/*  53 */     if (animation.shouldRenderPart(EntityModelAnimation.RenderPart.HEAD)) {
/*  54 */       GlStateManager.pushMatrix();
/*  55 */       animation.translatef((i, j, k) -> GlStateManager.translatef((float)x + 0.5F + i.floatValue() + getDirOffset(direction, 0.2F, Direction.Axis.X), (float)y + 0.15F + j.floatValue() + getDirOffset(direction, 0.2F, Direction.Axis.Y), (float)z + 0.5F + k.floatValue() + getDirOffset(direction, 0.2F, Direction.Axis.Z)), partialTicks);
/*     */ 
/*     */ 
/*     */       
/*  59 */       animation.scalef((i, j, k) -> GlStateManager.scalef(0.8F + i.floatValue(), 0.8F + j.floatValue(), 0.8F + k.floatValue()), partialTicks);
/*  60 */       animation.rotateZ(a -> GlStateManager.rotatef(a.floatValue(), 0.0F, 0.0F, 1.0F), partialTicks);
/*  61 */       animation.rotateY(a -> GlStateManager.rotatef(getPartRotate(direction) + a.floatValue(), 0.0F, 1.0F, 0.0F), partialTicks);
/*  62 */       animation.rotateX(a -> GlStateManager.rotatef(a.floatValue(), 1.0F, 0.0F, 0.0F), partialTicks);
/*  63 */       GlStateManager.rotatef(180.0F, 1.0F, 0.0F, 0.0F);
/*  64 */       CAT_RENDER.renderHead(scale);
/*  65 */       GlStateManager.popMatrix();
/*     */     } 
/*     */   }
/*     */ 
/*     */   private void renderFrontLeg(EntityModelAnimation animation, CardboardTileEntity tileEntityIn, double x, double y, double z, float partialTicks, float scale, Direction direction) {
/*  70 */     if (animation.shouldRenderPart(EntityModelAnimation.RenderPart.LEFT_HAND)) {
/*  71 */       GlStateManager.pushMatrix();
/*  72 */       animation.translatef((i, j, k) -> GlStateManager.translatef((float)x + i.floatValue() + 0.5F + getDirOffset(direction, -0.15F, Direction.Axis.X) + getDirOffset(direction, 0.15F, Direction.Axis.Z), (float)y + 0.11F + j.floatValue() + getDirOffset(direction, 0.2F, Direction.Axis.Y), (float)z + 0.5F + k.floatValue() + getDirOffset(direction, 0.15F, Direction.Axis.X) + getDirOffset(direction, -0.15F, Direction.Axis.Z)), partialTicks);
/*     */ 
/*     */ 
/*     */       
/*  76 */       animation.scalef((i, j, k) -> GlStateManager.scalef(0.8F + i.floatValue(), 0.8F + j.floatValue(), 0.8F + k.floatValue()), partialTicks);
/*  77 */       animation.rotateZ(a -> GlStateManager.rotatef(a.floatValue(), 0.0F, 0.0F, 1.0F), partialTicks);
/*  78 */       animation.rotateY(a -> GlStateManager.rotatef(getPartRotate(direction) + a.floatValue(), 0.0F, 1.0F, 0.0F), partialTicks);
/*  79 */       animation.rotateX(a -> GlStateManager.rotatef(a.floatValue(), 1.0F, 0.0F, 0.0F), partialTicks);
/*  80 */       GlStateManager.rotatef(90.0F, 1.0F, 0.0F, 0.0F);
/*  81 */       CAT_RENDER.renderFrontLeftLeg(scale);
/*  82 */       GlStateManager.popMatrix();
/*     */     } 
/*  84 */     if (animation.shouldRenderPart(EntityModelAnimation.RenderPart.RIGHT_HAND)) {
/*  85 */       GlStateManager.pushMatrix();
/*  86 */       animation.translatef((i, j, k) -> GlStateManager.translatef((float)x + i.floatValue() + 0.5F + getDirOffset(direction, -0.15F, Direction.Axis.X) + getDirOffset(direction, -0.15F, Direction.Axis.Z), (float)y + 0.11F + j.floatValue() + getDirOffset(direction, 0.2F, Direction.Axis.Y), (float)z + 0.5F + k.floatValue() + getDirOffset(direction, -0.15F, Direction.Axis.X) + getDirOffset(direction, -0.15F, Direction.Axis.Z)), partialTicks);
/*     */ 
/*     */ 
/*     */       
/*  90 */       animation.scalef((i, j, k) -> GlStateManager.scalef(0.8F + i.floatValue(), 0.8F + j.floatValue(), 0.8F + k.floatValue()), partialTicks);
/*  91 */       animation.rotateZ(a -> GlStateManager.rotatef(a.floatValue(), 0.0F, 0.0F, 1.0F), partialTicks);
/*  92 */       animation.rotateY(a -> GlStateManager.rotatef(getPartRotate(direction) + a.floatValue(), 0.0F, 1.0F, 0.0F), partialTicks);
/*  93 */       animation.rotateX(a -> GlStateManager.rotatef(a.floatValue(), 1.0F, 0.0F, 0.0F), partialTicks);
/*  94 */       GlStateManager.rotatef(90.0F, 1.0F, 0.0F, 0.0F);
/*  95 */       CAT_RENDER.renderFrontRightLeg(scale);
/*  96 */       GlStateManager.popMatrix();
/*     */     } 
/*     */   }
/*     */ 
/*     */   private float getDirOffset(Direction dir, float value, Direction.Axis axis) {
/* 101 */     float offset = 0.0F;
/* 102 */     if (dir.func_176740_k() == axis) {
/* 103 */       offset = value * dir.func_176743_c().func_179524_a();
/*     */     }
/* 105 */     return offset;
/*     */   }
/*     */ 
/*     */   private int getPartRotate(Direction dir) {
/* 109 */     int headRotate = 0;
/* 110 */     switch (dir) {
/*     */       case EAST:
/* 112 */         headRotate = 90;
/*     */         break;
/*     */       case NORTH:
/* 115 */         headRotate = 180;
/*     */         break;
/*     */ 
/*     */       
/*     */       case WEST:
/* 120 */         headRotate = 270;
/*     */         break;
/*     */     } 
/* 123 */     return headRotate;
/*     */   }
/*     */ 
/*     */   public static class WrapCatModel
/*     */     extends CatModel<CatEntity> {
/*     */     public WrapCatModel(float p_i51069_1_) {
/* 129 */       super(p_i51069_1_);
/* 130 */       this.field_78156_g.func_78793_a(0.0F, 0.0F, 0.0F);
/* 131 */       this.field_78158_e.func_78793_a(0.0F, 0.0F, 0.0F);
/* 132 */       this.field_78155_f.func_78793_a(0.0F, 0.0F, 0.0F);
/* 133 */       this.field_78160_c.func_78793_a(0.0F, 0.0F, 0.0F);
/* 134 */       this.field_78157_d.func_78793_a(0.0F, 0.0F, 0.0F);
/*     */     }
/*     */ 
/*     */     public void renderHead(float scale) {
/* 138 */       this.field_78156_g.func_78785_a(scale);
/*     */     }
/*     */ 
/*     */ 
/*     */     public void renderTail(float scale) {
/* 143 */       this.field_78155_f.func_78785_a(scale);
/*     */     }
/*     */ 
/*     */     public void renderFrontLeftLeg(float scale) {
/* 147 */       this.field_78160_c.func_78785_a(scale);
/*     */     }
/*     */ 
/*     */     public void renderFrontRightLeg(float scale) {
/* 151 */       this.field_78157_d.func_78785_a(scale);
/*     */     }
/*     */   }
/*     */ 
/*     */   private ResourceLocation getCatTexture(CardboardTileEntity tile) {
/* 156 */     return (ResourceLocation)CatEntity.field_213425_bD.get(Integer.valueOf((tile != null) ? tile.getCatType() : 0));
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 23 ms
	
*/