// Warning: No line numbers available in class file
/*  */ package com.ruby.meshi.crafting;
/*  */ 
/*  */ public interface CookingTimerRecipe {
/*  */   int getCookTime();
/*  */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 0 ms
	
*/