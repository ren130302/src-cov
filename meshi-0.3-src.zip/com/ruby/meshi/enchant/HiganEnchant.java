package com.ruby.meshi.enchant;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantment.Rarity;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.util.ResourceLocation;

public class HiganEnchant {
   public static final Enchantment QUICK_THROW;
   public static final Enchantment POWER_THROW;
   public static final Enchantment CRITICAL_THROW;
   public static final Enchantment POISON_THROW;
   public static final Enchantment SNIPE_THROW;
   public static final Enchantment ECONOMY_BRACELET;
   public static final Enchantment UNBREAKING_BRACELET;
   public static final Enchantment PICKPOCKET;
   public static final Enchantment FLAME_THROW;
   public static final Enchantment HUNTER_THROW;
   public static final Enchantment ROGUE_THROW;
   public static final Enchantment MULTI_THROW;
   public static final Enchantment INFINITY_THROW;
   public static final Enchantment ASSASSIN_THROW;
   public static final Enchantment RETURN_THROW;

   private static Enchantment regiter(String key, Enchantment enc) {
      return (Enchantment)enc.setRegistryName(new ResourceLocation("meshi", key));
   }

   static {
      QUICK_THROW = regiter("quick_throw", new QuickThrow(Rarity.COMMON, HiganEnchantType.BRACELET, new EquipmentSlotType[]{EquipmentSlotType.MAINHAND}));
      POWER_THROW = regiter("power_throw", new PowerThrow(Rarity.COMMON, HiganEnchantType.BRACELET, new EquipmentSlotType[]{EquipmentSlotType.MAINHAND}));
      CRITICAL_THROW = regiter("critical_throw", new CriticalThrow(Rarity.COMMON, HiganEnchantType.BRACELET, new EquipmentSlotType[]{EquipmentSlotType.MAINHAND}));
      POISON_THROW = regiter("poison_throw", new PoisonThrow(Rarity.COMMON, HiganEnchantType.BRACELET, new EquipmentSlotType[]{EquipmentSlotType.MAINHAND}));
      SNIPE_THROW = regiter("snipe_throw", new SnipeThrow(Rarity.COMMON, HiganEnchantType.BRACELET, new EquipmentSlotType[]{EquipmentSlotType.MAINHAND}));
      ECONOMY_BRACELET = regiter("economy_bracelet", new EconomyBracelet(Rarity.UNCOMMON, HiganEnchantType.BRACELET, new EquipmentSlotType[]{EquipmentSlotType.MAINHAND}));
      UNBREAKING_BRACELET = regiter("unbreaking_bracelet", new UnbreakingBracelet(Rarity.UNCOMMON, HiganEnchantType.BRACELET, new EquipmentSlotType[]{EquipmentSlotType.MAINHAND}));
      PICKPOCKET = regiter("pickpocket", new Pickpocket(Rarity.UNCOMMON, HiganEnchantType.BRACELET, new EquipmentSlotType[]{EquipmentSlotType.MAINHAND}));
      FLAME_THROW = regiter("flame_throw", new FlameThrow(Rarity.RARE, HiganEnchantType.BRACELET, new EquipmentSlotType[]{EquipmentSlotType.MAINHAND}));
      HUNTER_THROW = regiter("hunter_throw", new HunterThrow(Rarity.RARE, HiganEnchantType.BRACELET, new EquipmentSlotType[]{EquipmentSlotType.MAINHAND}));
      ROGUE_THROW = regiter("rogue_throw", new RogueThrow(Rarity.RARE, HiganEnchantType.BRACELET, new EquipmentSlotType[]{EquipmentSlotType.MAINHAND}));
      MULTI_THROW = regiter("multi_throw", new MultiThrow(Rarity.RARE, HiganEnchantType.BRACELET, new EquipmentSlotType[]{EquipmentSlotType.MAINHAND}));
      INFINITY_THROW = regiter("infinity_throw", new InfinityThrow(Rarity.RARE, HiganEnchantType.BRACELET, new EquipmentSlotType[]{EquipmentSlotType.MAINHAND}));
      ASSASSIN_THROW = regiter("assassin_throw", new AssassinThrow(Rarity.VERY_RARE, HiganEnchantType.BRACELET, new EquipmentSlotType[]{EquipmentSlotType.MAINHAND}));
      RETURN_THROW = regiter("return_throw", new ReturnThrow(Rarity.VERY_RARE, HiganEnchantType.BRACELET, new EquipmentSlotType[]{EquipmentSlotType.MAINHAND}));
   }
}