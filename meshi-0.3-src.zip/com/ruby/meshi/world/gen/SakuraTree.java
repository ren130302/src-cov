/*    */ package com.ruby.meshi.world.gen;
/*    */ 
/*    */ import java.util.Random;
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.trees.Tree;
/*    */ import net.minecraft.world.gen.feature.AbstractTreeFeature;
/*    */ import net.minecraft.world.gen.feature.NoFeatureConfig;
/*    */ import net.minecraft.world.gen.feature.TreeFeature;
/*    */ 
/*    */ 
/*    */ public class SakuraTree
/*    */   extends Tree
/*    */ {
/*    */   private Block log;
/*    */   private Block leave;
/*    */   
/*    */   public SakuraTree(Block log, Block leave) {
/* 19 */     this.log = log;
/* 20 */     this.leave = leave;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   @Nullable
/*    */   protected AbstractTreeFeature<NoFeatureConfig> func_196936_b(Random random) {
/* 27 */     return (random.nextInt(10) == 0) ? (new ExtendBigTreeFeature(NoFeatureConfig::func_214639_a, true)).setBlocks(this.log.func_176223_P(), this.leave.func_176223_P()) : (AbstractTreeFeature<NoFeatureConfig>)new TreeFeature(NoFeatureConfig::func_214639_a, true, 5, this.log.func_176223_P(), this.leave.func_176223_P(), false);
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 3 ms
	
*/