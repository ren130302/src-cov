package com.ruby.meshi.enchant;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentType;
import net.minecraft.enchantment.MendingEnchantment;
import net.minecraft.enchantment.Enchantment.Rarity;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.TranslationTextComponent;

public class InfinityThrow extends Enchantment {
   protected InfinityThrow(Rarity rarityIn, EnchantmentType type, EquipmentSlotType... slots) {
      super(rarityIn, type, slots);
   }

   public int func_77321_a(int enchantmentLevel) {
      return enchantmentLevel == 1 ? 30 : (enchantmentLevel == 2 ? 70 : 90);
   }

   public int func_223551_b(int enchantmentLevel) {
      return enchantmentLevel == 1 ? 69 : (enchantmentLevel == 2 ? 85 : 100);
   }

   public int func_77325_b() {
      return 3;
   }

   public ITextComponent func_200305_d(int level) {
      ITextComponent itextcomponent = new TranslationTextComponent(this.func_77320_a() + "_" + level, new Object[0]);
      if (this.func_190936_d()) {
         itextcomponent.func_211708_a(TextFormatting.RED);
      } else {
         itextcomponent.func_211708_a(TextFormatting.GRAY);
      }

      return itextcomponent;
   }

   public boolean isAllowedOnBooks() {
      return false;
   }

   public boolean func_77326_a(Enchantment ench) {
      return !(ench instanceof MendingEnchantment) && !(ench instanceof EconomyBracelet) && !(ench instanceof ReturnThrow) ? super.func_77326_a(ench) : false;
   }
}