/*    */ package com.ruby.meshi.client.renderer;
/*    */ 
/*    */ import com.mojang.blaze3d.platform.GlStateManager;
/*    */ import java.util.function.Consumer;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.renderer.model.ItemCameraTransforms;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntityRenderer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ 
/*    */ public abstract class SimpleItemRender<T extends TileEntity>
/*    */   extends TileEntityRenderer<T>
/*    */ {
/* 14 */   private static final Minecraft mc = Minecraft.func_71410_x();
/*    */ 
/*    */   public void renderItem(ItemStack stack, Consumer<ItemStack> transleter, Consumer<ItemStack> rotater, float scale) {
/* 17 */     if (!stack.func_190926_b()) {
/* 18 */       GlStateManager.pushMatrix();
/* 19 */       transleter.accept(stack);
/* 20 */       rotater.accept(stack);
/* 21 */       GlStateManager.scalef(scale, scale, scale);
/* 22 */       mc.func_175599_af().func_181564_a(stack, ItemCameraTransforms.TransformType.FIXED);
/* 23 */       GlStateManager.popMatrix();
/*    */     } 
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 2 ms
	
*/