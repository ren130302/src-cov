/*    */ package com.ruby.meshi.block;
/*    */ import com.ruby.meshi.block.tileentity.CollectorPressurePlateTileEntity;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import java.util.stream.Collectors;
/*    */ import java.util.stream.Stream;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.BlockState;
/*    */ import net.minecraft.entity.player.PlayerEntity;
/*    */ import net.minecraft.entity.player.PlayerInventory;
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.state.IProperty;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class CollectorPressurePlate extends CollectionAndDeliveryBase {
/*    */   public CollectorPressurePlate(Block.Properties properties, int horizon, int vertical) {
/* 20 */     super(properties, horizon, vertical);
/*    */   }
/*    */ 
/*    */ 
/*    */   public void onPressedSwitch(BlockState state, World worldIn, BlockPos pos, PlayerEntity playerIn) {
/* 25 */     CollectorPressurePlateTileEntity tile = (CollectorPressurePlateTileEntity)worldIn.func_175625_s(pos);
/* 26 */     boolean isForce = ((Boolean)state.func_177229_b((IProperty)FORCE)).booleanValue();
/*    */ 
/*    */ 
/*    */     
/* 30 */     Set<Item> collectorFilter = (Set<Item>)getSlotList((IInventory)tile).stream().filter(stack -> !stack.func_190926_b()).map(ItemStack::func_77973_b).collect(Collectors.toSet());
/*    */     
/* 32 */     if (!isForce || !collectorFilter.isEmpty()) {
/*    */ 
/*    */       
/* 35 */       List<CollectionAndDeliveryBase.InventoryEntry> playerEntryList = createInventoryEntrys((IInventory)playerIn.field_71071_by, (List<ItemStack>)playerIn.field_71071_by.field_70462_a, stack -> 
/*    */           
/* 37 */           (!stack.func_190926_b() && (collectorFilter.isEmpty() ? stack.func_77985_e() : collectorFilter.contains(stack.func_77973_b()))), (id, stack) -> !PlayerInventory.func_184435_e(id.intValue()));
/*    */ 
/*    */       
/* 40 */       if (!playerEntryList.isEmpty()) {
/*    */ 
/*    */ 
/*    */         
/* 44 */         Set<Item> matchedFilter = (Set<Item>)playerEntryList.stream().map(CollectionAndDeliveryBase.InventoryEntry::getItem).collect(Collectors.toSet());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 54 */         Set<CollectionAndDeliveryBase.InventoryEntry> chestEntrySet = (Set<CollectionAndDeliveryBase.InventoryEntry>)getSurroundingIInventory(worldIn, pos, this.horizonSize, this.verticalSize).stream().flatMap(inv -> createInventoryEntrys(inv, getSlotList(inv), (), ()).stream().sorted().distinct()).collect(Collectors.toSet());
/* 55 */         if (!chestEntrySet.isEmpty())
/*    */         {
/* 57 */           playerEntryList.forEach(playerEntry -> chestEntrySet.stream().filter(()).forEach(()));
/*    */         }
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 11 ms
	
*/