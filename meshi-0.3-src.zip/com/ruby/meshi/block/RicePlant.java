package com.ruby.meshi.block;

import com.ruby.meshi.item.HiganItems;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.CropsBlock;
import net.minecraft.block.Block.Properties;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;

public class RicePlant extends CropsBlock implements CustomItemBlock {
   protected RicePlant(Properties builder) {
      super(builder);
   }

   public IItemProvider func_199772_f() {
      return HiganItems.RICE_SEED;
   }

   public ItemStack func_185473_a(IBlockReader worldIn, BlockPos pos, BlockState state) {
      return new ItemStack(this.func_199772_f());
   }

   public Item getBlockItem(Block block, net.minecraft.item.Item.Properties prop) {
      return EMPTY;
   }
}