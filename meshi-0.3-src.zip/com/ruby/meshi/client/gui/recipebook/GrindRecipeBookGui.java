/*     */ package com.ruby.meshi.client.gui.recipebook;
/*     */ 
/*     */ import com.google.gson.JsonElement;
/*     */ import com.ruby.meshi.crafting.GrindRecipe;
/*     */ import com.ruby.meshi.crafting.GrindRecipeItemHelper;
/*     */ import it.unimi.dsi.fastutil.ints.IntList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.stream.Stream;
/*     */ import net.minecraft.client.gui.recipebook.RecipeBookGui;
/*     */ import net.minecraft.inventory.container.Slot;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.crafting.IRecipe;
/*     */ import net.minecraft.item.crafting.Ingredient;
/*     */ import net.minecraftforge.common.crafting.IIngredientSerializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GrindRecipeBookGui
/*     */   extends RecipeBookGui
/*     */ {
/*     */   public GrindRecipeBookGui() {
/*  24 */     GrindRecipeItemHelper.hookHelper(RecipeBookGui.class, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   public void func_193951_a(IRecipe<?> recipe, List<Slot> slots) {
/*  30 */     if (recipe instanceof GrindRecipe) {
/*  31 */       this.field_191915_z.func_192685_a(recipe);
/*  32 */       this.field_191915_z.func_194187_a(new WrapIngredient(((GrindRecipe)recipe).ingredient, ((GrindRecipe)recipe).getRequestCount()), ((Slot)slots.get(0)).field_75223_e, ((Slot)slots.get(0)).field_75221_f);
/*  33 */       ItemStack outPut = recipe.func_77571_b();
/*  34 */       this.field_191915_z.func_194187_a(new WrapIngredient(Ingredient.func_193369_a(new ItemStack[] { outPut }, ), outPut.func_190916_E()), ((Slot)slots.get(1)).field_75223_e, ((Slot)slots.get(1)).field_75221_f);
/*  35 */       ItemStack bonus = ((GrindRecipe)recipe).getBonus();
/*  36 */       if (!bonus.func_190926_b()) {
/*  37 */         this.field_191915_z.func_194187_a(new WrapIngredient(Ingredient.func_193369_a(new ItemStack[] { bonus }, ), bonus.func_190916_E()), ((Slot)slots.get(2)).field_75223_e, ((Slot)slots.get(2)).field_75221_f);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   static class WrapIngredient
/*     */     extends Ingredient
/*     */   {
/*     */     private final Ingredient original;
/*     */     private final int count;
/*     */     
/*     */     protected WrapIngredient(Ingredient org, int count) {
/*  50 */       super(Stream.empty());
/*  51 */       this.original = org;
/*  52 */       this.count = count;
/*     */     }
/*     */ 
/*     */ 
/*     */     public Predicate<ItemStack> and(Predicate<? super ItemStack> other) {
/*  57 */       return this.original.and(other);
/*     */     }
/*     */ 
/*     */ 
/*     */     public Predicate<ItemStack> negate() {
/*  62 */       return this.original.negate();
/*     */     }
/*     */ 
/*     */ 
/*     */     public Predicate<ItemStack> or(Predicate<? super ItemStack> other) {
/*  67 */       return this.original.or(other);
/*     */     }
/*     */ 
/*     */ 
/*     */     public ItemStack[] func_193365_a() {
/*  72 */       ItemStack[] stacks = this.original.func_193365_a();
/*  73 */       Arrays.<ItemStack>stream(stacks).forEach(s -> s.func_190920_e(this.count));
/*  74 */       return stacks;
/*     */     }
/*     */ 
/*     */ 
/*     */     public boolean test(ItemStack p_test_1_) {
/*  79 */       return this.original.test(p_test_1_);
/*     */     }
/*     */ 
/*     */ 
/*     */     public IntList func_194139_b() {
/*  84 */       return this.original.func_194139_b();
/*     */     }
/*     */ 
/*     */ 
/*     */     public JsonElement func_200304_c() {
/*  89 */       return this.original.func_200304_c();
/*     */     }
/*     */ 
/*     */ 
/*     */     public boolean func_203189_d() {
/*  94 */       return this.original.func_203189_d();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isSimple() {
/* 103 */       return this.original.isSimple();
/*     */     }
/*     */ 
/*     */ 
/*     */     public IIngredientSerializer<? extends Ingredient> getSerializer() {
/* 108 */       return this.original.getSerializer();
/*     */     }
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 170 ms
	
*/