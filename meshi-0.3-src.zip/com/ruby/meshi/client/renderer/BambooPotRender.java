package com.ruby.meshi.client.renderer;

import com.ruby.meshi.block.tileentity.BambooPotTileEntity;

public class BambooPotRender extends SimpleItemRender<BambooPotTileEntity> {
   public void render(BambooPotTileEntity tileEntityIn, double x, double y, double z, float partialTicks, int destroyStage) {
      super.func_199341_a(tileEntityIn, x, y, z, partialTicks, destroyStage);
   }
}