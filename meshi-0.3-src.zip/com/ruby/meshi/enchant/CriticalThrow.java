/*    */ package com.ruby.meshi.enchant;
/*    */ 
/*    */ import net.minecraft.enchantment.Enchantment;
/*    */ import net.minecraft.enchantment.EnchantmentType;
/*    */ import net.minecraft.inventory.EquipmentSlotType;
/*    */ import net.minecraft.util.text.ITextComponent;
/*    */ 
/*    */ public class CriticalThrow extends EnchantmentBase {
/*    */   protected CriticalThrow(Enchantment.Rarity rarityIn, EnchantmentType typeIn, EquipmentSlotType... slots) {
/* 10 */     super(rarityIn, typeIn, slots);
/*    */   }
/*    */ 
/*    */ 
/*    */   public int func_77321_a(int enchantmentLevel) {
/* 15 */     return 5 + (enchantmentLevel - 1) * 18;
/*    */   }
/*    */ 
/*    */ 
/*    */   public int func_223551_b(int enchantmentLevel) {
/* 20 */     return super.func_77321_a(enchantmentLevel) + 17;
/*    */   }
/*    */ 
/*    */ 
/*    */   public int func_77325_b() {
/* 25 */     return 6;
/*    */   }
/*    */ 
/*    */ 
/*    */   public boolean func_77326_a(Enchantment ench) {
/* 30 */     return (ench instanceof RogueThrow || ench instanceof AssassinThrow) ? false : super.func_77326_a(ench);
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 1 ms
	
*/