/*     */ package com.ruby.meshi.entity;
/*     */ 
/*     */ import com.google.common.collect.Sets;
/*     */ import com.ruby.meshi.item.HiganItems;
/*     */ import com.ruby.meshi.item.Shuriken;
/*     */ import java.util.Collection;
/*     */ import java.util.Set;
/*     */ import javax.annotation.Nonnull;
/*     */ import net.minecraft.block.BlockState;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.IRendersAsItem;
/*     */ import net.minecraft.entity.LivingEntity;
/*     */ import net.minecraft.entity.player.PlayerEntity;
/*     */ import net.minecraft.entity.projectile.AbstractArrowEntity;
/*     */ import net.minecraft.item.IItemTier;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.ItemTier;
/*     */ import net.minecraft.nbt.CompoundNBT;
/*     */ import net.minecraft.nbt.INBT;
/*     */ import net.minecraft.nbt.ListNBT;
/*     */ import net.minecraft.network.IPacket;
/*     */ import net.minecraft.network.datasync.DataParameter;
/*     */ import net.minecraft.network.datasync.DataSerializers;
/*     */ import net.minecraft.network.datasync.EntityDataManager;
/*     */ import net.minecraft.potion.EffectInstance;
/*     */ import net.minecraft.potion.PotionUtils;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.IItemProvider;
/*     */ import net.minecraft.util.IndirectEntityDamageSource;
/*     */ import net.minecraft.util.SoundCategory;
/*     */ import net.minecraft.util.SoundEvents;
/*     */ import net.minecraft.util.Util;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.BlockRayTraceResult;
/*     */ import net.minecraft.util.math.EntityRayTraceResult;
/*     */ import net.minecraft.util.math.RayTraceResult;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.api.distmarker.Dist;
/*     */ import net.minecraftforge.api.distmarker.OnlyIn;
/*     */ import net.minecraftforge.fml.network.FMLPlayMessages;
/*     */ import net.minecraftforge.fml.network.NetworkHooks;
/*     */ 
/*     */ 
/*     */ @OnlyIn(value = Dist.CLIENT, _interface = IRendersAsItem.class)
/*     */ public class ShurikenEntity
/*     */   extends AbstractArrowEntity
/*     */   implements IRendersAsItem
/*     */ {
/*  50 */   private static final DataParameter<ItemStack> ITEMSTACK_DATA = EntityDataManager.func_187226_a(ShurikenEntity.class, DataSerializers.field_187196_f);
/*     */ 
/*  52 */   private int timer = 0;
/*  53 */   public float xAngle = this.field_70146_Z.nextFloat() * 90.0F - 45.0F;
/*     */ 
/*  55 */   private final Set<EffectInstance> customPotionEffects = Sets.newHashSet();
/*     */ 
/*     */ 
/*  58 */   private int economy = 0;
/*     */ 
/*  60 */   private int infinity = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  67 */   private int multiThrow = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   public ShurikenEntity(FMLPlayMessages.SpawnEntity packet, World worldIn) {
/*  72 */     super(HiganEntityType.SHURIKEN, worldIn);
/*     */   }
/*     */ 
/*     */ 
/*     */   public ShurikenEntity(LivingEntity livingEntityIn, World worldIn) {
/*  77 */     super(HiganEntityType.SHURIKEN, livingEntityIn, worldIn);
/*  78 */     func_189654_d(true);
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_184547_a(Entity shooter, float pitch, float yaw, float p_184547_4_, float velocity, float inaccuracy) {
/*  83 */     super.func_184547_a(shooter, pitch, yaw, p_184547_4_, velocity, inaccuracy);
/*  84 */     this.velocity = velocity;
/*  85 */     this.inaccuracy = inaccuracy;
/*     */     
/*  87 */     this.field_70163_u -= 0.25D;
/*  88 */     func_213317_d(func_213322_ci().func_72441_c(0.0D, 0.05D, 0.0D));
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_70186_c(double x, double y, double z, float velocity, float inaccuracy) {
/*  93 */     super.func_70186_c(x, y, z, velocity, inaccuracy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void func_184549_a(RayTraceResult result) {
/*  99 */     RayTraceResult.Type resultType = result.func_216346_c();
/* 100 */     if (resultType == RayTraceResult.Type.ENTITY) {
/* 101 */       attackEntity((EntityRayTraceResult)result);
/* 102 */     } else if (resultType == RayTraceResult.Type.BLOCK) {
/* 103 */       BlockRayTraceResult blockResult = (BlockRayTraceResult)result;
/* 104 */       BlockPos blockPos = blockResult.func_216350_a();
/* 105 */       BlockState state = this.field_70170_p.func_180495_p(blockPos);
/* 106 */       Vec3d vec3d = blockResult.func_216347_e().func_178786_a(this.field_70165_t, this.field_70163_u, this.field_70161_v);
/* 107 */       func_213317_d(vec3d);
/* 108 */       Vec3d vec3d1 = vec3d.func_72432_b().func_186678_a(0.05000000074505806D);
/* 109 */       this.field_70165_t -= vec3d1.field_72450_a;
/* 110 */       this.field_70163_u -= vec3d1.field_72448_b;
/* 111 */       this.field_70161_v -= vec3d1.field_72449_c;
/* 112 */       func_184185_a(state.func_215695_r().func_185846_f(), 1.0F, 1.2F / (this.field_70146_Z.nextFloat() * 0.2F + 0.9F));
/* 113 */       this.field_70254_i = true;
/* 114 */       this.field_70249_b = 7;
/* 115 */       func_70243_d(false);
/* 116 */       func_213872_b((byte)0);
/* 117 */       func_213865_o(false);
/* 118 */       state.func_215690_a(this.field_70170_p, state, blockResult, (Entity)this);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   protected void attackEntity(EntityRayTraceResult result) {
/* 124 */     if (!this.field_70170_p.field_72995_K) {
/* 125 */       Entity target = result.func_216348_a();
/* 126 */       Entity shooter = func_212360_k();
/*     */       
/* 128 */       if (this.multiThrow > 0) {
/* 129 */         multiThrow();
/*     */       }
/* 131 */       if (this.multiThrow < 0) {
/* 132 */         target.field_70172_ad = 0;
/*     */       }
/* 134 */       float dmg = ((Shuriken)func_184550_j().func_77973_b()).getAttackDamage(func_184550_j());
/* 135 */       if (func_70241_g()) {
/* 136 */         dmg *= 1.5F;
/*     */       }
/* 138 */       dmg = (float)(dmg + func_70242_d());
/*     */       
/* 140 */       if (target.func_70097_a((DamageSource)new IndirectEntityDamageSource("shuriken", (Entity)this, target), dmg)) {
/* 141 */         if (shooter != null && 
/* 142 */           shooter instanceof LivingEntity) {
/* 143 */           ((LivingEntity)shooter).func_130011_c(target);
/*     */         }
/*     */         
/* 146 */         if (func_70027_ad() && !(target instanceof net.minecraft.entity.monster.EndermanEntity)) {
/* 147 */           target.func_70015_d(5);
/*     */         }
/* 149 */         if (target instanceof LivingEntity && !this.customPotionEffects.isEmpty()) {
/* 150 */           for (EffectInstance effectinstance1 : this.customPotionEffects) {
/* 151 */             ((LivingEntity)target).func_195064_c(effectinstance1);
/*     */           }
/*     */         }
/* 154 */         func_70106_y();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   protected void func_70088_a() {
/* 161 */     super.func_70088_a();
/* 162 */     func_184212_Q().func_187214_a(ITEMSTACK_DATA, ItemStack.field_190927_a);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   public void func_70071_h_() {
/* 168 */     multiThrow();
/*     */     
/* 170 */     this.timer++;
/*     */     
/* 172 */     float tempPitth = this.field_70125_A;
/* 173 */     float tempYaw = this.field_70177_z;
/* 174 */     super.func_70071_h_();
/* 175 */     this.field_70127_C = this.field_70125_A = tempPitth;
/* 176 */     this.field_70126_B = this.field_70177_z = tempYaw;
/*     */     
/* 178 */     if (!this.field_70254_i) {
/* 179 */       this.field_70125_A -= 36.0F;
/*     */     }
/* 181 */     else if (!this.field_70170_p.field_72995_K && 
/* 182 */       this.isReturn && func_212360_k() instanceof PlayerEntity) {
/* 183 */       func_70100_b_((PlayerEntity)func_212360_k());
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 188 */     Vec3d motion = func_213322_ci();
/* 189 */     func_213293_j(motion.field_72450_a, motion.field_72448_b - 0.03D, motion.field_72449_c);
/*     */   }
/*     */ 
/*     */ 
/*     */   private void multiThrow() {
/* 194 */     if (!this.field_70170_p.field_72995_K && 
/* 195 */       this.timer % 3 == 1 && 
/* 196 */       this.multiThrow > 0) {
/* 197 */       Entity shooter = func_212360_k();
/* 198 */       if (shooter instanceof LivingEntity) {
/* 199 */         ItemStack stack = pickupInventoryShuriken();
/* 200 */         if (!stack.func_190926_b()) {
/* 201 */           ShurikenEntity entity = new ShurikenEntity((LivingEntity)shooter, this.field_70170_p);
/* 202 */           entity.setItemStack(stack);
/* 203 */           entity.func_184547_a(shooter, shooter.field_70125_A, shooter.field_70177_z, 0.0F, this.velocity, this.inaccuracy);
/*     */           
/* 205 */           entity.multiThrow = (--this.multiThrow != 0) ? this.multiThrow : -1;
/* 206 */           entity.field_70251_a = this.field_70251_a;
/* 207 */           entity.infinity = this.infinity;
/* 208 */           entity.func_70243_d(func_70241_g());
/* 209 */           entity.setEffect(getEffect());
/* 210 */           entity.setIsReturn(this.isReturn);
/* 211 */           entity.func_70239_b(func_70242_d() * 0.699999988079071D);
/* 212 */           entity.func_70015_d(func_223314_ad());
/* 213 */           this.field_70170_p.func_217376_c((Entity)entity);
/* 214 */           this.field_70170_p.func_184148_a((PlayerEntity)null, shooter.field_70165_t, shooter.field_70163_u, shooter.field_70161_v, SoundEvents.field_187797_fA, SoundCategory.PLAYERS, 0.5F, 0.4F / (this.field_70146_Z.nextFloat() * 0.4F + 0.8F));
/* 215 */           this.multiThrow = -1;
/*     */         } else {
/* 217 */           this.multiThrow = 0;
/*     */         } 
/*     */       } else {
/* 220 */         this.multiThrow = 0;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nonnull
/*     */   private ItemStack pickupInventoryShuriken() {
/* 229 */     if (this.infinity > 0)
/*     */     {
/* 231 */       return new ItemStack((this.infinity == 3) ? (IItemProvider)HiganItems.SHURIKEN_DIAMOND : ((this.infinity == 2) ? (IItemProvider)HiganItems.SHURIKEN_IRON : (IItemProvider)HiganItems.SHURIKEN_STONE));
/*     */     }
/*     */     
/* 234 */     if (func_212360_k() != null && func_212360_k() instanceof PlayerEntity) {
/* 235 */       PlayerEntity player = (PlayerEntity)func_212360_k();
/* 236 */       ItemStack itemstack = player.field_71071_by.field_70462_a.stream().filter(s -> s.func_77973_b() instanceof Shuriken).findFirst().orElse(ItemStack.field_190927_a);
/* 237 */       if (!player.field_71075_bZ.field_75098_d) {
/* 238 */         if (isNoPickup()) {
/* 239 */           itemstack = itemstack.func_77946_l();
/* 240 */           itemstack.func_190920_e(1);
/*     */         } else {
/* 242 */           itemstack = itemstack.func_77979_a(1);
/*     */         } 
/*     */       }
/* 245 */       return itemstack;
/*     */     } 
/* 247 */     return ItemStack.field_190927_a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean func_189652_ae() {
/* 253 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_70100_b_(PlayerEntity entityIn) {
/* 258 */     if (!this.field_70170_p.field_72995_K && (this.field_70254_i || func_203047_q()) && this.field_70249_b <= 0) {
/* 259 */       boolean flag = (this.field_70251_a == AbstractArrowEntity.PickupStatus.ALLOWED || (this.field_70251_a == AbstractArrowEntity.PickupStatus.CREATIVE_ONLY && entityIn.field_71075_bZ.field_75098_d) || (func_203047_q() && func_212360_k().func_110124_au() == entityIn.func_110124_au()));
/*     */       
/* 261 */       if (!entityIn.field_71075_bZ.field_75098_d && !isNoPickup()) {
/* 262 */         if (this.field_70251_a == AbstractArrowEntity.PickupStatus.ALLOWED && !entityIn.field_71071_by.func_70441_a(func_184550_j())) {
/* 263 */           flag = false;
/*     */         }
/*     */       } else {
/* 266 */         flag = true;
/*     */       } 
/* 268 */       if (flag) {
/* 269 */         entityIn.func_71001_a((Entity)this, 1);
/* 270 */         func_70106_y();
/* 271 */       } else if (this.isReturn) {
/* 272 */         func_70106_y();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_70106_y() {
/* 279 */     super.func_70106_y();
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_70037_a(CompoundNBT compound) {
/* 284 */     super.func_70037_a(compound);
/* 285 */     ItemStack itemstack = ItemStack.func_199557_a(compound.func_74775_l("Item"));
/* 286 */     setItemStack(itemstack);
/* 287 */     for (EffectInstance effectinstance : PotionUtils.func_185192_b(compound)) {
/* 288 */       addEffect(effectinstance);
/*     */     }
/* 290 */     this.infinity = compound.func_74762_e("infinity");
/* 291 */     this.economy = compound.func_74762_e("economy");
/*     */   }
/*     */ 
/*     */ 
/*     */   public void func_213281_b(CompoundNBT compound) {
/* 296 */     super.func_213281_b(compound);
/* 297 */     ItemStack itemstack = func_184550_j();
/* 298 */     if (!itemstack.func_190926_b()) {
/* 299 */       compound.func_218657_a("Item", (INBT)itemstack.func_77955_b(new CompoundNBT()));
/*     */     }
/* 301 */     if (!this.customPotionEffects.isEmpty()) {
/* 302 */       ListNBT listnbt = new ListNBT();
/*     */       
/* 304 */       for (EffectInstance effectinstance : this.customPotionEffects) {
/* 305 */         listnbt.add(effectinstance.func_82719_a(new CompoundNBT()));
/*     */       }
/* 307 */       compound.func_218657_a("CustomPotionEffects", (INBT)listnbt);
/*     */     } 
/* 309 */     compound.func_74768_a("infinity", this.infinity);
/* 310 */     compound.func_74768_a("economy", this.economy);
/*     */   }
/*     */ 
/*     */ 
/*     */   public IPacket<?> func_213297_N() {
/* 315 */     return NetworkHooks.getEntitySpawningPacket((Entity)this);
/*     */   }
/*     */ 
/*     */ 
/*     */   public ItemStack func_184543_l() {
/* 320 */     ItemStack itemstack = func_184550_j();
/* 321 */     return itemstack.func_190926_b() ? new ItemStack((IItemProvider)func_184550_j().func_77973_b()) : itemstack;
/*     */   }
/*     */ 
/*     */   public void setItemStack(ItemStack stack) {
/* 325 */     if (stack.func_77973_b() != func_184550_j().func_77973_b() || stack.func_77942_o()) {
/* 326 */       func_184212_Q().func_187227_b(ITEMSTACK_DATA, Util.func_200696_a(stack.func_77946_l(), p_213883_0_ -> p_213883_0_.func_190920_e(1)));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ItemStack func_184550_j() {
/* 334 */     return (ItemStack)func_184212_Q().func_187225_a(ITEMSTACK_DATA);
/*     */   }
/*     */ 
/*     */   public void setMultiThrow(int lvl) {
/* 338 */     this.multiThrow = lvl;
/*     */   }
/*     */ 
/*     */   public void addEffect(EffectInstance effect) {
/* 342 */     this.customPotionEffects.add(effect);
/*     */   }
/*     */ 
/*     */   public void setEffect(Collection<EffectInstance> effects) {
/* 346 */     this.customPotionEffects.clear();
/* 347 */     this.customPotionEffects.addAll(effects);
/*     */   }
/*     */ 
/*     */   public Set<EffectInstance> getEffect() {
/* 351 */     return this.customPotionEffects;
/*     */   }
/*     */ 
/*     */   public void setIsReturn(boolean isReturn) {
/* 355 */     this.isReturn = isReturn;
/*     */   }
/*     */ 
/*     */   public void setInfinity(IItemTier iItemTier) {
/* 359 */     this.infinity = (iItemTier == ItemTier.STONE) ? 1 : ((iItemTier == ItemTier.IRON) ? 2 : ((iItemTier == ItemTier.DIAMOND) ? 3 : 0));
/*     */   }
/*     */ 
/*     */   public void setEconomy(int eco) {
/* 363 */     this.economy = eco;
/*     */   }
/*     */ 
/*     */   public void setNonPickup() {
/* 367 */     this.field_70251_a = AbstractArrowEntity.PickupStatus.DISALLOWED;
/*     */   }
/*     */ 
/*     */   public boolean isNoPickup() {
/* 371 */     return (this.field_70251_a == AbstractArrowEntity.PickupStatus.DISALLOWED);
/*     */   }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 33 ms
	
*/