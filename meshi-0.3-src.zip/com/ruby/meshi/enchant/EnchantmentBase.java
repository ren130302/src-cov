/*    */ package com.ruby.meshi.enchant;
/*    */ 
/*    */ import net.minecraft.enchantment.Enchantment;
/*    */ import net.minecraft.enchantment.EnchantmentType;
/*    */ import net.minecraft.inventory.EquipmentSlotType;
/*    */ import net.minecraft.util.text.ITextComponent;
/*    */ import net.minecraft.util.text.TextFormatting;
/*    */ import net.minecraft.util.text.TranslationTextComponent;
/*    */ 
/*    */ abstract class EnchantmentBase
/*    */   extends Enchantment {
/*    */   protected EnchantmentBase(Enchantment.Rarity rarityIn, EnchantmentType typeIn, EquipmentSlotType[] slots) {
/* 13 */     super(rarityIn, typeIn, slots);
/*    */   }
/*    */ 
/*    */ 
/*    */   public ITextComponent func_200305_d(int level) {
/* 18 */     if (level < func_77325_b()) {
/* 19 */       return super.func_200305_d(level);
/*    */     }
/* 21 */     TranslationTextComponent translationTextComponent = new TranslationTextComponent(func_77320_a() + "_ex", new Object[0]);
/* 22 */     if (func_190936_d()) {
/* 23 */       translationTextComponent.func_211708_a(TextFormatting.RED);
/*    */     } else {
/* 25 */       translationTextComponent.func_211708_a(TextFormatting.GRAY);
/*    */     } 
/* 27 */     if (func_77325_b() < level) {
/* 28 */       translationTextComponent.func_150258_a("★");
/*    */     }
/* 30 */     return (ITextComponent)translationTextComponent;
/*    */   }
/*    */ 
/*    */ 
/*    */   public boolean isAllowedOnBooks() {
/* 35 */     return false;
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 2 ms
	
*/