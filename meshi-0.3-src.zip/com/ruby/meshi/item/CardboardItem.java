/*    */ package com.ruby.meshi.item;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.inventory.EquipmentSlotType;
/*    */ import net.minecraft.item.BlockItem;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class CardboardItem extends BlockItem {
/*    */   public CardboardItem(Block block, Item.Properties properties) {
/* 12 */     super(block, properties);
/*    */   }
/*    */ 
/*    */ 
/*    */   public boolean canEquip(ItemStack stack, EquipmentSlotType armorType, Entity entity) {
/* 17 */     return (EquipmentSlotType.HEAD == armorType);
/*    */   }
/*    */ 
/*    */ 
/*    */   public EquipmentSlotType getEquipmentSlot(ItemStack stack) {
/* 22 */     return EquipmentSlotType.HEAD;
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 1 ms
	
*/