/*    */ package com.ruby.meshi.client.renderer;
/*    */ 
/*    */ import com.mojang.blaze3d.platform.GlStateManager;
/*    */ import com.ruby.meshi.entity.ShurikenEntity;
/*    */ import java.util.function.Consumer;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.renderer.entity.EntityRenderer;
/*    */ import net.minecraft.client.renderer.entity.EntityRendererManager;
/*    */ import net.minecraft.client.renderer.model.ItemCameraTransforms;
/*    */ import net.minecraft.client.renderer.texture.AtlasTexture;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraft.util.math.MathHelper;
/*    */ 
/*    */ 
/*    */ public class ShurikenRender
/*    */   extends EntityRenderer<ShurikenEntity>
/*    */ {
/* 20 */   private static final ResourceLocation RESOURCE = new ResourceLocation("meshi", "textures/entitys/claw.png");
/*    */ 
/*    */   public ShurikenRender(EntityRendererManager renderManager) {
/* 23 */     super(renderManager);
/*    */   }
/*    */ 
/*    */ 
/*    */   public void doRender(ShurikenEntity entity, double x, double y, double z, float entityYaw, float partialTicks) {
/* 28 */     (mc.func_175598_ae()).field_78724_e.func_110577_a(AtlasTexture.field_110575_b);
/* 29 */     ItemStack stack = entity.func_184543_l();
/* 30 */     GlStateManager.enableLighting();
/* 31 */     float scale = 0.25F;
/* 32 */     if (!stack.func_190926_b()) {
/* 33 */       GlStateManager.pushMatrix();
/*    */       
/* 35 */       GlStateManager.translated(x, y, z);
/* 36 */       GlStateManager.rotatef(MathHelper.func_219799_g(partialTicks, entity.field_70126_B, entity.field_70177_z) - 90.0F, 0.0F, 1.0F, 0.0F);
/* 37 */       GlStateManager.rotatef(entity.xAngle, 1.0F, 0.0F, 0.0F);
/* 38 */       GlStateManager.rotatef(MathHelper.func_219799_g(partialTicks, entity.field_70127_C, entity.field_70125_A), 0.0F, 0.0F, 1.0F);
/* 39 */       GlStateManager.scalef(scale, scale, scale);
/* 40 */       mc.func_175599_af().func_181564_a(stack, ItemCameraTransforms.TransformType.FIXED);
/*    */       
/* 42 */       GlStateManager.popMatrix();
/*    */     } 
/* 44 */     GlStateManager.enableLighting();
/*    */   }
/*    */ 
/* 47 */   private static final Minecraft mc = Minecraft.func_71410_x();
/*    */ 
/*    */   public void renderItem(ItemStack stack, Consumer<ItemStack> transleter, Consumer<ItemStack> rotater, float scale) {
/* 50 */     if (!stack.func_190926_b()) {
/* 51 */       GlStateManager.pushMatrix();
/* 52 */       transleter.accept(stack);
/* 53 */       rotater.accept(stack);
/* 54 */       GlStateManager.scalef(scale, scale, scale);
/* 55 */       mc.func_175599_af().func_181564_a(stack, ItemCameraTransforms.TransformType.FIXED);
/* 56 */       GlStateManager.popMatrix();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   protected ResourceLocation getEntityTexture(ShurikenEntity entity) {
/* 62 */     return RESOURCE;
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 7 ms
	
*/