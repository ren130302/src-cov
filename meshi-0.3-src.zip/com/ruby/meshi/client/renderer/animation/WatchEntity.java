/*    */ package com.ruby.meshi.client.renderer.animation;
/*    */ 
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.util.Direction;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.util.math.MathHelper;
/*    */ 
/*    */ public class WatchEntity
/*    */   extends SwingHead
/*    */ {
/*    */   @Nullable
/*    */   Entity entity;
/*    */   BlockPos pos;
/*    */   
/*    */   public WatchEntity(Direction direction, BlockPos pos) {
/* 17 */     super(direction);
/* 18 */     this.pos = pos;
/*    */   }
/*    */ 
/*    */   public WatchEntity setTarget(Entity entity) {
/* 22 */     this.entity = entity;
/* 23 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */   void headMove() {
/* 28 */     if (this.entity == null || !this.entity.func_70089_S()) {
/* 29 */       super.headMove();
/*    */       return;
/*    */     } 
/* 32 */     this.rotatePitch = calcAngle(this.rotatePitch, -getLookingPitch() + getHeadPitchOffset(), 10.0F);
/* 33 */     this.rotateYaw = calcAngle(this.rotateYaw, getLookingYaw(), 35.0F);
/*    */     
/* 35 */     this.rotatePitch = MathHelper.func_76131_a(this.rotatePitch, -35.0F, 35.0F);
/* 36 */     this.rotateYaw = MathHelper.func_76131_a(this.rotateYaw, -35.0F, 35.0F);
/*    */   }
/*    */ 
/*    */   float calcAngle(float baseAngle, float amount, float swingSpeed) {
/* 40 */     float f = MathHelper.func_203302_c(baseAngle, amount);
/* 41 */     float f1 = MathHelper.func_76131_a(f, -swingSpeed, swingSpeed);
/* 42 */     return baseAngle + f1;
/*    */   }
/*    */ 
/*    */   float getLookingPitch() {
/* 46 */     double d0 = this.pos.func_177958_n() - this.entity.field_70165_t;
/* 47 */     double d1 = this.pos.func_177952_p() - this.entity.field_70161_v;
/* 48 */     return (float)(MathHelper.func_181159_b(d1, d0) * 57.2957763671875D) - 90.0F;
/*    */   }
/*    */ 
/*    */   float getLookingYaw() {
/* 52 */     double d0 = this.pos.func_177958_n() - this.entity.field_70165_t;
/* 53 */     double d1 = this.pos.func_177956_o() - this.entity.field_70163_u + this.entity.func_70047_e();
/* 54 */     double d2 = this.pos.func_177952_p() - this.entity.field_70161_v;
/* 55 */     double d3 = MathHelper.func_76133_a(d0 * d0 + d2 * d2);
/* 56 */     return (float)-(MathHelper.func_181159_b(d1, d3) * 57.2957763671875D);
/*    */   }
/*    */ 
/*    */   float getHeadPitchOffset() {
/* 60 */     float offset = 0.0F;
/* 61 */     switch (this.direction) {
/*    */       case EAST:
/* 63 */         offset = 90.0F;
/*    */         break;
/*    */       case SOUTH:
/* 66 */         offset = 180.0F;
/*    */         break;
/*    */       case WEST:
/* 69 */         offset = 270.0F;
/*    */         break;
/*    */     } 
/* 72 */     return offset;
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 4 ms
	
*/