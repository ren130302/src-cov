package com.ruby.meshi.util;

import com.ruby.meshi.util.CapabilityHandler.CapExtendInvProvider;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus;

@EventBusSubscriber(
   bus = Bus.FORGE
)
public class CapabilityHandler {
   public static final ResourceLocation EXTEND_INVENTORY = new ResourceLocation("meshi", "extend_inv");

   @SubscribeEvent
   public static void attach(AttachCapabilitiesEvent<Entity> event) {
      if (event.getObject() instanceof PlayerEntity) {
         event.addCapability(EXTEND_INVENTORY, new CapExtendInvProvider());
      }

   }
}