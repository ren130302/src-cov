/*    */ package com.ruby.meshi.fluid;
/*    */ 
/*    */ import net.minecraft.fluid.FlowingFluid;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MeshiFluids
/*    */ {
/* 10 */   public static final FlowingFluid FLOWING_HOT_SPING = (FlowingFluid)register("flowing_hot_spring", new HotSpring.Flowing());
/* 11 */   public static final FlowingFluid HOT_SPING = (FlowingFluid)register("hot_spring", new HotSpring.Source());
/*    */ 
/*    */ 
/*    */   private static <T extends net.minecraft.fluid.Fluid> T register(String name, T fluid) {
/* 15 */     return (T)fluid.setRegistryName("meshi", name);
/*    */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\s20203029\Downloads\forge-1.14.4-28.2.26-mdk\src\test\resources\meshi-0.3.jar
	Total time: 3 ms
	
*/